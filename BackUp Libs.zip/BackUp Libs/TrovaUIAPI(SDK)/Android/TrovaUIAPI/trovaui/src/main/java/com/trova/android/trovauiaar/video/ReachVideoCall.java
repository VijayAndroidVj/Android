package com.trova.android.trovauiaar.video;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.trova.android.trovauiaar.ContactListFragment;
import com.trova.android.trovauiaar.Db.DataBaseHandler;
import com.trova.android.trovauiaar.Globalclass;
import com.trova.android.trovauiaar.R;
import com.trova.android.trovauiaar.Utils.CameraPreview;
import com.trova.android.trovauiaar.Utils.JoinConferenceDialog;
import com.trova.android.trovauiaar.model.UserModel;
import com.trova.android.trovauiaar.service.TrovaService;
import com.trova.android.trovauiaar.voice.ReachVoiceCall;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.EglBase;
import org.webrtc.MediaStream;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoRenderer;
import org.webrtc.VideoTrack;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import arr.trova.in.trovawoui.BaseActivity;
import arr.trova.in.trovawoui.Utils.PercentFrameLayout;
import arr.trova.in.trovawoui.Utils.PermissionCheck;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnPermissionsRequired;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAcceptedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCallState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCalleeBusy;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveLocalStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveMissedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRejectCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRemoteStream;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.GadgetAgent;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.agentName;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.mainAgent;

/**
 * Created by razin on 04-10-2017..
 */
public class ReachVideoCall extends BaseActivity {
    private static final int PERMISSION_REQUEST_CODE = 1234;
    public static ReachVideoCall reachVideoCall;
    public static boolean isVideoCallAlive = false;
    public HashMap<Integer, String> videoList = new HashMap<>();
    boolean isConnected;
    boolean endCallDone;
    boolean makeAgentCall = false;
    boolean makeNormalCall = false;
    private View rlremote1View, rlremote2View;
    private ImageView img_trova_video_call_video;
    private ImageView img_trova_video_call_mic;
    private ImageView img_trova_video_call_speaker;
    private ImageView img_trova_video_call_add;
    private ImageView img_trova_video_call_list;
    private SurfaceViewRenderer incalllocalvideoview;
    private SurfaceViewRenderer incallremotevideoview;
    private SurfaceViewRenderer incallremotevideoviewtwo;
    private View flincallremotevideoview, flincallremotevideoviewtwo;
    private PercentFrameLayout incallremotevideolayout0;
    private ImageView ivMic1, ivMic2;
    private TextView txtVideo2Name;
    private RelativeLayout ll_trova_video_controls;
    private FrameLayout fl_reach_video_call_fragment_container;
    private LinearLayout ll_trova_video_call_contact_info_container;
    private Fragment fragment1 = new ContactListFragment();
    private FragmentTransaction ft;
    private String callType;
    private String otherUserID;
    private String agentKey;
    private String otherUserName = "";
    private DataBaseHandler dataBaseHandler;
    private boolean isRejected = false, isCallstarted = false, isdestroy = false;
    private TextView tv_trova_video_call_caller_name;
    public ImageView img_trova_video_call_reject, img_trova_video_call_accept;
    private EglBase rootEglBase;
    private EglBase rootEglBase2;
    private boolean isSpeaker;
    private boolean isMicEnabled = true;
    private boolean isVideoEnabled = true;
    private long startTime;
    private TextView tv_trova_video_call_caller_id;
    private boolean restrictEscalate;
    private TextView tv_trova_video_call_finding_agents;
    private LinearLayout ll_trova_video_call_finding_agents;
    private TextView tv_trova_video_call_business_name;
    private String businessName = "";
    private CameraPreview mPreview;
    private int status = 0;
    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private long[] vibratepattern = {0, 200, 600};
    private Handler mainThreadHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer m; /*assume, somewhere in the global scope...*/
    private Runnable delayedTask;
    private MediaPlayer mbusy;
    private VideoRenderer videoRendererRemote, videoRendererLocal;
    private VideoRenderer videoRendererRemotetwo;
    private VideoTrack videoTrackRemote, videoTrackLocal;
    private VideoTrack videoTrackRemotetwo;
    private Handler mHandler = new Handler();

    private ProgressBar mProgress;

    private int[] img_trova_video_call_speaker_pos = new int[2];
    private int[] img_trova_video_call_mic_pos = new int[2];
    private int[] img_trova_video_call_add_pos = new int[2];
    private int[] img_trova_video_call_video_pos = new int[2];
    private int[] img_trova_video_call_list_pos = new int[2];
    /**
     * Background Runnable thread
     */
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            long millisUntilFinished = System.currentTimeMillis() - startTime;
            tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
            tv_trova_video_call_caller_id.setText(String.format(Locale.getDefault(), "%s %02d:%02d:%02d", getString(R.string.call_duration),
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            // Running this thread after 100 milliseconds
            mHandler.postDelayed(this, 1000);
        }
    };
    private Handler mCallingHandler = new Handler();
    private int callingTxtCount = 1;
    /**
     * Background Runnable thread
     */
    private Runnable mUpdateCalling = new Runnable() {
        public void run() {
            switch (callingTxtCount) {
                case 0:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s", getString(R.string.finding_agents)));
                    callingTxtCount = 1;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                case 1:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s.", getString(R.string.finding_agents)));
                    callingTxtCount = 2;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                case 2:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s..", getString(R.string.finding_agents)));
                    callingTxtCount = 3;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                default:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s...", getString(R.string.finding_agents)));
                    callingTxtCount = 0;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isVideoCallAlive = true;
        reachVideoCall = this;
        dataBaseHandler = DataBaseHandler.getInstance(activity);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);


    }

    private void setInitUI() {
        ll_trova_video_controls = findViewById(R.id.rl_trova_video_controls);
        fl_reach_video_call_fragment_container = findViewById(R.id.fl_reach_video_call_fragment_container);
        ll_trova_video_call_contact_info_container = findViewById(R.id.ll_trova_video_call_contact_info_container);
        img_trova_video_call_video = findViewById(R.id.img_trova_video_call_video);
        img_trova_video_call_mic = findViewById(R.id.img_trova_video_call_mic);
        img_trova_video_call_speaker = findViewById(R.id.img_trova_video_call_speaker);
        img_trova_video_call_add = findViewById(R.id.img_trova_video_call_add);
        img_trova_video_call_list = findViewById(R.id.img_trova_video_call_list);
        tv_trova_video_call_business_name = findViewById(R.id.tv_trova_video_call_business_name);
        tv_trova_video_call_caller_name = findViewById(R.id.tv_trova_video_call_caller_name);
        tv_trova_video_call_caller_id = findViewById(R.id.tv_trova_video_call_caller_id);
        img_trova_video_call_reject = findViewById(R.id.img_trova_video_call_reject);
        img_trova_video_call_accept = findViewById(R.id.img_trova_video_call_accept);
        img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_black_24dp);
        img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);

        img_trova_video_call_speaker.getLocationOnScreen(img_trova_video_call_speaker_pos);
        img_trova_video_call_mic.getLocationOnScreen(img_trova_video_call_mic_pos);
        img_trova_video_call_add.getLocationOnScreen(img_trova_video_call_add_pos);
        img_trova_video_call_video.getLocationOnScreen(img_trova_video_call_video_pos);
        img_trova_video_call_list.getLocationOnScreen(img_trova_video_call_list_pos);

        mProgress = findViewById(R.id.circularProgressbar);

    }

    private void InitVideoUI() {
        incallremotevideolayout0 = findViewById(R.id.incallremotevideolayout0);
        incallremotevideolayout0.setPosition(0, 0, 100, 100);
        incalllocalvideoview = findViewById(R.id.incalllocalvideoview);
        incallremotevideoview = findViewById(R.id.incallremotevideoview);
        incallremotevideoviewtwo = findViewById(R.id.incallremotevideoviewtwo);
        ivMic1 = findViewById(R.id.ivMic1);
        ivMic2 = findViewById(R.id.ivMic2);
        ivMic1.setVisibility(View.GONE);
        txtVideo2Name = findViewById(R.id.txtVideo2Name);

        rlremote1View = findViewById(R.id.rlremote1View);
        rlremote2View = findViewById(R.id.rlremote2View);

        rlremote1View.setVisibility(View.GONE);
        rlremote2View.setVisibility(View.GONE);

        flincallremotevideoview = findViewById(R.id.flincallremotevideoview);
        flincallremotevideoviewtwo = findViewById(R.id.flincallremotevideoviewtwo);

        rootEglBase = EglBase.create();
        rootEglBase2 = EglBase.create();
        incalllocalvideoview.init(rootEglBase.getEglBaseContext(), null);
        incalllocalvideoview.setZOrderMediaOverlay(true);
        incalllocalvideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
        incalllocalvideoview.setMirror(false);
        incalllocalvideoview.requestLayout();

        flincallremotevideoview.setVisibility(View.VISIBLE);
        flincallremotevideoviewtwo.setVisibility(View.VISIBLE);

        incallremotevideoview.init(rootEglBase.getEglBaseContext(), null);
        incallremotevideoview.setZOrderMediaOverlay(false);
        incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
        incallremotevideoview.setMirror(false);
        incallremotevideoview.requestLayout();


        incallremotevideoviewtwo.init(rootEglBase2.getEglBaseContext(), null);
        incallremotevideoviewtwo.setZOrderMediaOverlay(false);
        incallremotevideoviewtwo.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
        incallremotevideoviewtwo.setMirror(false);
        incallremotevideoviewtwo.requestLayout();

        incallremotevideolayout0.setVisibility(View.VISIBLE);
        flincallremotevideoview.setVisibility(View.GONE);
        flincallremotevideoviewtwo.setVisibility(View.GONE);

        ll_trova_video_call_finding_agents = findViewById(R.id.ll_trova_video_call_finding_agents);
        tv_trova_video_call_finding_agents = findViewById(R.id.tv_trova_video_call_finding_agents);
        ll_trova_video_controls.setVisibility(View.GONE);
    }

    private void setRegisterUI() {
        img_trova_video_call_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                    if (Globalclass.trovaSDK_init != null)
                        Globalclass.trovaSDK_init.trovaVideoMute(isVideoEnabled);
                    isVideoEnabled = !isVideoEnabled;
                    if (!isVideoEnabled) {
                        img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_off_black_24dp);
                    } else {
                        img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_black_24dp);
                    }
                } else {
                    incallremotevideoview.callOnClick();
                }
            }
        });

        isSpeaker = true;

        img_trova_video_call_speaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                    if (isSpeaker) {
                        Globalclass.trovaSDK_init.trovaAudioMute(true);
                        img_trova_video_call_speaker.setImageResource(R.drawable.ic_volume_off_black_24dp);
                        isSpeaker = false;
                    } else {
                        Globalclass.trovaSDK_init.trovaAudioMute(false);
                        img_trova_video_call_speaker.setImageResource(R.drawable.ic_volume_up_black_24dp);
                        isSpeaker = true;
                    }
                } else {
                    incallremotevideoview.callOnClick();
                }

            }
        });

        img_trova_video_call_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                    if (Globalclass.trovaSDK_init != null)
                        Globalclass.trovaSDK_init.trovaMicMute(isMicEnabled);
                    isMicEnabled = !isMicEnabled;
                    if (isMicEnabled) {
                        img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);
                    } else {
                        img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_off_black_24dp);
                    }
                    try {
                        JSONObject nuserObj = new JSONObject();
                        nuserObj.put("event", isMicEnabled ? "micon" : "micoff");
                        nuserObj.put("userId", preferenceUtil.getUserId());
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaXmit_Notification(otherUserID, nuserObj.toString(), "high", 0, "", "");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    incallremotevideoview.callOnClick();
                }
            }
        });

        img_trova_video_call_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TrovaService.notificationManager != null) {
                    TrovaService.notificationManager.cancelAll();
                }
                if (TrovaService.userNotif != null) {
                    TrovaService.userNotif = null;
                }
                reachVideoCall = null;
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (mPreview != null) {
                    mPreview.destroycamView();
                    mPreview = null;
                }

                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        endCallDone = true;
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_End("video", otherUserID);
                        reachVideoCall = null;
                        if (TrovaService.notificationManager != null) {
                            TrovaService.notificationManager.cancelAll();
                        }
                        if (TrovaService.userNotif != null) {
                            TrovaService.userNotif = null;
                        }
                        isdestroy = true;
                        onPause();
                        onfinish();
                    } else {
                        isRejected = true;
                        if (callType.equals("answer")) {
//                            postEvent(POSTREJECTCALL);
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaCall_Reject("video", otherUserID);
                        } else {
//                            postEvent(POSTMISSEDCALL);
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaCall_InitMissedCall("video", otherUserID);
                        }
                        reachVideoCall = null;
                        if (TrovaService.notificationManager != null) {
                            TrovaService.notificationManager.cancelAll();
                        }
                        if (TrovaService.userNotif != null) {
                            TrovaService.userNotif = null;
                        }
                        isdestroy = true;
                        onPause();
                        onfinish();
                    }
                } else {
                    reachVideoCall = null;
                    if (TrovaService.notificationManager != null) {
                        TrovaService.notificationManager.cancelAll();
                    }
                    if (TrovaService.userNotif != null) {
                        TrovaService.userNotif = null;
                    }
                    isdestroy = true;
                    onPause();
                    onfinish();
                }
            }
        });

        img_trova_video_call_accept.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                TrovaService.notificationManager.cancel(0);
                TrovaService.createInCallNotification(otherUserName, otherUserID, "video");
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                incallremotevideolayout0.removeAllViews();
                incallremotevideolayout0.setVisibility(View.GONE);
                flincallremotevideoview.setVisibility(View.VISIBLE);
                incallremotevideoview.setZOrderMediaOverlay(false);
                incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                incallremotevideoview.setMirror(false);
                incalllocalvideoview.setVisibility(View.VISIBLE);
                incalllocalvideoview.setVisibility(View.VISIBLE);
                if (Globalclass.trovaSDK_init != null)
                    Globalclass.trovaSDK_init.trovaCall_Answer("video", otherUserID);
//                postEvent(POSTANSWERCALL);
                img_trova_video_call_accept.setVisibility(View.GONE);
                ll_trova_video_controls.setVisibility(View.VISIBLE);
                img_trova_video_call_speaker.setVisibility(View.VISIBLE);
                img_trova_video_call_add.setVisibility(View.VISIBLE);
                img_trova_video_call_list.setVisibility(View.VISIBLE);
                img_trova_video_call_mic.setVisibility(View.VISIBLE);
                img_trova_video_call_video.setVisibility(View.VISIBLE);
                tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
                tv_trova_video_call_caller_id.setText("connecting...");

//                tv_trova_video_call_caller_name.setText(otherUserID);
                ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("In-Call");
                isConnected = true;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                            slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                            slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                        }
                    }
                }, 5000);
            }
        });

        incallremotevideoview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                    rlremote1View.setVisibility(View.GONE);
                    slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                    slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                    if (flincallremotevideoviewtwo.getVisibility() == View.VISIBLE) {
                        slideDown(rlremote2View, 0, -(ll_trova_video_call_contact_info_container.getHeight() + rlremote2View.getHeight()), 400);
                        incalllocalvideoview.setVisibility(View.GONE);
                    } else {
                        rlremote2View.setVisibility(View.GONE);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    }
                } else {
                    rlremote1View.setVisibility(View.VISIBLE);
                    slideUp(ll_trova_video_controls, ll_trova_video_call_contact_info_container.getHeight(), 0);
                    slideUp(ll_trova_video_call_contact_info_container, -ll_trova_video_call_contact_info_container.getHeight(), 0);
                    if (flincallremotevideoviewtwo.getVisibility() == View.VISIBLE) {
                        slideUp(rlremote2View, -(ll_trova_video_call_contact_info_container.getHeight() + rlremote2View.getHeight()), 0);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    } else {
                        rlremote2View.setVisibility(View.GONE);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        incallremotevideoviewtwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                    rlremote1View.setVisibility(View.GONE);
                    slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                    slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                    if (flincallremotevideoviewtwo.getVisibility() == View.VISIBLE) {
                        slideDown(rlremote2View, 0, -(ll_trova_video_call_contact_info_container.getHeight() + rlremote2View.getHeight()), 400);
                        incalllocalvideoview.setVisibility(View.GONE);
                    } else {
                        rlremote2View.setVisibility(View.GONE);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    }
                } else {
                    rlremote1View.setVisibility(View.VISIBLE);
                    slideUp(ll_trova_video_controls, ll_trova_video_call_contact_info_container.getHeight(), 0);
                    slideUp(ll_trova_video_call_contact_info_container, -ll_trova_video_call_contact_info_container.getHeight(), 0);
                    if (flincallremotevideoviewtwo.getVisibility() == View.VISIBLE) {
                        slideUp(rlremote2View, -(ll_trova_video_call_contact_info_container.getHeight() + rlremote2View.getHeight()), 0);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    } else {
                        rlremote2View.setVisibility(View.GONE);
                        incalllocalvideoview.setVisibility(View.VISIBLE);
                    }
                }
            }
        });

        img_trova_video_call_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(agentKey))
                    if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                        if (!restrictEscalate) {
                            fl_reach_video_call_fragment_container.setVisibility(View.VISIBLE);
                            ft = getFragmentManager().beginTransaction();
                            ft.replace(R.id.fl_reach_video_call_fragment_container, fragment1).commit();
                        }
                    } else {
                        incallremotevideoview.callOnClick();
                    }
            }
        });
    }

    // slide the view from below itself to the current position
    public void slideUp(View view, int fromYDelta, int toYDelta) {
        view.setVisibility(View.VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                fromYDelta,  // fromYDelta
                toYDelta);                // toYDelta
        animate.setDuration(400);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.VISIBLE);
    }

    // slide the view from its current position to below itself
    public void slideDown(View view, int fromYDelta, int toYDelta, int duration) {
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                fromYDelta,                 // fromYDelta
                toYDelta); // toYDelta
        animate.setDuration(duration);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }

    private void handleCallViews() {
        status = getIntent().getIntExtra("status", 0);

        restrictEscalate = getIntent().getBooleanExtra("restrictEscalate", false);

        callType = getIntent().getStringExtra("callType");
        if (getIntent().hasExtra("otherUserID")) {
            otherUserID = getIntent().getStringExtra("otherUserID");
        }
        if (getIntent().hasExtra("agentKey")) {
            agentKey = getIntent().getStringExtra("agentKey");
        }
//        if (agentKey != null && !agentKey.equalsIgnoreCase("")) {
//            ReachVoiceCall.agentKey1 = agentKey;
//            if (!TextUtils.isEmpty(otherUserID))
//                ReachVoiceCall.conferenceId = md5(preferenceUtil.getBusinessKey() + otherUserID);
//        }


        if (getIntent().hasExtra("otherUserName")) {
            if (TextUtils.isEmpty(otherUserID))
                otherUserName = dataBaseHandler.getUserName(otherUserID);
            if (TextUtils.isEmpty(otherUserName))
                otherUserName = getIntent().getStringExtra("otherUserName");
        }
        if (getIntent().hasExtra("businessName")) {
            businessName = getIntent().getStringExtra("businessName");
        }
        if (status == 1) {
            ll_trova_video_call_finding_agents.setVisibility(View.VISIBLE);
            tv_trova_video_call_finding_agents.setText(getString(R.string.finding_agents));
            mCallingHandler.postDelayed(mUpdateCalling, 1000);
//            mCallingHandler1.removeCallbacks(mUpdateCalling);

            img_trova_video_call_accept.setVisibility(View.GONE);
            img_trova_video_call_reject.setVisibility(View.VISIBLE);
            ll_trova_video_controls.setVisibility(View.GONE);
            img_trova_video_call_speaker.setVisibility(View.GONE);
            img_trova_video_call_add.setVisibility(View.GONE);
            img_trova_video_call_list.setVisibility(View.GONE);
            img_trova_video_call_mic.setVisibility(View.GONE);
            img_trova_video_call_video.setVisibility(View.GONE);
            incalllocalvideoview.setVisibility(View.GONE);
            incallremotevideoview.setZOrderMediaOverlay(false);
            incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            incallremotevideoview.setMirror(false);
            incallremotevideoview.requestLayout();
            ArrayList<String> permissionlist = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
            if (permissionlist.size() <= 0)
                requestCameraPermissionAndContinue();

            if (callType.equals("answer")) {
                ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("Incoming");
                if (businessName != null && !businessName.isEmpty()) {
                    tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_business_name.setText(businessName);
                    tv_trova_video_call_caller_id.setVisibility(View.GONE);
                } else {
                    tv_trova_video_call_business_name.setVisibility(View.GONE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_caller_id.setText(otherUserID);
                }

                img_trova_video_call_accept.setVisibility(View.VISIBLE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                ll_trova_video_controls.setVisibility(View.GONE);
                img_trova_video_call_speaker.setVisibility(View.GONE);
                img_trova_video_call_add.setVisibility(View.GONE);
                img_trova_video_call_list.setVisibility(View.GONE);
                img_trova_video_call_mic.setVisibility(View.GONE);
                img_trova_video_call_video.setVisibility(View.GONE);
                incalllocalvideoview.setVisibility(View.GONE);
                incallremotevideoview.setZOrderMediaOverlay(false);
                incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
                incallremotevideoview.setMirror(false);
                incallremotevideoview.requestLayout();
                permissionlist = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
                if (permissionlist.size() <= 0)
                    requestCameraPermissionAndContinue();
            } else {
                if (Globalclass.trovaSDK_init != null)
                    makeAgentCall = Globalclass.trovaSDK_init.trovaGadgetCall_Init(activity, "video", agentKey);
            }
        } else {
            tv_trova_video_call_business_name.setVisibility(View.GONE);
            ll_trova_video_call_finding_agents.setVisibility(View.GONE);
            preferenceUtil.setVideoUserOnline(otherUserID);
            if (callType.equals("answer")) {
                ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("Incoming");
                if (businessName != null && !businessName.isEmpty()) {
                    tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_business_name.setText(businessName);
                    tv_trova_video_call_caller_id.setVisibility(View.GONE);
                } else {
                    tv_trova_video_call_business_name.setVisibility(View.GONE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_caller_id.setText(otherUserID);
                }

                img_trova_video_call_accept.setVisibility(View.VISIBLE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                ll_trova_video_controls.setVisibility(View.GONE);
                img_trova_video_call_speaker.setVisibility(View.GONE);
                img_trova_video_call_add.setVisibility(View.GONE);
                img_trova_video_call_list.setVisibility(View.GONE);
                img_trova_video_call_mic.setVisibility(View.GONE);
                img_trova_video_call_video.setVisibility(View.GONE);
                incalllocalvideoview.setVisibility(View.GONE);
                incallremotevideoview.setZOrderMediaOverlay(false);
                incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
                incallremotevideoview.setMirror(false);
                incallremotevideoview.requestLayout();
                ArrayList<String> permissionlist = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
                if (permissionlist.size() <= 0)
                    requestCameraPermissionAndContinue();
            } else if (callType.equalsIgnoreCase("in_call")) {
                if (businessName != null && !businessName.isEmpty()) {
                    tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_business_name.setText(businessName);

                    if (TextUtils.isEmpty(otherUserName)) {
                        otherUserName = agentName;
                    }

                    if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                        tv_trova_video_call_caller_name.setText(otherUserID);
                        tv_trova_video_call_caller_id.setText("");
                    } else {
                        tv_trova_video_call_caller_name.setText(otherUserName);
                        tv_trova_video_call_caller_id.setText("");
                    }

                } else {
                    tv_trova_video_call_business_name.setVisibility(View.GONE);
                    tv_trova_video_call_caller_id.setText(otherUserID);
                }
                ll_trova_video_controls.setVisibility(View.VISIBLE);
                img_trova_video_call_speaker.setVisibility(View.VISIBLE);
                img_trova_video_call_mic.setVisibility(View.VISIBLE);
                img_trova_video_call_accept.setVisibility(View.GONE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                Globalclass.trovaSDK_init.trovaCall_Answer("video", otherUserID);
                isConnected = true;
                ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("In-Call");
            } else {

                incalllocalvideoview.setVisibility(View.GONE);
                incallremotevideoview.setZOrderMediaOverlay(false);
                incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
                incallremotevideoview.setMirror(false);
                incallremotevideoview.requestLayout();

                if (businessName != null && !businessName.isEmpty()) {
                    tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_business_name.setText(businessName);
                    tv_trova_video_call_caller_id.setVisibility(View.GONE);
                } else {
                    tv_trova_video_call_business_name.setVisibility(View.GONE);
                    tv_trova_video_call_caller_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_name.setText(otherUserName);
                    tv_trova_video_call_caller_id.setText(otherUserID);
                }
                img_trova_video_call_accept.setVisibility(View.GONE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                ll_trova_video_controls.setVisibility(View.GONE);
                img_trova_video_call_speaker.setVisibility(View.GONE);
                img_trova_video_call_add.setVisibility(View.GONE);
                img_trova_video_call_list.setVisibility(View.GONE);
                img_trova_video_call_mic.setVisibility(View.GONE);
                img_trova_video_call_video.setVisibility(View.GONE);
                UserModel userModel = new UserModel();
                if (Globalclass.trovaSDK_init != null) {
                    if (status == 1) {
                        makeAgentCall = Globalclass.trovaSDK_init.trovaGadgetCall_Init(activity, "video", agentKey);
                        userModel.setAgentKey(otherUserID);
                        userModel.setDisplayName(businessName);
                    } else if (status == 2) {
                        makeAgentCall = Globalclass.trovaSDK_init.trovaAgentCall_Init(activity, "video", otherUserID, "", false, agentKey);
                        userModel.setAgentKey(otherUserID);
                        userModel.setDisplayName(businessName);
                    } else {
                        makeNormalCall = Globalclass.trovaSDK_init.trovaCall_Init(activity, "video", otherUserID);
                    }

                }
                if (makeAgentCall || makeNormalCall) {
                    requestCameraPermissionAndContinue();
                }
                playCallerTone();
            }
        }
        if (getIntent().hasExtra("action")) {
            if (getIntent().getStringExtra("action").equalsIgnoreCase("accept_call")) {
                img_trova_video_call_accept.callOnClick();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (fl_reach_video_call_fragment_container.getVisibility() == View.VISIBLE) {
            fl_reach_video_call_fragment_container.setVisibility(View.GONE);
        }
    }

    private String md5(String in) {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
            digest.reset();
            digest.update(in.getBytes());
            byte[] a = digest.digest();
            int len = a.length;
            StringBuilder sb = new StringBuilder(len << 1);
            for (byte anA : a) {
                sb.append(Character.forDigit((anA & 0xf0) >> 4, 16));
                sb.append(Character.forDigit(anA & 0x0f, 16));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }


    private void setRinger() {
        if (mediaPlayer == null)
            try {
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                switch (audio.getRingerMode()) {
                    case AudioManager.RINGER_MODE_NORMAL:
                        mediaPlayer = MediaPlayer.create(getApplicationContext(), notification);
                        mediaPlayer.setLooping(true);
                        mediaPlayer.start();
                        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        // Vibrate for 500 milliseconds
                        vibrator.vibrate(vibratepattern, 0);
                        break;
                    case AudioManager.RINGER_MODE_SILENT:
                        break;
                    case AudioManager.RINGER_MODE_VIBRATE:
                        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        // Vibrate for 500 milliseconds
                        vibrator.vibrate(vibratepattern, 0);
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    public void requestCameraPermissionAndContinue() {
        ArrayList<String> pendingPermissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
        if (pendingPermissions.size() > 0) {
            PermissionCheck.requestPermission(activity, pendingPermissions, PERMISSION_REQUEST_CODE);
        } else {
//            getCameraPreview();
            setCamera();
        }
    }

//    private void getCameraPreview() {
////        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
//        cameraCount = Camera.getNumberOfCameras();
//        if (cameraCount > 0) {
//            setCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
//        } else {
//            setCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
//        }
//    }

    boolean isAlreadayPlaying = false;

    private void setCamera() {
        if (!isAlreadayPlaying) {
            mPreview = new CameraPreview(this);
            incallremotevideolayout0.setVisibility(View.VISIBLE);
            incallremotevideolayout0.removeAllViews();
            incallremotevideolayout0.setScaleX(mPreview.getScaleX());
            incallremotevideolayout0.setScaleY(mPreview.getScaleY());
            incallremotevideolayout0.addView(mPreview);
            flincallremotevideoview.setVisibility(View.GONE);
            flincallremotevideoviewtwo.setVisibility(View.GONE);
            //mPreview.startCamera();
            isAlreadayPlaying = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (callType.equals("answer")) {
                        setRinger();
                    } else if (status != 1) {
                        playCallerTone();
                    }
                }
            }, 1200);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        initDestroy();
    }

    private void initDestroy() {
        if (isFinishing() || isdestroy) {
            isVideoCallAlive = false;
            isdestroy = false;
            try {
                if (mPreview != null) {
                    mPreview.destroycamView();
                    mPreview = null;
                }
                if (TrovaService.notificationManager != null) {
                    TrovaService.notificationManager.cancelAll();
                }
                if (TrovaService.userNotif != null) {
                    TrovaService.userNotif = null;
                }
                ReachVoiceCall.conferenceId = null;
                ReachVoiceCall.agentKey1 = null;
                reachVideoCall = null;
                preferenceUtil.setVideoUserOnline("");
                mHandler.removeCallbacks(mUpdateTimeTask);
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        if (!endCallDone)
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaCall_End("video", otherUserID);
                    } else if (!isRejected) {
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_Reject("video", otherUserID);
                    }
                }
                if (incalllocalvideoview != null) {
                    if (videoRendererLocal != null && videoTrackLocal != null && !isConnected)
                        videoTrackLocal.removeRenderer(videoRendererLocal);
                    incalllocalvideoview.release();
                    incalllocalvideoview = null;
                }
                videoTrackLocal = null;
//                if (!TextUtils.isEmpty(agentKey) && !callType.equalsIgnoreCase("answer") && !callType.equalsIgnoreCase("in_call")) {
                if (incallremotevideoview != null) {
                    if (videoRendererRemote != null && videoTrackRemote != null)
                        videoTrackRemote.removeRenderer(videoRendererRemote);
                    incallremotevideoview.release();
                    incallremotevideoview = null;
                }
                if (incallremotevideoviewtwo != null) {
                    if (videoRendererRemotetwo != null && videoTrackRemotetwo != null)
                        videoTrackRemotetwo.removeRenderer(videoRendererRemotetwo);
                    incallremotevideoviewtwo.release();
                    incallremotevideoviewtwo = null;
                }
//                }
                if (rootEglBase != null) {
                    rootEglBase.release();
                    rootEglBase.releaseSurface();
                    rootEglBase = null;
                }
                if (rootEglBase2 != null) {
                    rootEglBase2.release();
                    rootEglBase2.releaseSurface();
                    rootEglBase2 = null;
                }
                videoTrackRemote = null;
                videoTrackRemotetwo = null;
                stopCallerTone();
                stopBusyTone();
                System.gc();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void stopBusyTone() {
        try {
            if (mbusy != null && mbusy.isPlaying()) {
                mbusy.stop();
                mbusy.release();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void playCallBusyTone() {
        try {
            if (mbusy == null) {
                mbusy = new MediaPlayer();
                AssetFileDescriptor descriptor = getAssets().openFd("phone_busy.mp3");
                mbusy.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                descriptor.close();

                mbusy.prepare();
                mbusy.setVolume(1f, 1f);
                mbusy.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopCallerTone() {
        try {
            mainThreadHandler.removeCallbacks(delayedTask);
            if (m != null && m.isPlaying()) {
                m.stop();
                m.release();
                m = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void playCallerTone() {
        try {
            if (m == null) {
                m = new MediaPlayer();
                AssetFileDescriptor descriptor = getAssets().openFd("ringing.mp3");
                m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                descriptor.close();

                m.prepare();
                m.setVolume(1f, 1f);
                m.setLooping(true);
                m.start();

                delayedTask = new Runnable() {
                    @Override
                    public void run() {
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_InitMissedCall("video", otherUserID);
                        onfinish();
                    }

                };
                mainThreadHandler.postDelayed(delayedTask, 30000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    private void flipCamera() {
//        if (camId == Camera.CameraInfo.CAMERA_FACING_BACK) {
//            setCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
//        } else {
//            setCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
//        }
//    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        initDestroy();
    }

    private void onfinish() {
        if (isTaskRoot()) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                finishAndRemoveTask();
            } else {
                finish();
            }
        } else {
            finish();
        }
    }

    String escalatedUserId = "";

    public void TrovaEvents(final JSONObject jsonObject) {
        String event;
        try {
            event = jsonObject.getString("trovaEvent");
            switch (event) {
                case "onMissedEscalation":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                                Toast.makeText(activity, agentName + " missed escalation", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (escalatedUserId != null && callerId.equalsIgnoreCase(escalatedUserId)) {
                                restrictEscalate = false;
                                isEscalationCancelled = true;
                            }
                        }
                    });
                    break;
                case "onCancelEscalation":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                                Toast.makeText(activity, agentName + " rejected escalation", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (escalatedUserId != null && callerId.equalsIgnoreCase(escalatedUserId)) {
                                restrictEscalate = false;
                                isEscalationCancelled = true;
                                img_trova_video_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                                mProgress.setVisibility(View.GONE);
                            }
                        }
                    });
                    break;
                case "micoff":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if (TextUtils.isEmpty(GadgetAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                ivMic1.setImageResource(R.drawable.ic_mic_off);
                            } else {
                                ivMic2.setImageResource(R.drawable.ic_mic_off);
                            }
                        }
                    });

                    break;
                case "micon":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if (TextUtils.isEmpty(GadgetAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                ivMic1.setImageResource(R.drawable.ic_mic_on);
                            } else {
                                ivMic2.setImageResource(R.drawable.ic_mic_on);
                            }
                        }
                    });

                    break;
                case OnTrovaReceiveCalleeBusy:
                    String callerId = jsonObject.get("callerId").toString();
                    if (callerId.equalsIgnoreCase(otherUserID)) {
                        stopCallerTone();
                        Toast.makeText(activity, callerId + " is Busy right now", Toast.LENGTH_LONG).show();
                        playCallBusyTone();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                stopCallerTone();
                                stopBusyTone();
                                isdestroy = true;
                                onPause();
                                onfinish();
                            }
                        }, 2000);
                    }
                    break;
                case OnTrovaAgentInfo:
                    String callMode = jsonObject.getString("callMode");
                    callerId = jsonObject.getString("callerId");
                    String agentName = jsonObject.getString("agentName");
                    String businessName = jsonObject.getString("displayName");
                    if (callMode.equalsIgnoreCase("video")) {
                        otherUserID = callerId;
                        if (TextUtils.isEmpty(otherUserID))
                            otherUserName = dataBaseHandler.getUserName(otherUserID);
                        if (TextUtils.isEmpty(otherUserName))
                            otherUserName = agentName;
                        ReachVoiceCall.conferenceId = md5(preferenceUtil.getBusinessKey() + otherUserID);
                        ll_trova_video_call_finding_agents.setVisibility(View.GONE);
                        preferenceUtil.setVideoUserOnline(otherUserID);
                        if (businessName != null && !businessName.isEmpty()) {
                            tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                            tv_trova_video_call_business_name.setText(businessName);
                        } else {
                            tv_trova_video_call_business_name.setVisibility(View.GONE);
                        }
                        tv_trova_video_call_caller_name.setText("Calling " + otherUserID);
                        incallremotevideolayout0.setVisibility(View.VISIBLE);
                        flincallremotevideoview.setVisibility(View.GONE);
                        flincallremotevideoviewtwo.setVisibility(View.GONE);
                        rlremote1View.setVisibility(View.GONE);
                        rlremote2View.setVisibility(View.GONE);
                        fl_reach_video_call_fragment_container.setVisibility(View.GONE);
                        ll_trova_video_call_finding_agents.setVisibility(View.GONE);
                        playCallerTone();
                    }
                    break;
                case OnTrovaReceiveLocalStream:
                    try {
                        MediaStream mediaStream = (MediaStream) jsonObject.get("stream");
                        videoList.put(0, "You");
                        if (mediaStream.videoTracks.size() == 1) {
                            videoTrackLocal = mediaStream.videoTracks.get(0);
                            videoTrackLocal.setEnabled(true);

                            if (callType.equalsIgnoreCase("in_call")) {
                                incallremotevideolayout0.setVisibility(View.GONE);
                                flincallremotevideoview.setVisibility(View.VISIBLE);
                                flincallremotevideoviewtwo.setVisibility(View.GONE);

                                incalllocalvideoview.setVisibility(View.VISIBLE);
                                videoRendererLocal = new VideoRenderer(incalllocalvideoview);
                                videoTrackLocal.addRenderer(videoRendererLocal);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;

                case OnTrovaReceiveRemoteStream:
                    try {
                        if (!isCallstarted) {
                            isCallstarted = true;
                            TrovaService.createInCallNotification(otherUserName, otherUserID, "video");
                            stopCallerTone();
                            img_trova_video_call_accept.setVisibility(View.GONE);
                            ll_trova_video_controls.setVisibility(View.VISIBLE);
                            img_trova_video_call_speaker.setVisibility(View.VISIBLE);
                            img_trova_video_call_add.setVisibility(View.VISIBLE);
                            img_trova_video_call_list.setVisibility(View.VISIBLE);
                            img_trova_video_call_mic.setVisibility(View.VISIBLE);
                            img_trova_video_call_video.setVisibility(View.VISIBLE);
                            ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("In-Call");
                            isConnected = true;
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                                        slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                                        slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                                    }
                                }
                            }, 5000);
                        }


                        MediaStream mediaStream = (MediaStream) jsonObject.get("stream");
                        String callerPhone = jsonObject.getString("callerId").trim();
                        if (!videoList.containsValue(callerPhone)) {
                            videoList.put(videoList.size(), callerPhone);
                        }

                        if (videoList.size() == 2) {
                            ivMic1.setVisibility(View.VISIBLE);
                            ivMic1.setImageResource(R.drawable.ic_mic_on);
                            incallremotevideolayout0.removeAllViews();
                            incallremotevideolayout0.setVisibility(View.GONE);
                            flincallremotevideoview.setVisibility(View.VISIBLE);
                            flincallremotevideoviewtwo.setVisibility(View.GONE);
                            incallremotevideoview.setZOrderMediaOverlay(false);
                            incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                            incallremotevideoview.setMirror(false);
                            incalllocalvideoview.setVisibility(View.VISIBLE);
                            videoTrackRemote = mediaStream.videoTracks.get(0);
                            videoTrackRemote.setEnabled(true);
                            videoRendererRemote = new VideoRenderer(incallremotevideoview);
                            videoTrackRemote.addRenderer(videoRendererRemote);
                            flincallremotevideoview.setVisibility(View.VISIBLE);

                            videoRendererLocal = new VideoRenderer(incalllocalvideoview);
                            videoTrackLocal.addRenderer(videoRendererLocal);

                        } else if (videoList.size() == 3) {
                            rlremote1View.setVisibility(View.VISIBLE);
                            rlremote2View.setVisibility(View.VISIBLE);
                            txtVideo2Name.setText(JoinConferenceDialog.agentName);
                            ivMic2.setImageResource(R.drawable.ic_mic_on);
                            isEscalationCancelled = false;
                            countDownTimer.cancel();
                            restrictEscalate = true;
                            img_trova_video_call_add.setBackgroundResource(R.drawable.rounded_corner_button_disabled);
                            incallremotevideolayout0.removeAllViews();
                            incallremotevideolayout0.setVisibility(View.GONE);
                            flincallremotevideoview.setVisibility(View.VISIBLE);
                            flincallremotevideoviewtwo.setVisibility(View.VISIBLE);
                            incallremotevideoviewtwo.bringToFront();
                            videoTrackRemotetwo = mediaStream.videoTracks.get(0);
                            videoTrackRemotetwo.setEnabled(true);
                            videoRendererRemotetwo = new VideoRenderer(incallremotevideoviewtwo);
                            videoTrackRemotetwo.addRenderer(videoRendererRemotetwo);
                            incallremotevideoviewtwo.bringToFront();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case OnTrovaCallState:
                    String status = jsonObject.getString("status");
                    if (status.equalsIgnoreCase("connected")) {
                        if (!isCallstarted) {
                            isCallstarted = true;
                            TrovaService.createInCallNotification(otherUserName, otherUserID, "video");
                            stopCallerTone();
                            incallremotevideolayout0.removeAllViews();
                            incallremotevideolayout0.setVisibility(View.GONE);
                            flincallremotevideoview.setVisibility(View.VISIBLE);
                            flincallremotevideoviewtwo.setVisibility(View.GONE);

                            incallremotevideoview.setZOrderMediaOverlay(false);
                            incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                            incallremotevideoview.setMirror(false);
                            incalllocalvideoview.setVisibility(View.VISIBLE);

                            img_trova_video_call_accept.setVisibility(View.GONE);
                            ll_trova_video_controls.setVisibility(View.VISIBLE);
                            img_trova_video_call_speaker.setVisibility(View.VISIBLE);
                            img_trova_video_call_add.setVisibility(View.VISIBLE);
                            img_trova_video_call_list.setVisibility(View.VISIBLE);
                            img_trova_video_call_mic.setVisibility(View.VISIBLE);
                            img_trova_video_call_video.setVisibility(View.VISIBLE);
                            ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("In-Call");
                            isConnected = true;
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                                        slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                                        slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                                    }
                                }
                            }, 5000);

                        }
                        if (startTime == 0) {
                            startTime = System.currentTimeMillis();
                            mHandler.postDelayed(mUpdateTimeTask, 100);
                        }
                    } else if (status.equalsIgnoreCase("failed")) {
                        callerId = jsonObject.has("callerId") ? jsonObject.getString("callerId") : "";
                        if (TextUtils.isEmpty(agentKey) || callerId.equalsIgnoreCase(otherUserID) || callerId.equalsIgnoreCase(mainAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                            endCallDone = true;
                            if (TrovaService.notificationManager != null) {
                                TrovaService.notificationManager.cancelAll();
                            }
                            if (TrovaService.userNotif != null) {
                                TrovaService.userNotif = null;
                            }
                            Toast.makeText(activity, "App unexpectedly stopped", Toast.LENGTH_SHORT).show();
                            isdestroy = true;
                            onPause();
                            reachVideoCall = null;
                            onfinish();
                        }
                    }
                    break;
                case OnTrovaReceiveEndCall:

                    try {
                        callMode = jsonObject.getString("callMode");
                        if (callMode.equalsIgnoreCase("video")) {
                            callerId = jsonObject.getString("callerId");
                            if (TextUtils.isEmpty(agentKey) || callerId.equalsIgnoreCase(otherUserID) || callerId.equalsIgnoreCase(mainAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                endCallDone = true;
//                                if (!TextUtils.isEmpty(agentKey))
//                                    Globalclass.trovaSDK_init.trovaCall_End("video", otherUserID);
                                reachVideoCall = null;
                                if (TrovaService.notificationManager != null) {
                                    TrovaService.notificationManager.cancelAll();
                                }
                                if (TrovaService.userNotif != null) {
                                    TrovaService.userNotif = null;
                                }
                                stopCallerTone();
                                stopBusyTone();
                                isdestroy = true;
                                onPause();
                                onfinish();
                            } else {
                                restrictEscalate = false;
                                isEscalationCancelled = true;
                                img_trova_video_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                                mProgress.setVisibility(View.GONE);
                                flincallremotevideoviewtwo.setVisibility(View.GONE);
                                slideDown(rlremote2View, 0, -(ll_trova_video_call_contact_info_container.getHeight() + rlremote2View.getHeight()), 400);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    break;

                case OnTrovaReceiveRejectCall:
                    reachVideoCall = null;
                    if (TrovaService.notificationManager != null) {
                        TrovaService.notificationManager.cancelAll();
                    }
                    if (TrovaService.userNotif != null) {
                        TrovaService.userNotif = null;
                    }
                    otherUserID = "";
                    stopCallerTone();
                    stopBusyTone();
                    isdestroy = true;
                    onPause();
                    onfinish();
                    break;

                case OnPermissionsRequired:
                    Toast.makeText(activity, "Permission Required", Toast.LENGTH_SHORT).show();
                    PermissionCheck.requestPermission(activity, PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions()), PERMISSION_REQUEST_CODE);
                    break;
                case OnTrovaReceiveMissedCall:

                    reachVideoCall = null;
                    if (TrovaService.notificationManager != null) {
                        TrovaService.notificationManager.cancelAll();
                    }
                    if (TrovaService.userNotif != null) {
                        TrovaService.userNotif = null;
                    }
                    isRejected = true;
                    try {
                        String callerid = jsonObject.get("callerId").toString();
                        callMode = jsonObject.get("callMode").toString();
                        if (TrovaService.lastReceivedCallTime == 0) {
                            TrovaService.lastReceivedCallTime = System.currentTimeMillis();
                        }
                        if (TextUtils.isEmpty(otherUserID) || callerid.equalsIgnoreCase(otherUserID) && callMode.equalsIgnoreCase("video")) {
                            stopCallerTone();
                            GadgetAgent = "";
                            JoinConferenceDialog.mainAgent = "";
                            JoinConferenceDialog.agentName = "";
                            JoinConferenceDialog.widgetName = "";
                            stopBusyTone();
                            isdestroy = true;
                            onPause();
                            onfinish();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    try {
                        String callerid = jsonObject.get("callerId").toString();
                        Toast.makeText(activity, "Missed call from " + callerid, Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;

                case OnTrovaAcceptedCall:
                    isCallstarted = true;
                    TrovaService.createInCallNotification(otherUserName, otherUserID, "video");
                    stopCallerTone();
                    incallremotevideolayout0.removeAllViews();
                    incallremotevideolayout0.setVisibility(View.GONE);
                    flincallremotevideoview.setVisibility(View.VISIBLE);
                    flincallremotevideoviewtwo.setVisibility(View.GONE);
                    tv_trova_video_call_caller_id.setVisibility(View.VISIBLE);
                    tv_trova_video_call_caller_id.setText("connecting...");

                    incallremotevideoview.setZOrderMediaOverlay(false);
                    incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                    incallremotevideoview.setMirror(false);
                    incalllocalvideoview.setVisibility(View.VISIBLE);

                    img_trova_video_call_accept.setVisibility(View.GONE);
                    ll_trova_video_controls.setVisibility(View.VISIBLE);
                    img_trova_video_call_speaker.setVisibility(View.VISIBLE);
                    img_trova_video_call_add.setVisibility(View.VISIBLE);
                    img_trova_video_call_list.setVisibility(View.VISIBLE);
                    img_trova_video_call_mic.setVisibility(View.VISIBLE);
                    img_trova_video_call_video.setVisibility(View.VISIBLE);
                    ((TextView) findViewById(R.id.tv_trova_video_calling)).setText("In-Call");
                    isConnected = true;
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (ll_trova_video_controls.getVisibility() == View.VISIBLE) {
                                slideDown(ll_trova_video_controls, 0, ll_trova_video_controls.getHeight(), 400);
                                slideDown(ll_trova_video_call_contact_info_container, 0, -ll_trova_video_call_contact_info_container.getHeight(), 400);
                            }
                        }
                    }, 5000);
                    callMode = jsonObject.getString("callMode");
                    if (callMode.equalsIgnoreCase("video")) {
                        callerId = jsonObject.getString("callerId");
                        if (!callerId.equalsIgnoreCase(otherUserID)) {
                            isEscalationCancelled = false;
                            countDownTimer.cancel();
                        }
                    }

                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    void setProgress() {
        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.circular_loader);
        mProgress.setVisibility(View.VISIBLE);
        mProgress.setProgress(0);   // Main Progress
        mProgress.setSecondaryProgress(100); // Secondary Progress
        mProgress.setMax(100); // Maximum Progress
        mProgress.setProgressDrawable(drawable);
    }

/*

    public static ReachEscalationCallBack reachEscalationCallBack = new ReachEscalationCallBack() {
        @Override
        public void setReachEscalationCallBack(JSONObject jsonObject) {
            try {
                String contact_name = jsonObject.getString("contact_name");
                String contact_number = jsonObject.getString("contact_number");
                String contact_user_id = jsonObject.getString("contact_user_id");
                JSONObject sendNotificationObject = new JSONObject();
                sendNotificationObject.put("event", "onJoinConferenceRequest");
                sendNotificationObject.put("agentKey", ReachVideoCall.reachVideoCall.agentKey);
                sendNotificationObject.put("displayName", ReachVideoCall.reachVideoCall.businessName);
                sendNotificationObject.put("callMode", "video");
                sendNotificationObject.put("callbackTime", System.currentTimeMillis());
                sendNotificationObject.put("widgetUserName", ReachVideoCall.reachVideoCall.otherUserName);
                sendNotificationObject.put("agentUserName", ReachVideoCall.reachVideoCall.preferenceUtil.getUserName());
                sendNotificationObject.put("agentUserId", ReachVideoCall.reachVideoCall.preferenceUtil.getUserId());
                sendNotificationObject.put("widgetUserId", ReachVideoCall.reachVideoCall.otherUserID);
                Globalclass.trovaSDK_init.trovaAddToConference(contact_user_id, sendNotificationObject.toString());
                if (!TextUtils.isEmpty(mainAgent)) {
                    mainAgent = ReachVideoCall.reachVideoCall.preferenceUtil.getUserId();
                    GadgetAgent = ReachVideoCall.reachVideoCall.otherUserID;
                }
                agentName = contact_name;
                ReachVideoCall.reachVideoCall.restrictEscalate = true;
                ReachVideoCall.reachVideoCall.escalatedUserId = contact_user_id;
                Toast.makeText(ReachVideoCall.reachVideoCall, contact_name + " escalated successfully", Toast.LENGTH_SHORT).show();
                ReachVideoCall.reachVideoCall.countDownTimer.start();
                ReachVideoCall.reachVideoCall.img_trova_video_call_add.setBackgroundResource(R.drawable.rounded_corner_button_disabled);
                ReachVideoCall.reachVideoCall.setProgress();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
*/


    private boolean isEscalationCancelled = true;

    private CountDownTimer countDownTimer = new

            CountDownTimer(30000, 1000) {

                public void onTick(long millisUntilFinished) {
                    Log.i("CountDownTimer:", "seconds remaining: " + millisUntilFinished / 1000);
                    if (millisUntilFinished / 1000 == 0) {
                        isEscalationCancelled = true;
                    }
                    int progress = (int) (((Double.valueOf(millisUntilFinished) / 30000) * 100));
                    Log.i("CountDown:", "percentage: " + progress);
                    mProgress.setProgress(mProgress.getMax() - progress);
                }

                public void onFinish() {
                    if (isEscalationCancelled) {
                        restrictEscalate = false;
                        img_trova_video_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                        mProgress.setVisibility(View.GONE);
                        Toast.makeText(activity, agentName + " Missed Escalation", Toast.LENGTH_SHORT).show();
                    }
                }
            };

    @Override
    protected void onResume() {
        super.onResume();
        if (permissionGranted) {
            permissionGranted = false;
            setContentView(R.layout.activity_trova_video_conference_call_new);
//            ContactListFragment.setCallBack(reachEscalationCallBack);
            setInitUI();
            InitVideoUI();
            setRegisterUI();
            handleCallViews();
        }
    }


//    public static void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
//        trovaUICallBack = trovaUIAPICallBack;
//    }
//
//    private void postEvent(String event) {
//        if (trovaUICallBack != null) {
//            JSONObject jobj = new JSONObject();
//            try {
//                jobj.put("trovaEvent", event);
//                jobj.put("callerId", otherUserID);
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            trovaUICallBack.setTrovaUICallBack(jobj);
//        }
//    }
}


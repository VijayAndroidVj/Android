package arr.trova.in.trovawoui.s3Util;

import android.content.ContentResolver;
import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import arr.trova.in.trovawoui.Utils.PreferenceUtil;
import arr.trova.in.trovawoui.services.TrovaApiService;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.InProgress;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Upload;

/**
 * Created by iyara_rajan on 10-08-2017.
 */

public class Upload {

    public Upload() {

    }

    static String amazonAWSBucket = "trovamedia";
    static TransferUtility transferUtility;
    public static AmazonS3Client amazonS3Client;

    private static AmazonS3Client credentialsProvider(Context context) {
        if (amazonS3Client == null) {

            PreferenceUtil preferenceUtil = new PreferenceUtil(context);
            String amazonCognitoId = preferenceUtil.getS3CognitioId();
            String region = preferenceUtil.getS3Region();
            amazonAWSBucket = preferenceUtil.getS3Bucket();

            if (TextUtils.isEmpty(amazonCognitoId) && TextUtils.isEmpty(region) && TextUtils.isEmpty(amazonAWSBucket)) {
                amazonCognitoId = "us-east-1:75f62414-b651-471f-9211-69165861a261";
                region = "us-east-1";
                amazonAWSBucket = "trovamedia";
            }

            // Initialize the Amazon Cognito credentials provider
            CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                    context, amazonCognitoId, // Identity Pool ID
                    Regions.fromName(region) // Region
            );
            amazonS3Client = setAmazonS3Client(credentialsProvider, region);
        }
        return amazonS3Client;
    }

    /**
     * Create a AmazonS3Client constructor and pass the credentialsProvider.
     *
     * @param credentialsProvider
     * @param region
     */
    private static AmazonS3Client setAmazonS3Client(CognitoCachingCredentialsProvider credentialsProvider, String region) {
        // Create an S3 client
        AmazonS3Client s3 = new AmazonS3Client(credentialsProvider);
        // Set the region of your S3 bucket
        s3.setRegion(Region.getRegion(Regions.fromName(region)));
        return s3;
    }


    private String getMimeType(String url) {
        try {
            String extension = url.substring(url.lastIndexOf("."));
            String mimeTypeMap = MimeTypeMap.getFileExtensionFromUrl(extension);
            String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(mimeTypeMap);
            if (mimeType == null) {
                Uri uri = Uri.fromFile(new File(url));
                if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
                    ContentResolver cr = context.getContentResolver();
                    mimeType = cr.getType(uri);
                } else {
                    String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                            .toString());
                    mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                            fileExtension.toLowerCase());
                }
                return mimeType;
            }
            return mimeType;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    static void setTransferUtility(Context context) {
        if (amazonS3Client == null)
            amazonS3Client = credentialsProvider(context);
        if (transferUtility == null)
            transferUtility = new TransferUtility(amazonS3Client, context);
    }

    private static String getDuration(Context context, Uri uri) {
        String duration;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        //use one of overloaded setDataSource() functions to set your data source
        retriever.setDataSource(context, uri);
        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        long timeInMillisec = Long.parseLong(time);
        int hrs = (int) TimeUnit.MILLISECONDS.toHours(timeInMillisec) % 24;
        int min = (int) TimeUnit.MILLISECONDS.toMinutes(timeInMillisec) % 60;
        int sec = (int) TimeUnit.MILLISECONDS.toSeconds(timeInMillisec) % 60;
        if (hrs > 0)
            duration = String.format(Locale.getDefault(), "%02d:%02d:%02d", hrs, min, sec);
        else
            duration = String.format(Locale.getDefault(), "%02d:%02d", min, sec);

        return duration;
    }

    private Context context;
    private String destinationPatha;
    private String filename;

    /**
     * This method is used to upload the file to S3 by using TransferUtility class
     *
     * @param filePath = Path to upload file
     */
    public void setFileToUpload(final Context context, final String filePath, final String destinationPath, final String identifier) {
        this.context = context;
        PreferenceUtil preferenceUtil = new PreferenceUtil(context);
        destinationPatha = destinationPath;
        try {
            destinationPatha = preferenceUtil.getBusinessKey() + "/" + preferenceUtil.getUserId() + "/" + destinationPatha;
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(destinationPath) && !destinationPath.endsWith("/")) {
            destinationPatha = destinationPath + "/";
        }
        final File file = (filePath == null || filePath.isEmpty()) ? null : new File(filePath);
        if (file == null || !file.exists()) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                jsonObject.put("state", "failed");
                jsonObject.put("identifier", identifier);
                JSONObject jsondata = new JSONObject();
                jsondata.put("message", "File not available");
                jsondata.put("localFilePath", filePath);
                jsonObject.put("data", jsondata);
                Log.i("S3 FAILURE ", jsonObject.toString());
                TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                setTransferUtility(context);
                filename = file.getName().replaceAll(" ", "_");
                filename = filename.replaceAll("%20", "_");
                filename = filename.replaceAll("%", "_");
                // amazonS3Client.putObject(new PutObjectRequest(amazonAWSBucket, "TrovaAar/" + file.getName(), file).withCannedAcl(CannedAccessControlList.PublicRead));
                TransferObserver transferObserver = transferUtility.upload(
                        amazonAWSBucket,     /* The bucket to upload to */
                        destinationPatha + filename,       /* The key for the uploaded object */
                        file       /* The file where the data to upload exists */
                );

                final String finalFilename = filename;
                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            amazonS3Client.putObject(new PutObjectRequest(amazonAWSBucket, destinationPatha + finalFilename, file).withCannedAcl(CannedAccessControlList.PublicRead));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                thread.start();

                transferObserver.setTransferListener(new TransferListener() {

                    @Override
                    public void onStateChanged(int id, final TransferState state) {
                        Log.e("S3 statechange", state + "");

                        if (state == TransferState.COMPLETED) {
                            JSONObject jsonObject = new JSONObject();
                            try {
                                String mimeType = getMimeType(file.getAbsolutePath());
                                String dur = "";
                                if (mimeType.contains("video/")) {
                                    // thumbFile = saveBitmap(thumbnail, "jpg", String.valueOf(commonDateTimeZone.messageId), context.getString(R.string.trova_base_thumb_folder));
                                    // thumbFilePath = Uri.fromFile(thumbFile).toString();
                                    dur = getDuration(context, Uri.fromFile(file));
                                } else {
                                    // Audio / Documents
                                    if (mimeType.contains("audio/")) {
                                        dur = getDuration(context, Uri.fromFile(file));
                                    } else if (!mimeType.contains("image")) {
                                        mimeType = "doc";
                                    }
                                }

                                Calendar cal = Calendar.getInstance();
                                TimeZone tz = cal.getTimeZone();
                                String timezone = tz.getDisplayName();
                                SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                String currDate = df.format(cal.getTime());
                                df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                                String time = df.format(cal.getTime());
                                if (filename == null)
                                    filename = file.getName().replaceAll(" ", "_");

                                String serverPath = amazonS3Client.getResourceUrl(amazonAWSBucket, destinationPatha + filename);
                                jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                                jsonObject.put("state", "success");

                                if (serverPath.contains("amazonaws.com/")) {
                                    serverPath = serverPath.split("amazonaws.com/")[1];
                                }

                                JSONObject jsondata = new JSONObject();
                                jsondata.put("localFilePath", filePath);
                                jsondata.put("localFilePath", file.getAbsolutePath());
                                jsondata.put("filesize", file.length());
                                jsondata.put("filename", filename);
                                jsondata.put("fileduration", dur);
                                jsondata.put("mimeType", mimeType);
                                jsondata.put("identifier", identifier);
                                String fileExt = (filePath.substring(filePath.lastIndexOf("."))).substring(1);
                                jsondata.put("fileExt", fileExt);
                                jsondata.put("serverPath", serverPath);
                                jsondata.put("messageId", System.currentTimeMillis());
                                jsondata.put("currDate", currDate);
                                jsondata.put("time", time);
                                jsondata.put("timezone", timezone);

                                jsonObject.put("data", jsondata);
                                Log.i("S3 onSuccessResult", jsonObject.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                        } else if (state == TransferState.CANCELED || state == TransferState.FAILED) {
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                                jsonObject.put("state", "failed");
                                JSONObject jsondata = new JSONObject();
                                jsondata.put("localFilePath", file);
                                jsondata.put("identifier", identifier);
                                jsondata.put("message", state.name());
                                jsonObject.put("data", jsondata);
                                Log.i("S3 FAILURE ", jsonObject.toString());
                                TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }


                    @Override
                    public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                        try {
                            final int percentage = (int) (bytesCurrent / bytesTotal * 100);
                            Log.e("percentage", percentage + "");
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                            jsonObject.put("state", InProgress);
                            JSONObject jsondata = new JSONObject();
                            jsondata.put("localFilePath", file.getAbsolutePath());
                            jsondata.put("percentage", percentage);
                            jsondata.put("identifier", identifier);
                            jsonObject.put("data", jsondata);
                            Log.i("S3 percentage ", jsonObject.toString());
                            TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onError(int id, final Exception ex) {
                        Log.e("error", "error");
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                            jsonObject.put("state", "failed");
                            JSONObject jsondata = new JSONObject();
                            jsondata.put("localFilePath", file.getAbsolutePath());
                            jsondata.put("message", ex.getMessage());
                            jsondata.put("identifier", identifier);
                            jsonObject.put("data", jsondata);
                            Log.i("S3 status ", jsonObject.toString());
                            TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }

                });
                if (transferObserver.getState() == TransferState.CANCELED || transferObserver.getState() == TransferState.FAILED) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                        jsonObject.put("state", "failed");
                        JSONObject jsondata = new JSONObject();
                        jsondata.put("identifier", identifier);
                        jsondata.put("localFilePath", file.getAbsolutePath());
                        jsondata.put("message", "File not available");
                        jsonObject.put("data", jsondata);
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else if (transferObserver.getState() == TransferState.COMPLETED) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("trovaEvent", OnTrovaAmazonS3_Upload);
                        jsonObject.put("state", "success");
                        JSONObject jsondata = new JSONObject();
                        jsondata.put("localFilePath", file.getAbsolutePath());
                        jsondata.put("identifier", identifier);
                        if (filename == null)
                            filename = file.getName().replaceAll(" ", "_");

                        String serverPath = amazonS3Client.getResourceUrl(amazonAWSBucket, destinationPatha + filename);
                        if (serverPath.contains("amazonaws.com/")) {
                            serverPath = serverPath.split("amazonaws.com/")[1];
                        }

                        jsondata.put("serverPath", serverPath);
                        jsonObject.put("data", jsondata);
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }

}

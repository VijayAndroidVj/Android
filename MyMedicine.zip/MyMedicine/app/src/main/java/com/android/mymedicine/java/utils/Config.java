package com.android.mymedicine.java.utils;

/**
 * Created by razin on 29/11/17.
 */

public interface Config {
    public static String BASE_URL = "http://oxemate.com/clients/mymedi/";
    public static String API_KEY = "F8t8iEH487zqmrXza349440O6yLQ7kLP";
}

package com.trova.android.trovauiaar.voice;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.GlideDrawableImageViewTarget;
import com.trova.android.trovauiaar.ContactListFragment;
import com.trova.android.trovauiaar.Db.DataBaseHandler;
import com.trova.android.trovauiaar.Globalclass;
import com.trova.android.trovauiaar.R;
import com.trova.android.trovauiaar.Utils.JoinConferenceDialog;
import com.trova.android.trovauiaar.model.UserModel;
import com.trova.android.trovauiaar.service.TrovaService;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import arr.trova.in.trovawoui.BaseActivity;
import arr.trova.in.trovawoui.Utils.PermissionCheck;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnPermissionsRequired;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAcceptedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCallState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCalleeBusy;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveMissedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRejectCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRemoteStream;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.GadgetAgent;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.agentName;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.mainAgent;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.widgetName;
import static com.trova.android.trovauiaar.service.TrovaService.callerName;

public class ReachVoiceCall extends BaseActivity {

    private TextView tv_trova_voice_call_title;
    private TextView tv_trova_voice_call_finding_agents;
    private TextView tv_trova_voice_call_business_name;
    private TextView tv_trova_voice_call_caller_name;
    private TextView tv_trova_voice_call_caller_id;
    private ImageView img_trova_voice_call_speaker;
    private ImageView img_trova_voice_call_mic;
    private ImageView img_trova_voice_call_add;
    private ImageView img_trova_voice_call_video;
    private ImageView img_trova_voice_call_list;
    public ImageView img_trova_voice_call_reject;
    public ImageView img_trova_voice_call_accept;
    private String callType;
    private String otherUserName;
    private static String otherUserID;
    public static String conferenceId;
    private View rlremote1View, rlremote2View;
    public static String agentKey1;
    private boolean isConnected = false, endCallDone = false;
    public HashMap<Integer, String> videoList = new HashMap<>();
    public static ReachVoiceCall reachVoiceCall;
    private boolean isSpeaker;
    private boolean isMicEnabled = true;
    private boolean restrictEscalate;
    private String agentKey;
    private int status;
    private LinearLayout ll_trova_voice_call_details;
    private LinearLayout ll_trova_voice_call_finding_agent;
    private RelativeLayout ll_trova_voice_controls;
    private FrameLayout fl_reach_voice_call_fragment_container;
    private Fragment fragment1 = new ContactListFragment();
    private FragmentTransaction ft;
    private boolean makeAgentCall = false;
    private boolean makeNormalCall = false, isCallstarted = false;
    private String businessName = "";
    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private long[] vibratepattern = {0, 200, 600};
    ImageView giv_calling;
    private RelativeLayout rl_call_accepted;
    public static boolean isVoiceCallAlive = false;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private DataBaseHandler dataBaseHandler;
    private ImageView ivMic1, ivMic2;
    private TextView txtVideo2Name;

    ProgressBar mProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Globalclass.trovaSDK_init != null)
            Globalclass.trovaSDK_init.trovaSession_Connect();
        reachVoiceCall = this;
        isVoiceCallAlive = true;
        super.onCreate(savedInstanceState);
        dataBaseHandler = DataBaseHandler.getInstance(activity);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
//        createNotification();
    }

    void setProgress() {
        Resources res = getResources();
        Drawable drawable = res.getDrawable(R.drawable.circular_loader);
        mProgress.setVisibility(View.VISIBLE);
        mProgress.setProgress(0);   // Main Progress
        mProgress.setSecondaryProgress(100); // Secondary Progress
        mProgress.setMax(100); // Maximum Progress
        mProgress.setProgressDrawable(drawable);
    }

    private String escalatedUserId = "";

  /*  public static ReachEscalationCallBack reachEscalationCallBack = new ReachEscalationCallBack() {
        @Override
        public void setReachEscalationCallBack(JSONObject jsonObject) {
            try {
                String contact_name = jsonObject.getString("contact_name");
                String contact_number = jsonObject.getString("contact_number");
                String contact_user_id = jsonObject.getString("contact_user_id");
                JSONObject sendNotificationObject = new JSONObject();
                sendNotificationObject.put("agentKey", ReachVoiceCall.reachVoiceCall.agentKey);
                sendNotificationObject.put("event", "onJoinConferenceRequest");
                sendNotificationObject.put("displayName", ReachVoiceCall.reachVoiceCall.businessName);
                sendNotificationObject.put("callMode", "audio");
                sendNotificationObject.put("callbackTime", System.currentTimeMillis());
                sendNotificationObject.put("widgetUserName", ReachVoiceCall.reachVoiceCall.otherUserName);
                sendNotificationObject.put("agentUserName", ReachVoiceCall.reachVoiceCall.preferenceUtil.getUserName());
                sendNotificationObject.put("agentUserId", ReachVoiceCall.reachVoiceCall.preferenceUtil.getUserId());
                sendNotificationObject.put("widgetUserId", ReachVoiceCall.reachVoiceCall.otherUserID);
                Globalclass.trovaSDK_init.trovaAddToConference(contact_user_id, sendNotificationObject.toString());

                if (!TextUtils.isEmpty(mainAgent)) {
                    mainAgent = ReachVoiceCall.reachVoiceCall.preferenceUtil.getUserId();
                    GadgetAgent = ReachVoiceCall.reachVoiceCall.otherUserID;
                }
                ReachVoiceCall.reachVoiceCall.escalatedUserId = contact_user_id;
                agentName = contact_name;
                ReachVoiceCall.reachVoiceCall.restrictEscalate = true;
                Toast.makeText(ReachVoiceCall.reachVoiceCall, contact_name + " escalated successfully", Toast.LENGTH_SHORT).show();
                ReachVoiceCall.reachVoiceCall.countDownTimer.start();
                ReachVoiceCall.reachVoiceCall.img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_disabled);
                ReachVoiceCall.reachVoiceCall.setProgress();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };*/

    private boolean isEscalationCancelled = true;

    CountDownTimer countDownTimer = new

            CountDownTimer(30000, 1000) {

                public void onTick(long millisUntilFinished) {
                    Log.i("CountDownTimer:", "seconds remaining: " + millisUntilFinished / 1000);
                    if (millisUntilFinished / 1000 == 0) {
                        isEscalationCancelled = true;
                    }
                    int progress = (int) (((Double.valueOf(millisUntilFinished) / 30000) * 100));
                    Log.i("CountDown:", "percentage: " + progress);
                    mProgress.setProgress(mProgress.getMax() - progress);
                }

                public void onFinish() {
                    if (isEscalationCancelled) {
                        restrictEscalate = false;
                        img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                        mProgress.setVisibility(View.GONE);
                        Toast.makeText(activity, agentName + " Missed Escalation", Toast.LENGTH_SHORT).show();
                    }

                }
            };

    public static String md5(String in) {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
            digest.reset();
            digest.update(in.getBytes());
            byte[] a = digest.digest();
            int len = a.length;
            StringBuilder sb = new StringBuilder(len << 1);
            for (int i = 0; i < len; i++) {
                sb.append(Character.forDigit((a[i] & 0xf0) >> 4, 16));
                sb.append(Character.forDigit(a[i] & 0x0f, 16));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (permissionGranted) {
            permissionGranted = false;
            setContentView(R.layout.activity_trova_voice_coference_call);
            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
//            ContactListFragment.setCallBack(reachEscalationCallBack);
            callType = getIntent().getStringExtra("callType");
//        Toast.makeText(this,"calltype : "+callType,Toast.LENGTH_SHORT).show();
            status = getIntent().getIntExtra("status", 0);
            restrictEscalate = getIntent().getBooleanExtra("restrictEscalate", false);

            if (status == 1) {
                if (getIntent().hasExtra("agentKey")) {
                    agentKey = getIntent().getStringExtra("agentKey");
                }
            } else {
                if (getIntent().hasExtra("otherUserID")) {
                    otherUserID = getIntent().getStringExtra("otherUserID");
                }
            }
            if (getIntent().hasExtra("otherUserName")) {
                if (TextUtils.isEmpty(otherUserID))
                    otherUserName = dataBaseHandler.getUserName(otherUserID);
                if (TextUtils.isEmpty(otherUserName))
                    otherUserName = getIntent().getStringExtra("otherUserName");
            }
            if (getIntent().hasExtra("businessName")) {
                businessName = getIntent().getStringExtra("businessName");
            }

            if (agentKey != null && !agentKey.equalsIgnoreCase("")) {
                agentKey1 = agentKey;
                if (!TextUtils.isEmpty(otherUserID))
                    conferenceId = md5(preferenceUtil.getBusinessKey() + otherUserID);
            }
            setInitUI();
            setRegisterUI();
            handleCallViews();
        }

        if (isConnected) {
            registerSensor();
        }
    }


    private void onfinish() {
        if (isTaskRoot()) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                finishAndRemoveTask();
            } else {
                finish();
            }
        } else {
            finish();
        }
    }

    private boolean isRejected = false;
    private boolean isdestroy = false;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        initDestroy();
    }

    @Override
    protected void onPause() {
//        if (mSensorManager != null) {
//            mSensorManager.unregisterListener(sensorEventListener,mSensor);
//        }
//        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
//        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
//        PowerManager pm = (PowerManager) this.getSystemService(POWER_SERVICE);
//        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "tag");
//        wl.acquire();
        super.onPause();

        initDestroy();

    }

    private void initDestroy() {
        TrovaService.stopProximity();

        if (isFinishing() || isdestroy) {
            try {
                isVoiceCallAlive = false;
                conferenceId = null;
                agentKey1 = null;
                reachVoiceCall = null;
                otherUserID = null;
                mHandler.removeCallbacks(mUpdateTimeTask);
                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        if (!endCallDone)
                            if (Globalclass.trovaSDK_init != null) {
                                endCallDone = true;
                                Globalclass.trovaSDK_init.trovaCall_End("audio", otherUserID);
                            }
                    } else if (!isRejected) {
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_Reject("audio", otherUserID);
                    }
                }
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (TrovaService.notificationManager != null) {
                    TrovaService.notificationManager.cancelAll();
                }
                if (TrovaService.userNotif != null) {
                    TrovaService.userNotif = null;
                }
                callerName = "";
                stopCallerTone();
                stopBusyTone();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private Handler mCallingHandler1 = new Handler();
    private int callingTxtCount = 1;
    /**
     * Background Runnable thread
     */
    private Runnable mUpdateCalling = new Runnable() {
        public void run() {
            switch (callingTxtCount) {
                case 0:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s", getString(R.string.finding_agents)));
                    callingTxtCount = 1;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                case 1:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s.", getString(R.string.finding_agents)));
                    callingTxtCount = 2;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                case 2:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s..", getString(R.string.finding_agents)));
                    callingTxtCount = 3;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                default:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s...", getString(R.string.finding_agents)));
                    callingTxtCount = 0;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
            }
        }
    };

    private void handleCallViews() {
        ll_trova_voice_controls.setVisibility(View.GONE);
        giv_calling.setVisibility(View.VISIBLE);

        GlideDrawableImageViewTarget yourimageViewTarget = new GlideDrawableImageViewTarget(giv_calling);
        Glide.with(activity).load(R.drawable.calling_blue).into(yourimageViewTarget);

        rl_call_accepted.setVisibility(View.GONE);
        img_trova_voice_call_speaker.setVisibility(View.GONE);
        img_trova_voice_call_mic.setVisibility(View.GONE);

        if (status == 1) {
            ll_trova_voice_call_details.setVisibility(View.GONE);
            ll_trova_voice_call_finding_agent.setVisibility(View.VISIBLE);
            tv_trova_voice_call_finding_agents.setText(getString(R.string.finding_agents));
            mCallingHandler1.postDelayed(mUpdateCalling, 1000);

            if (!TextUtils.isEmpty(TrovaService.displaynameHashmap.get(otherUserID))) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(TrovaService.displaynameHashmap.get(otherUserID));
                tv_trova_voice_call_caller_name.setText(callerName);
                tv_trova_voice_call_caller_id.setText("");
            }

        } else {
            ll_trova_voice_call_finding_agent.setVisibility(View.GONE);
            ll_trova_voice_call_details.setVisibility(View.VISIBLE);
            if (!TextUtils.isEmpty(TrovaService.displaynameHashmap.get(otherUserID))) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(TrovaService.displaynameHashmap.get(otherUserID));
                tv_trova_voice_call_caller_name.setText(callerName);
                tv_trova_voice_call_caller_id.setText("");
            } else {
                tv_trova_voice_call_business_name.setVisibility(View.GONE);
                if (TextUtils.isEmpty(otherUserName)) {
                    otherUserName = dataBaseHandler.getUserName(otherUserID);
                }
                if (otherUserName == null || otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                    tv_trova_voice_call_caller_name.setText(otherUserID);
                    tv_trova_voice_call_caller_id.setText("");
                } else {
                    tv_trova_voice_call_caller_name.setText(otherUserName);
                    tv_trova_voice_call_caller_id.setText(otherUserID);
                }
            }
        }
        if (callType.equals("answer")) {
            setRinger();
            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
            img_trova_voice_call_accept.setVisibility(View.VISIBLE);
            tv_trova_voice_call_title.setText("Incoming");
        } else if (callType.equalsIgnoreCase("in_call")) {
            if (businessName != null && !businessName.isEmpty()) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(businessName);
                otherUserName = widgetName;
                if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                    tv_trova_voice_call_caller_name.setText(otherUserID);
                    tv_trova_voice_call_caller_id.setText("");
                } else {
                    tv_trova_voice_call_caller_name.setText(otherUserName);
                    tv_trova_voice_call_caller_id.setText("");
                }

            } else {
                tv_trova_voice_call_business_name.setVisibility(View.GONE);
                tv_trova_voice_call_caller_id.setText(otherUserID);
            }
            ll_trova_voice_controls.setVisibility(View.VISIBLE);
            giv_calling.setVisibility(View.GONE);
            rl_call_accepted.setVisibility(View.VISIBLE);
            img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
            img_trova_voice_call_mic.setVisibility(View.VISIBLE);
            img_trova_voice_call_accept.setVisibility(View.GONE);
            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
//            if (agentKey != null && !agentKey.equalsIgnoreCase("")) {
//                Globalclass.trovaSDK_init.trovaAgentCall_Init(this, "audio", agentKey, otherUserID);
            Globalclass.trovaSDK_init.trovaCall_Answer("audio", otherUserID);
//            }
            tv_trova_voice_call_title.setText("In-Call");
            isConnected = true;
        } else {
            if (businessName != null && !businessName.isEmpty()) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(businessName);

                if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                    tv_trova_voice_call_caller_name.setText(otherUserID);
                    tv_trova_voice_call_caller_id.setText("");
                } else {
                    tv_trova_voice_call_caller_name.setText(otherUserName);
                    tv_trova_voice_call_caller_id.setText("");
                }

            } else {
                tv_trova_voice_call_business_name.setVisibility(View.GONE);
                if (TextUtils.isEmpty(otherUserName)) {
                    otherUserName = dataBaseHandler.getUserName(otherUserID);
                } else {
                    tv_trova_voice_call_caller_name.setText(otherUserName);
                    tv_trova_voice_call_caller_id.setText(otherUserID);
                }

            }
            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
            img_trova_voice_call_accept.setVisibility(View.GONE);
            tv_trova_voice_call_title.setText("Calling");
            UserModel userModel = new UserModel();
            if (status == 1) {
                if (Globalclass.trovaSDK_init != null)
                    makeAgentCall = Globalclass.trovaSDK_init.trovaGadgetCall_Init(activity, "audio", agentKey);
                userModel.setAgentKey(agentKey);
                userModel.setDisplayName(businessName);
            } else if (status == 2) {
                if (Globalclass.trovaSDK_init != null)
                    makeAgentCall = Globalclass.trovaSDK_init.trovaAgentCall_Init(activity, "audio", otherUserID, "", false, agentKey);
                userModel.setAgentKey(agentKey);
                userModel.setDisplayName(businessName);
            } else {
                if (Globalclass.trovaSDK_init != null)
                    makeNormalCall = Globalclass.trovaSDK_init.trovaCall_Init(activity, "audio", otherUserID);
            }
            if (makeAgentCall || makeNormalCall) {
                playCallerTone();
            }
            registerSensor();
        }
        if (getIntent().hasExtra("action")) {
            if (getIntent().getStringExtra("action").equalsIgnoreCase("accept_call")) {
                img_trova_voice_call_accept.callOnClick();
            }
        }
    }

    private void registerSensor() {
//                if (mSensorManager != null) {
//                    mSensorManager.registerListener(sensorEventListener, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
//                }
        TrovaService.startProximity();
    }

    private Handler mainThreadHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer m; /*assume, somewhere in the global scope...*/
    private MediaPlayer mbusy;
    private Runnable delayedTask;

    private void stopCallerTone() {
        try {
            mainThreadHandler.removeCallbacks(delayedTask);
            if (m != null && m.isPlaying()) {
                m.stop();
                m.release();
                m = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void stopBusyTone() {
        try {
            if (mbusy != null && mbusy.isPlaying()) {
                mbusy.stop();
                mbusy.release();
                mbusy = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void playCallBusyTone() {
        try {
            if (mbusy == null) {
                mbusy = new MediaPlayer();
                AssetFileDescriptor descriptor = getAssets().openFd("phone_busy.mp3");
                mbusy.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                descriptor.close();
                mbusy.prepare();
                mbusy.setVolume(1f, 1f);
                mbusy.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void playCallerTone() {
        try {
            if (m == null) {
                m = new MediaPlayer();
                AssetFileDescriptor descriptor = getAssets().openFd("ringing.mp3");
                m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                m.setAudioStreamType(AudioManager.STREAM_VOICE_CALL);
                descriptor.close();

                m.prepare();
                m.setVolume(1f, 1f);
                m.setLooping(true);
                m.start();

                delayedTask = new Runnable() {
                    @Override
                    public void run() {
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_InitMissedCall("audio", otherUserID);
                        onfinish();
                    }

                };
                mainThreadHandler.postDelayed(delayedTask, 30000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setRinger() {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);

            if (notification == null) {
                // alert is null, using backup
                notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                if (notification == null) {
                    // I can't see this ever being null (as always have a default
                    // notification) but just incase alert backup is null, using 2nd backup
                    notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                }
            }

            AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            switch (audio.getRingerMode()) {
                case AudioManager.RINGER_MODE_NORMAL:
                    try {
                        mediaPlayer = MediaPlayer.create(getApplicationContext(), notification);
                        mediaPlayer.setLooping(true);
                        mediaPlayer.start();
                        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        vibrator.vibrate(vibratepattern, 0);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case AudioManager.RINGER_MODE_SILENT:
                    break;
                case AudioManager.RINGER_MODE_VIBRATE:
                    vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    vibrator.vibrate(vibratepattern, 0);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void setRegisterUI() {

        try {
            AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
            am.setMode(AudioManager.STREAM_VOICE_CALL);
            am.setSpeakerphoneOn(false);
        } catch (Exception e) {

            e.printStackTrace();
        }
        img_trova_voice_call_speaker.setImageResource(R.drawable.ic_volume_off_black_24dp);
        isSpeaker = true;

        img_trova_voice_call_speaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isSpeaker) {
                    try {
                        AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                        am.setMode(AudioManager.STREAM_VOICE_CALL);
                        am.setSpeakerphoneOn(true);
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
                    img_trova_voice_call_speaker.setImageResource(R.drawable.ic_volume_up_black_24dp);
                    isSpeaker = false;
                } else {
                    try {
                        AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                        am.setMode(AudioManager.STREAM_VOICE_CALL);
                        am.setSpeakerphoneOn(false);
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
                    img_trova_voice_call_speaker.setImageResource(R.drawable.ic_volume_off_black_24dp);
                    isSpeaker = true;
                }

            }
        });
        img_trova_voice_call_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Globalclass.trovaSDK_init != null)
                    Globalclass.trovaSDK_init.trovaMicMute(isMicEnabled);
                isMicEnabled = !isMicEnabled;
                if (isMicEnabled) {
                    img_trova_voice_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);
                } else {
                    img_trova_voice_call_mic.setImageResource(R.drawable.ic_mic_off_black_24dp);
                }

                try {
                    JSONObject nuserObj = new JSONObject();
                    nuserObj.put("event", isMicEnabled ? "micon" : "micoff");
                    nuserObj.put("userId", preferenceUtil.getUserId());
                    if (Globalclass.trovaSDK_init != null)
                        Globalclass.trovaSDK_init.trovaXmit_Notification(otherUserID, nuserObj.toString(), "high", 0, "", "");
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
        img_trova_voice_call_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TrovaService.notificationManager != null) {
                    TrovaService.notificationManager.cancelAll();
                }
                if (TrovaService.userNotif != null) {
                    TrovaService.userNotif = null;
                }
                reachVoiceCall = null;
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                stopCallerTone();
                stopBusyTone();
                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        endCallDone = true;
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaCall_End("audio", otherUserID);
//                        postEvent(POSTENDCALL);
                    } else {
                        isRejected = true;
                        if (callType.equals("answer")) {
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaCall_Reject("audio", otherUserID);
//                            postEvent(POSTREJECTCALL);
                        } else {
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaCall_InitMissedCall("audio", otherUserID);
//                            postEvent(POSTMISSEDCALL);
                            onfinish();
                        }
                    }
                }
                onfinish();
            }
        });
        img_trova_voice_call_accept.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View view) {
                if (TrovaService.notificationManager != null)
                    TrovaService.notificationManager.cancel(0);
                TrovaService.createInCallNotification(otherUserName, otherUserID, "audio");

                stopCallerTone();
                stopBusyTone();

                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (Globalclass.trovaSDK_init != null) {
                    Globalclass.trovaSDK_init.trovaCall_Answer("audio", otherUserID);
                }
//                postEvent(POSTANSWERCALL);
                runOnUiThread(new Runnable() {
                    public void run() {
                        tv_trova_voice_call_caller_id.setVisibility(View.VISIBLE);
                        tv_trova_voice_call_caller_id.setText("connecting...");
                        rl_call_accepted.setVisibility(View.VISIBLE);
                        giv_calling.setVisibility(View.GONE);
                        ll_trova_voice_controls.setVisibility(View.VISIBLE);
                        img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
                        img_trova_voice_call_mic.setVisibility(View.VISIBLE);
                        img_trova_voice_call_accept.setVisibility(View.GONE);
                        img_trova_voice_call_reject.setVisibility(View.VISIBLE);
                        tv_trova_voice_call_title.setText("In-Call");
                        isConnected = true;
//                        Globalclass.trovaSDK_init.trovaUnMuteAudioStream();
                        try {
                            AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                            am.setMode(AudioManager.STREAM_VOICE_CALL);
                            am.setSpeakerphoneOn(false);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                registerSensor();
            }
        });
        img_trova_voice_call_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(agentKey))
                    if (ll_trova_voice_controls.getVisibility() == View.VISIBLE && !restrictEscalate) {
                        fl_reach_voice_call_fragment_container.setVisibility(View.VISIBLE);
                        ft = getFragmentManager().beginTransaction();
                        ft.replace(R.id.fl_reach_voice_call_fragment_container, fragment1).commit();
                    }
            }
        });


//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        }, 2000);

    }

    @Override
    public void onBackPressed() {
        if (fl_reach_voice_call_fragment_container.getVisibility() == View.VISIBLE) {
            fl_reach_voice_call_fragment_container.setVisibility(View.GONE);
        } else {
//            super.onBackPressed();
        }
    }

    private void setInitUI() {
        giv_calling = findViewById(R.id.giv_calling);
        rl_call_accepted = findViewById(R.id.rl_call_accepted);
        tv_trova_voice_call_title = findViewById(R.id.tv_trova_voice_call_title);
        tv_trova_voice_call_finding_agents = findViewById(R.id.tv_trova_voice_call_finding_agents);
        tv_trova_voice_call_business_name = findViewById(R.id.tv_trova_voice_call_business_name);
        tv_trova_voice_call_caller_name = findViewById(R.id.tv_trova_voice_call_caller_name);
        tv_trova_voice_call_caller_id = findViewById(R.id.tv_trova_voice_call_caller_id);
        img_trova_voice_call_speaker = findViewById(R.id.img_trova_voice_call_speaker);
        img_trova_voice_call_mic = findViewById(R.id.img_trova_voice_call_mic);
        img_trova_voice_call_add = findViewById(R.id.img_trova_voice_call_add);
        img_trova_voice_call_video = findViewById(R.id.img_trova_voice_call_video);
        img_trova_voice_call_list = findViewById(R.id.img_trova_voice_call_list);
        img_trova_voice_call_reject = findViewById(R.id.img_trova_voice_call_reject);
        img_trova_voice_call_accept = findViewById(R.id.img_trova_voice_call_accept);
        ll_trova_voice_call_details = findViewById(R.id.ll_trova_voice_call_details);
        ll_trova_voice_call_finding_agent = findViewById(R.id.ll_trova_voice_call_finding_agent);
        ll_trova_voice_controls = findViewById(R.id.rl_trova_voice_controls);

        ivMic1 = findViewById(R.id.ivMic1);
        ivMic2 = findViewById(R.id.ivMic2);
        ivMic1.setVisibility(View.GONE);
        txtVideo2Name = findViewById(R.id.txtVideo2Name);

        rlremote1View = findViewById(R.id.rlremote1View);
        rlremote2View = findViewById(R.id.rlremote2View);

        rlremote1View.setVisibility(View.GONE);
        rlremote2View.setVisibility(View.GONE);

        fl_reach_voice_call_fragment_container = findViewById(R.id.fl_reach_voice_call_fragment_container);
        mProgress = (ProgressBar) findViewById(R.id.circularProgressbar);
//        ll_trova_voice_controls.setBackground(new SemiCircleDrawable());
//        GifImageButton gib = new GifImageButton(this);
//        setContentView(gib);
//        gib.setImageResource(R.drawable.sample);
//        final MediaController mc = new MediaController(this);
//        mc.setMediaPlayer((GifDrawable) gib.getDrawable());
//        mc.setAnchorView(gib);
//        gib.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mc.show();
//            }
//        });
    }

    private Handler mHandler = new Handler();
    private long startTime;
    /**
     * Background Runnable thread
     */
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            long millisUntilFinished = System.currentTimeMillis() - startTime;

            tv_trova_voice_call_caller_id.setText(String.format(Locale.getDefault(), "%s %02d:%02d:%02d", "Call duration",
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            // Running this thread after 100 milliseconds
            mHandler.postDelayed(this, 1000);
        }
    };

    public void TrovaEvents(final JSONObject jsonObject) {

        String event;
        try {
            event = jsonObject.getString("trovaEvent");
            switch (event) {
                case "onMissedEscalation":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                                Toast.makeText(activity, agentName + " missed escalation", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (escalatedUserId != null && callerId.equalsIgnoreCase(escalatedUserId)) {
                                restrictEscalate = false;
                                isEscalationCancelled = true;
                                img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                                mProgress.setVisibility(View.GONE);
                            }
                        }
                    });
                    break;
                case "onCancelEscalation":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                                Toast.makeText(activity, agentName + " rejected escalation", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (escalatedUserId != null && callerId.equalsIgnoreCase(escalatedUserId)) {
                                restrictEscalate = false;
                                isEscalationCancelled = true;
                                img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                                mProgress.setVisibility(View.GONE);
                            }
                        }
                    });
                    break;
                case "micoff":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if (TextUtils.isEmpty(GadgetAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                ivMic1.setImageResource(R.drawable.ic_mic_off);
                            } else {
                                ivMic2.setImageResource(R.drawable.ic_mic_off);
                            }
                        }
                    });

                    break;
                case "micon":
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            String callerId = null;
                            try {
                                callerId = jsonObject.get("callerId").toString();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if (TextUtils.isEmpty(GadgetAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                ivMic1.setImageResource(R.drawable.ic_mic_on);
                            } else {
                                ivMic2.setImageResource(R.drawable.ic_mic_on);
                            }
                        }
                    });

                    break;
                case OnTrovaReceiveCalleeBusy:
                    String callerId = jsonObject.get("callerId").toString();
                    if (callerId.equalsIgnoreCase(otherUserID)) {
                        stopCallerTone();
                        Toast.makeText(activity, callerId + " is Busy right now", Toast.LENGTH_LONG).show();
                        playCallBusyTone();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                onfinish();
                            }
                        }, 2000);
                    }
                    break;
                case OnTrovaAgentInfo:
                    String callMode = jsonObject.getString("callMode");
                    if (callMode.equalsIgnoreCase("audio")) {
                        callerId = jsonObject.getString("callerId");
                        String agentName = jsonObject.getString("agentName");
                        String businessName = jsonObject.getString("displayName");
                        otherUserID = callerId;
                        if (TextUtils.isEmpty(otherUserID))
                            otherUserName = dataBaseHandler.getUserName(otherUserID);
                        if (TextUtils.isEmpty(otherUserName))
                            otherUserName = agentName;
                        conferenceId = md5(preferenceUtil.getBusinessKey() + otherUserID);
                        ll_trova_voice_call_finding_agent.setVisibility(View.GONE);
                        ll_trova_voice_call_details.setVisibility(View.VISIBLE);
                        mCallingHandler1.removeCallbacks(mUpdateCalling);
                        if (businessName != null && !businessName.isEmpty()) {
                            tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_business_name.setText(businessName);
                        } else {
                            tv_trova_voice_call_business_name.setVisibility(View.GONE);
                        }
                        if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                            tv_trova_voice_call_caller_name.setText(otherUserID);
                            tv_trova_voice_call_caller_id.setText("");
                        } else {
                            tv_trova_voice_call_caller_name.setText(otherUserName);
                            tv_trova_voice_call_caller_id.setText(otherUserID);
                        }
                    }

                    break;
                case OnTrovaReceiveMissedCall:
                    reachVoiceCall = null;
                    if (TrovaService.notificationManager != null) {
                        TrovaService.notificationManager.cancelAll();
                    }
                    if (TrovaService.userNotif != null) {
                        TrovaService.userNotif = null;
                    }
                    isRejected = true;
                    try {
                        String callerid = jsonObject.get("callerId").toString();
                        callMode = jsonObject.get("callMode").toString();
                        if (TextUtils.isEmpty(otherUserID) || callerid.equalsIgnoreCase(otherUserID) && callMode.equalsIgnoreCase("audio")) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    mHandler.removeCallbacks(mUpdateTimeTask);
//                            if(SP.isApplicationLaunched) {
                                    stopCallerTone();
                                    stopBusyTone();
                                    GadgetAgent = "";
                                    mainAgent = "";
                                    JoinConferenceDialog.agentName = "";
                                    JoinConferenceDialog.widgetName = "";
                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            isdestroy = true;
                                            onPause();
                                            onfinish();
                                        }
                                    }, 1500);
//                            } else {
//                                finishAndRemoveTask();
//                            }
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case OnTrovaReceiveRemoteStream:
                    String callerPhone = jsonObject.getString("callerId").trim();
                    if (!videoList.containsValue(callerPhone)) {
                        videoList.put(videoList.size(), callerPhone);
                    }
                    if (videoList.size() == 1) {
                        ivMic1.setVisibility(View.VISIBLE);
                        ivMic1.setImageResource(R.drawable.ic_mic_on);
                    } else if (videoList.size() == 2) {
                        isEscalationCancelled = false;
                        countDownTimer.cancel();
                        restrictEscalate = true;
                        img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_disabled);
                        rlremote1View.setVisibility(View.VISIBLE);
                        rlremote2View.setVisibility(View.VISIBLE);
                        txtVideo2Name.setText(JoinConferenceDialog.agentName);
                        ivMic2.setImageResource(R.drawable.ic_mic_on);
                    }

                    break;
                case OnTrovaReceiveEndCall:
                    runOnUiThread(new Runnable() {
                        public void run() {
                            try {
                                String callMode = jsonObject.getString("callMode");
                                if (callMode.equalsIgnoreCase("audio")) {
                                    String callerId = jsonObject.getString("callerId");
                                    if (TextUtils.isEmpty(agentKey) || callerId.equalsIgnoreCase(otherUserID) || callerId.equalsIgnoreCase(mainAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                        endCallDone = true;
                                        Globalclass.trovaSDK_init.trovaCall_End("audio", otherUserID);
                                        if (TrovaService.notificationManager != null) {
                                            TrovaService.notificationManager.cancelAll();
                                        }
                                        if (TrovaService.userNotif != null) {
                                            TrovaService.userNotif = null;
                                        }
                                        reachVoiceCall = null;
                                        mHandler.removeCallbacks(mUpdateTimeTask);
                                        setResult(RESULT_CANCELED);
                                        stopCallerTone();
                                        stopBusyTone();
                                        isdestroy = true;
                                        onPause();
                                        onfinish();
                                    } else {
                                        isEscalationCancelled = true;
                                        restrictEscalate = false;
                                        img_trova_voice_call_add.setBackgroundResource(R.drawable.rounded_corner_button_color);
                                        mProgress.setVisibility(View.GONE);
                                        rlremote2View.setVisibility(View.GONE);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    break;

                case OnTrovaReceiveRejectCall:
                    runOnUiThread(new Runnable() {
                        public void run() {
                            reachVoiceCall = null;
                            if (TrovaService.notificationManager != null)
                                TrovaService.notificationManager.cancel(0);
                            mHandler.removeCallbacks(mUpdateTimeTask);
                            otherUserID = "";
//                            if(SP.isApplicationLaunched) {
                            setResult(RESULT_CANCELED);
                            stopCallerTone();
                            stopBusyTone();
                            isdestroy = true;
                            onPause();
                            onfinish();
//                            } else {
//                                finishAndRemoveTask();
//                            }
                        }
                    });
                    break;

                case OnTrovaAcceptedCall:
                    stopCallerTone();
                    stopBusyTone();
                    isCallstarted = true;
                    callMode = jsonObject.getString("callMode");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            TrovaService.createInCallNotification(otherUserName, otherUserID, "audio");
                            giv_calling.setVisibility(View.GONE);
                            ivMic1.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_caller_id.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_caller_id.setText("connecting...");
                            ll_trova_voice_controls.setVisibility(View.VISIBLE);
                            rl_call_accepted.setVisibility(View.VISIBLE);
                            img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
                            img_trova_voice_call_mic.setVisibility(View.VISIBLE);
                            img_trova_voice_call_accept.setVisibility(View.GONE);
                            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_title.setText("In-Call");
                            isConnected = true;
                        }
                    });
                    if (callMode.equalsIgnoreCase("audio")) {
                        callerId = jsonObject.getString("callerId");
                        if (!callerId.equalsIgnoreCase(otherUserID)) {
                            isEscalationCancelled = false;
                            countDownTimer.cancel();
                        }
                    }
                    break;
                case OnTrovaCallState:
                    String status = null;
                    try {
                        status = jsonObject.getString("status");
                        if (status.equalsIgnoreCase("connected")) {
                            if (!isCallstarted) {
                                isCallstarted = true;
                                stopCallerTone();
                                stopBusyTone();
                                runOnUiThread(new Runnable() {
                                    public void run() {
                                        TrovaService.createInCallNotification(otherUserName, otherUserID, "audio");
                                        giv_calling.setVisibility(View.GONE);
                                        ivMic1.setVisibility(View.VISIBLE);
                                        ll_trova_voice_controls.setVisibility(View.VISIBLE);
                                        rl_call_accepted.setVisibility(View.VISIBLE);
                                        img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
                                        img_trova_voice_call_mic.setVisibility(View.VISIBLE);
                                        img_trova_voice_call_accept.setVisibility(View.GONE);
                                        img_trova_voice_call_reject.setVisibility(View.VISIBLE);
                                        tv_trova_voice_call_title.setText("In-Call");
                                        isConnected = true;
                                        if (Globalclass.trovaSDK_init != null)
                                            Globalclass.trovaSDK_init.trovaAudioMute(false);
                                    }
                                });
                            }
                            if (startTime == 0) {
                                startTime = System.currentTimeMillis();
                                mHandler.postDelayed(mUpdateTimeTask, 100);
                            }
                        } else if (status.equalsIgnoreCase("failed")) {
                            callerId = jsonObject.has("callerId") ? jsonObject.getString("callerId") : "";
                            if (TextUtils.isEmpty(agentKey) || callerId.equalsIgnoreCase(otherUserID) || callerId.equalsIgnoreCase(mainAgent) || callerId.equalsIgnoreCase(GadgetAgent)) {
                                endCallDone = true;
                                if (TrovaService.notificationManager != null) {
                                    TrovaService.notificationManager.cancelAll();
                                }
                                if (TrovaService.userNotif != null) {
                                    TrovaService.userNotif = null;
                                }
                                Toast.makeText(activity, "Call unexpectedly stopped", Toast.LENGTH_SHORT).show();
                                reachVoiceCall = null;
                                mHandler.removeCallbacks(mUpdateTimeTask);
                                setResult(RESULT_CANCELED);
                                isdestroy = true;
                                stopCallerTone();
                                stopBusyTone();
                                onPause();
                                onfinish();
                            }
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    break;

                case OnPermissionsRequired:
                    Toast.makeText(activity, "Permission Required", Toast.LENGTH_SHORT).show();
                    PermissionCheck.requestPermission(activity, PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions()), 1000);
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

//    public static void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
//        trovaUICallBack = trovaUIAPICallBack;
//    }

//    private void postEvent(String event) {
//        if (trovaUICallBack != null) {
//            JSONObject jobj = new JSONObject();
//            try {
//                jobj.put("trovaEvent", event);
//                jobj.put("callerId", otherUserID);
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//            trovaUICallBack.setTrovaUICallBack(jobj);
//        }
//    }
}

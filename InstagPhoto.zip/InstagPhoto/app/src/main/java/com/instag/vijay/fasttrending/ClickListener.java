package com.instag.vijay.fasttrending;

import android.view.View;

/**
 * Created by vijay on 21/1/18.
 */

public interface ClickListener {
    public void onClick(View view, int position);

    public void onLongClick(View view, int position);
}

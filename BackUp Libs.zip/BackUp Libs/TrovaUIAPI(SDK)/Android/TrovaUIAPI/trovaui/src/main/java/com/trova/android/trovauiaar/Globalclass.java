package com.trova.android.trovauiaar;

import arr.trova.in.trovawoui.trovaSDK_Init;

/**
 * Created by vijay on 17/11/17.
 */

public class Globalclass {
    public static trovaSDK_Init trovaSDK_init;
}

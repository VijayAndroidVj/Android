package arr.trova.in.trovawoui;

/**
 * Created by vijay on 1/5/18.
 */

public class ConfigServer {
    //Debug
    public static String FcmServerKey = Constants.serverKeyDeBug + "/ClickToCall/";
    //live
//    public static String FcmServerKey = Constants.serverKeyLive + "/newcontrollers/ClickToCall/";
}

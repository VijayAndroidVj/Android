package arr.trova.in.trovawoui.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera1Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.StatsObserver;
import org.webrtc.StatsReport;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import arr.trova.in.trovawoui.ConfigServer;
import arr.trova.in.trovawoui.services.TrovaApiService;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCallState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveLocalStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRemoteStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveScreenShareStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaScreenShareState;
import static arr.trova.in.trovawoui.services.TrovaApiService.DEBUG;

public class RTCConnection {
    private static final String VIDEO_TRACK_ID = "ARDAMSv0";
    private static final String AUDIO_TRACK_ID = "ARDAMSa0";
    private static final String VIDEO_CODEC = "VP8";
    private static final String AUDIO_CODEC = "ISAC";
    public boolean isSdpSent = false;
    /*String CONFIGURATION="{\"iceServers\": [{\"urls\": [\"stun:turn01.uswest.xirsys.com\"]},{" +
            "\"urls\": [\"turn:turn01.uswest.xirsys.com:80?transport=udp\",\"turn:turn01.uswest.xirsys.com:3478?transport=udp\",\"turn:turn01.uswest.xirsys.com:80?transport=tcp\",\"turn:turn01.uswest.xirsys.com:3478?transport=tcp\",\"turns:turn01.uswest.xirsys.com:443?transport=tcp\",\"turns:turn01.uswest.xirsys.com:5349?transport=tcp\"],\"credential\": \"1195bde6-e20d-11e6-8978-4959f85e5474\","+
            "\"username\": \"1195bcb0-e20d-11e6-9d3f-6b7ba054864f\"}]}";*/
    public HashMap<String, PeerConnection> peerConnectionMap = new HashMap<>();
    public HashMap<String, PeerConnection> sspeerConnectionMap = new HashMap<>();
    public Thread sendCanditateThread;
    private Thread drainCanditateThread;
    private Thread drainShareCanditateThread;
    PeerConnection peerConnection = null;
    private PeerConnectionFactory factory;
    private HashMap<String, AudioTrack> audioTrackHashMap = new HashMap<>();
    private String registerIceServerConfig = "registerIceServerConfig";
    private boolean videoCallEnabled = false;
    private VideoCapturer videoCapturer;
    private VideoSource videoSource;
    private AudioSource audioSource;
    private VideoTrack localVideoTrack;
    private AudioTrack localAudioTrack, remoteAudioTrack;
    private Context context;
    public MediaStream lmediaStream;
    private ConnectedServer connectedServer;
    private PeerConnection.RTCConfiguration rtcConfig;
    private String CONFIGURATION = "{\"iceServers\": [{\"urls\": [\"stun:stun.l.google.com:19302\"]},{" +
            "\"urls\": [\"turn:dev.trova.in:8000?transport=tcp\"],\"credential\": \"mtrova123\"," +
            "\"username\": \"trovauser\"}]}";
    private boolean callInitiater = false;
    private boolean reTryStarted = false;
    //public LinkedList<IceCandidate> queuedRemoteCandidates=new LinkedList<IceCandidate>();
    private BlockingQueue<IceCandidate> queuedRemoteCandidates;
    private PeerConnectionEvents events;
    private TrovaApiService trovaApiService;

    public RTCConnection(TrovaApiService context) {
        this.context = context;
        trovaApiService = context;
        Thread.UncaughtExceptionHandler h = new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread th, Throwable ex) {
                System.out.println("Uncaught exception: " + ex);
            }
        };
        Thread.setDefaultUncaughtExceptionHandler(h);
    }

    private static String preferCodec(
            String sdpDescription, String codec, boolean isAudio) {
        String[] lines = sdpDescription.split("\r\n");
        int mLineIndex = -1;
        String codecRtpMap = null;
        String regex = "^a=rtpmap:(\\d+) " + codec + "(/\\d+)+[\r]?$";
        Pattern codecPattern = Pattern.compile(regex);
        String mediaDescription = "m=video ";
        if (isAudio) {
            mediaDescription = "m=audio ";
        }
        for (int i = 0; (i < lines.length)
                && (mLineIndex == -1 || codecRtpMap == null); i++) {
            if (lines[i].startsWith(mediaDescription)) {
                mLineIndex = i;
                continue;
            }
            Matcher codecMatcher = codecPattern.matcher(lines[i]);
            if (codecMatcher.matches()) {
                codecRtpMap = codecMatcher.group(1);
            }
        }
        if (mLineIndex == -1) {
            TrovaApiService.logData("", "No " + mediaDescription + " line, so can't prefer " + codec);
            return sdpDescription;
        }
        if (codecRtpMap == null) {
            TrovaApiService.logData("", "No rtpmap for " + codec);
            return sdpDescription;
        }
        TrovaApiService.logData("", "Found " + codec + " rtpmap " + codecRtpMap + ", prefer at "
                + lines[mLineIndex]);
        String[] origMLineParts = lines[mLineIndex].split(" ");
        if (origMLineParts.length > 3) {
            StringBuilder newMLine = new StringBuilder();
            int origPartIndex = 0;
            newMLine.append(origMLineParts[origPartIndex++]).append(" ");
            newMLine.append(origMLineParts[origPartIndex++]).append(" ");
            newMLine.append(origMLineParts[origPartIndex++]).append(" ");
            newMLine.append(codecRtpMap);
            for (; origPartIndex < origMLineParts.length; origPartIndex++) {
                if (!origMLineParts[origPartIndex].equals(codecRtpMap)) {
                    newMLine.append(" ").append(origMLineParts[origPartIndex]);
                }
            }
            lines[mLineIndex] = newMLine.toString();
            TrovaApiService.logData("", "Change media description: " + lines[mLineIndex]);
        } else {
            TrovaApiService.logData("", "Wrong SDP media description format: " + lines[mLineIndex]);
        }
        StringBuilder newSdpDescription = new StringBuilder();
        for (String line : lines) {
            newSdpDescription.append(line).append("\r\n");
        }
        return newSdpDescription.toString();
    }


    public void callingAudioVideo(String mode) {
        videoCallEnabled = false;
        isSdpSent = false;
        createPeerConnectionFactory();
        if (factory == null) {
            TrovaApiService.logData("", "Peerconnection factory is not created");
            return;
        }
        if (mode.equalsIgnoreCase("audio")) {
            TrovaApiService.logData("", "calling audio.");
        } else {
            videoCallEnabled = true;
            TrovaApiService.logData("", "calling video.");
            CameraEnumerator camera2Enumerator = new Camera1Enumerator(false);
            TrovaApiService.logData("", "After cameraDevice:");
            String[] cameraDeviceName = camera2Enumerator.getDeviceNames();
            TrovaApiService.logData("", "After cameraDevice:" + cameraDeviceName);
            for (String deviceName : cameraDeviceName) {
                TrovaApiService.logData("", "After cameraDevice:" + deviceName);
                if (camera2Enumerator.isFrontFacing(deviceName)) {
                    TrovaApiService.logData("", "Creating front facing camera capturer.");
                    videoCapturer = camera2Enumerator.createCapturer(deviceName, null);
                    break;
                }
            }
            createVideoTrack(videoCapturer);
        }
        createAudioTrack();
    }

    private void createPeerConnectionFactory() {
        factory = null;
        videoCapturer = null;
        localVideoTrack = null;
        PeerConnectionFactory.initializeFieldTrials("");
        PeerConnectionFactory.initializeAndroidGlobals(context, true, true, true);
        PeerConnectionFactory.Options options = new PeerConnectionFactory.Options();
        options.networkIgnoreMask = 0;

        factory = new PeerConnectionFactory(options);
        TrovaApiService.logData("", "Peer connection factory created.");
    }

    public void changeCamera() {
        if (videoCapturer != null && videoCapturer instanceof CameraVideoCapturer) {
            CameraVideoCapturer cameraVideoCapturer = (CameraVideoCapturer) videoCapturer;
            cameraVideoCapturer.switchCamera(null);
        }
    }

    private void createVideoTrack(VideoCapturer capturer) {
        /*MediaConstraints videoConstraints=new MediaConstraints();
        videoConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                "maxWidth", Integer.toString(1280)));
        videoConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                "maxHeight", Integer.toString(720)));
        videoConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                "minWidth", Integer.toString(1280)));
        videoConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                "minHeight", Integer.toString(720)));*/
        //videoConstraints.optional.add(new MediaConstraints.KeyValuePair("googIPv6","false"));
        videoSource = factory.createVideoSource(capturer);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
        }
        Log.i("displayMetrics", "widthPixels : " + displayMetrics.widthPixels + " , heightPixels : " + displayMetrics.heightPixels);
        capturer.startCapture(480, 640, 25);
        localVideoTrack = factory.createVideoTrack(VIDEO_TRACK_ID, videoSource);
        localVideoTrack.setEnabled(true);
    }

    private void createAudioTrack() {
        audioSource = factory.createAudioSource(new MediaConstraints());
        localAudioTrack = factory.createAudioTrack(
                AUDIO_TRACK_ID,
                audioSource);
        localAudioTrack.setEnabled(true);
    }

    public void createStream(TrovaApiService trovaApiService) {
        this.trovaApiService = trovaApiService;
        lmediaStream = factory.createLocalMediaStream("ARDAMS");
        if (videoCallEnabled) {
            lmediaStream.addTrack(localVideoTrack);
        }
        lmediaStream.addTrack(localAudioTrack);
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("stream", lmediaStream);
            jsonObject.put("trovaEvent", OnTrovaReceiveLocalStream);
            TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createPeerConnection(final String callerId) {

        CompleteListener completeListener = new CompleteListener() {
            @Override
            public void responseListener() {

                if (queuedRemoteCandidates == null) {
                    queuedRemoteCandidates = new LinkedBlockingQueue<>();
                    trovaApiService.runCandidatesQueueThread();
                }
                if (peerConnectionMap == null) {
                    peerConnectionMap = new HashMap<>();
                }

                List<PeerConnection.IceServer> iceServers = null;
                try {
                    PreferenceUtil preferenceUtil = new PreferenceUtil(trovaApiService);
                    String iceConfig = preferenceUtil.sharedpreferences.getString(registerIceServerConfig, null);
                    if (iceConfig == null) {
                        TrovaApiService.logData("createPeerConnection", "");
                        iceConfig = CONFIGURATION;
                    }
                    // iceConfig = CONFIGURATION;
                    iceServers = iceServersFromConfig(iceConfig);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //iceServers=new LinkedList<PeerConnection.IceServer>();
                if (iceServers != null) {
                    if (connectedServer == null)
                        connectedServer = ConnectedServer.STUN;
                    rtcConfig = new PeerConnection.RTCConfiguration(iceServers);
                    rtcConfig.tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED;
                    rtcConfig.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE;
                    rtcConfig.rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE;
                    rtcConfig.continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;
                    rtcConfig.keyType = PeerConnection.KeyType.ECDSA;
                }
//        PeerConnection peerConnection = null;
//        MediaConstraints pcConstraints = new MediaConstraints();
                MediaConstraints pcConstraints = new MediaConstraints();
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "maxWidth", Integer.toString(480)));
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "maxHeight", Integer.toString(640)));
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "minWidth", Integer.toString(480)));
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "minHeight", Integer.toString(640)));
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googIPv6", "false"));
                if (rtcConfig != null) {
                    peerConnection = factory.createPeerConnection(
                            rtcConfig, pcConstraints, new PCObserver(callerId));
                }
                if (peerConnection != null) {
                    peerConnection.addStream(lmediaStream);
                    TrovaApiService.logData("", "Peer connection created.");
                    peerConnectionMap.put(callerId, peerConnection);
                }

                String key = "null";
                for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                    String value = e.getValue();
                    if (value.equalsIgnoreCase(callerId)) {
                        key = e.getKey();
                        break;
                    }
                }
                Log.i("PeerConnection ->>-", "Create Peerc , User :" + key);
            }
        };
        getServerConfigStun(completeListener);
    }

    interface CompleteListener {
        void responseListener();
    }

    private void getServerConfigStun(final CompleteListener listener) {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                }
        };
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
        }
        String url = ConfigServer.FcmServerKey + "stunServer";
        HttpURLConnection con = null;
        String response1 = "";
        try {
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");

            String urlParameters = "";
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();
            int responseCode = con.getResponseCode();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            if (DEBUG) {
                Log.e("Server Config", responseCode + "");
                Log.e("Server Config", response + "");
            }

            in.close();
            if (!TextUtils.isEmpty(response.toString())) {
                response1 = response.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (!response1.isEmpty()) {
                try {
                    JSONObject jsonObject = new JSONObject(response1);
                    String stunUrl = jsonObject.getString("urls");
                    String userName = jsonObject.getString("username");
                    String password = jsonObject.getString("password");
                    getServerConfigTurn(stunUrl, userName, password, listener);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                listener.responseListener();
            }


        }
    }

    private void getServerConfigTurn(final String Stunurl, final String userName, final String password, final CompleteListener listener) {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                }
        };
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
        }
        String url = ConfigServer.FcmServerKey + "trunServer";
        HttpURLConnection con = null;
        try {
            URL obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");

            String urlParameters = "";
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            wr.close();
            int responseCode = con.getResponseCode();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            if (DEBUG) {
                Log.e("Server Config", responseCode + "");
                Log.e("Server Config", response + "");
            }

            //turn  {"urls":["turn:dev.trova.in:8000?transport=tcp","turn:dev.trova.in:4430?transport=udp"],"credential":"mtrova123","username":"trovauser"}
            in.close();
            if (!TextUtils.isEmpty(response.toString())) {
                JSONObject jsonObject = new JSONObject(response.toString());
//                JSONArray jsonArray = jsonObject.getJSONArray("urls");
//                String turnuserName = jsonObject.getString("username");
//                String turnpassword = jsonObject.getString("credential");
                JSONObject mainObj = new JSONObject();
                JSONArray mainArray = new JSONArray();

                JSONObject stunObj = new JSONObject();
                JSONArray stunUrlArray = new JSONArray();
                stunUrlArray.put(Stunurl);
                stunObj.put("urls", stunUrlArray);
                stunObj.put("username", userName);
                stunObj.put("credential", password);
                mainArray.put(stunObj);

                mainArray.put(jsonObject);

                mainObj.put("iceServers", mainArray);

                PreferenceUtil preferenceUtil = new PreferenceUtil(trovaApiService);
                SharedPreferences.Editor editor = preferenceUtil.sharedpreferences.edit();
                editor.putString(registerIceServerConfig, mainObj.toString());
                editor.apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            listener.responseListener();
        }
    }


    public void createScreenSharePeerConnection(final String callerId) {
        CompleteListener completeListener = new CompleteListener() {

            @Override
            public void responseListener() {
                sspeerConnectionMap = new HashMap<>();
                if (queuedRemoteCandidates == null) {
                    queuedRemoteCandidates = new LinkedBlockingQueue<>();
                    trovaApiService.runCandidatesQueueThread();
                }
                List<PeerConnection.IceServer> iceServers = null;
                try {
                    PreferenceUtil preferenceUtil = new PreferenceUtil(trovaApiService);
                    String iceConfig = preferenceUtil.sharedpreferences.getString(registerIceServerConfig, null);
                    if (iceConfig == null) {
                        TrovaApiService.logData("createPeerConnection", "");
                        iceConfig = CONFIGURATION;
                    }
                    // iceConfig = CONFIGURATION;
                    iceServers = iceServersFromConfig(iceConfig);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                //iceServers=new LinkedList<PeerConnection.IceServer>();
                if (iceServers != null) {
                    if (connectedServer == null)
                        connectedServer = ConnectedServer.STUN;
                    rtcConfig = new PeerConnection.RTCConfiguration(iceServers);
                    rtcConfig.tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED;
                    rtcConfig.bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE;
                    rtcConfig.rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE;
                    rtcConfig.continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY;
                    rtcConfig.keyType = PeerConnection.KeyType.ECDSA;
                }
                PeerConnection peerConnection = null;
                MediaConstraints pcConstraints = new MediaConstraints();
                pcConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googIPv6", "false"));
                if (rtcConfig != null) {
                    peerConnection = factory.createPeerConnection(
                            rtcConfig, pcConstraints, new PCObserver(callerId, true));
                }
                if (peerConnection != null) {
                    MediaStream emptyMediaStream = new MediaStream(0);
                    peerConnection.addStream(emptyMediaStream);
                    TrovaApiService.logData("", "Peer connection created.");
                    sspeerConnectionMap.put(callerId, peerConnection);
                }

                String key = "null";
                for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                    String value = e.getValue();
                    if (value.equalsIgnoreCase(callerId)) {
                        key = e.getKey();
                        break;
                    }
                }
                Log.i("PeerConnection ->>-", "share Create Peerc , User :" + key);
            }
        };
        getServerConfigStun(completeListener);
    }

    /*public LinkedList<PeerConnection.IceServer> iceServersFromConfig(
            String pcConfig) throws JSONException {
        JSONObject json = new JSONObject(pcConfig);
        JSONArray servers = json.getJSONArray("iceServers");
        LinkedList<PeerConnection.IceServer> ret =  new LinkedList<PeerConnection.IceServer>();
        for (int i = 0; i < servers.length(); ++i) {
            JSONObject server = servers.getJSONObject(i);
            String url = server.getString("url");
            String credential =
                    server.has("credential") ? server.getString("credential") : "";
            ret.add(new PeerConnection.IceServer(url, "", credential));
        }
        return ret;
    }*/
    private LinkedList<PeerConnection.IceServer> iceServersFromConfig(String pcConfig)
            throws JSONException {
        JSONObject json = new JSONObject(pcConfig);
        JSONArray servers = json.getJSONArray("iceServers");
        LinkedList<PeerConnection.IceServer> ret = new LinkedList<>();
        /*for (int i = 0; i < servers.length(); ++i) {
            JSONObject server = servers.getJSONObject(i);
            String url = server.getString("urls");
            String credential = server.has("credential") ? server.getString("credential") : "";
            ret.add(new PeerConnection.IceServer(url, "", credential));
        }*/
        for (int i = 0; i < servers.length(); ++i) {
            JSONObject server = servers.getJSONObject(i);
            JSONArray turnUrls = server.getJSONArray("urls");
            String username = server.has("username") ? server.getString("username") : "";
            String credential = server.has("credential") ? server.getString("credential") : "";
            for (int j = 0; j < turnUrls.length(); j++) {
                String turnUrl = turnUrls.getString(j);
                ret.add(new PeerConnection.IceServer(turnUrl, username, credential));
            }
        }
        return ret;

        //return ret;
    }

    public void initiatePeerConnectionEvents(PeerConnectionEvents events) {
        this.events = events;
    }

    public void createOffer(final String callerId) {
        /*new Thread(new Runnable() {
            public void run() {*/
        reTryStarted = false;
        isSdpSent = false;
        if (peerConnectionMap != null) {
            PeerConnection peerConnection = peerConnectionMap.get(callerId);
            MediaConstraints sdpMediaConstraints = new MediaConstraints();
            sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                    "OfferToReceiveAudio", "true"));
            if (videoCallEnabled)
                sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "OfferToReceiveVideo", "true"));

            TrovaApiService.logData("sdpMediaConstraints", sdpMediaConstraints.toString());
            if (peerConnection != null) {
                TrovaApiService.logData("", "PC Create OFFER");
                callInitiater = true;
                SDPObserver sdpObserver = new SDPObserver(callerId, videoCallEnabled ? "video" : "audio");
                peerConnection.createOffer(sdpObserver, sdpMediaConstraints);
            }
        }
            /*}
        }).start();*/
    }

    private void createAnswer(final String callerId, final boolean shareScreen) {
        /*new Thread(new Runnable() {
            public void run() {*/
        reTryStarted = false;
        isSdpSent = false;
        if (shareScreen) {
            if (sspeerConnectionMap != null) {
                PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
                TrovaApiService.logData("", "PC create ANSWER1" + peerConnection.toString());
                MediaConstraints sdpMediaConstraints = new MediaConstraints();
                sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "OfferToReceiveAudio", "true"));
                sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "OfferToReceiveVideo", "true"));

                TrovaApiService.logData("", "PC create ANSWER2");
                callInitiater = false;
                SDPObserver sdpObserver = new SDPObserver(callerId, videoCallEnabled ? "video" : "audio", true);
                peerConnection.createAnswer(sdpObserver, sdpMediaConstraints);
            }
        } else if (peerConnectionMap != null) {
            PeerConnection peerConnection = peerConnectionMap.get(callerId);
            TrovaApiService.logData("", "PC create ANSWER1" + peerConnection.toString());
            MediaConstraints sdpMediaConstraints = new MediaConstraints();
            sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                    "OfferToReceiveAudio", "true"));
            if (videoCallEnabled)
                sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair(
                        "OfferToReceiveVideo", "true"));

            TrovaApiService.logData("", "PC create ANSWER2");
            callInitiater = false;
            SDPObserver sdpObserver = new SDPObserver(callerId, videoCallEnabled ? "video" : "audio", shareScreen);
            peerConnection.createAnswer(sdpObserver, sdpMediaConstraints);
        }
           /* }
        }).start();*/
    }

    private void drainShareCandidatesByQueue(final String callerId) {

        if (drainShareCanditateThread == null) {
            drainShareCanditateThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    if (sspeerConnectionMap != null) {
                        PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
                        while (!(Thread.currentThread().isInterrupted())) {
                            IceCandidate candidate;
                            if (queuedRemoteCandidates != null && queuedRemoteCandidates.size() > 0)
                                try {
                                    candidate = queuedRemoteCandidates.take();
                                    if (candidate != null) {
                                        Log.i("candidates : drain", candidate.toString());
                                        peerConnection.addIceCandidate(candidate);
                                    }
                                } catch (Exception e) {
                                    //Thread.currentThread().interrupt();
                                    e.printStackTrace();
                                }

                        }
                    }
                }
            });
            drainShareCanditateThread.start();
        }
    }


    private void drainCandidatesByQueue(final String callerId) {

        if (drainCanditateThread == null) {
            drainCanditateThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    if (peerConnectionMap != null) {
                        PeerConnection peerConnection = peerConnectionMap.get(callerId);
                        while (!(Thread.currentThread().isInterrupted())) {
                            IceCandidate candidate;
                            if (queuedRemoteCandidates != null && queuedRemoteCandidates.size() > 0)
                                try {
                                    candidate = queuedRemoteCandidates.take();
                                    if (candidate != null) {
                                        Log.i("candidates : drain", candidate.toString());
                                        peerConnection.addIceCandidate(candidate);
                                    }
                                } catch (Exception e) {
                                    //Thread.currentThread().interrupt();
                                    e.printStackTrace();
                                }

                        }
                    }
                }
            });
            drainCanditateThread.start();
        }
    }

    public void addRemoteIceCandidate(final IceCandidate candidate, final String callerId, boolean shareScreen) {

        if (shareScreen) {
            if (sspeerConnectionMap == null) {
                return;
            }
            final PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
        /*new Thread(new Runnable() {
            public void run() {*/
            if (peerConnection != null) {
                    /*if (queuedRemoteCandidates != null) {
                        try {
                            Log.i("candidates : addRemote", candidate.toString() + ", candidates :" + callerId);
                            queuedRemoteCandidates.put(candidate);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {*/
                peerConnection.addIceCandidate(candidate);
                //}
            }
        } else {
            if (peerConnectionMap == null) {
                return;
            }
            final PeerConnection peerConnection = peerConnectionMap.get(callerId);
        /*new Thread(new Runnable() {
            public void run() {*/
            if (peerConnection != null) {
                    /*if (queuedRemoteCandidates != null) {
                        try {
                            Log.i("candidates : addRemote", candidate.toString() + ", candidates :" + callerId);
                            queuedRemoteCandidates.put(candidate);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {*/
                peerConnection.addIceCandidate(candidate);
                //}
            }
        }

           /* }
        }).start();*/
    }

    public void setRemoteDescription(final SessionDescription sdp, final String callerId, final boolean shareScreen) {
        TrovaApiService.logData("", "Set remote SDP. sdpRemote" + callerId);
        if (shareScreen) {
            if (sspeerConnectionMap != null) {
                final PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
        /*new Thread(new Runnable() {
            public void run() {*/
                if (peerConnection == null) {
                    return;
                }
                String sdpDescription = sdp.description;
                // sdpDescription = preferCodec(sdpDescription, AUDIO_CODEC, true);
                sdpDescription = preferCodec(sdpDescription, VIDEO_CODEC, false);
                TrovaApiService.logData("", "Set remote SDP. sdpRemote" + sdp.type);
                final SessionDescription sdpRemote = new SessionDescription(
                        sdp.type, sdpDescription);
                TrovaApiService.logData("", "Set remote SDP. sdpRemote" + sdpRemote.description);
                SDPObserver sdpObserver = new SDPObserver(callerId, videoCallEnabled ? "video" : "audio", shareScreen);
                peerConnection.setRemoteDescription(sdpObserver, sdpRemote);
                if (sdp.type.toString().equals("OFFER")) {
//                    if (sdpRemote.type.toString().equals("OFFER")) {
                    Log.i("OnRemote Description", "OFFER");
                    createAnswer(callerId, true);
//                    }

                }
                TrovaApiService.logData("", "isInitiator " + callerId);
            }
        } else if (peerConnectionMap != null) {
            final PeerConnection peerConnection = peerConnectionMap.get(callerId);
        /*new Thread(new Runnable() {
            public void run() {*/
            if (peerConnection == null) {
                return;
            }
            String sdpDescription = sdp.description;
//            sdpDescription = preferCodec(sdpDescription, AUDIO_CODEC, true);
            if (videoCallEnabled)
                sdpDescription = preferCodec(sdpDescription, VIDEO_CODEC, false);
            TrovaApiService.logData("", "Set remote SDP. sdpRemote" + sdp.type);
            final SessionDescription sdpRemote = new SessionDescription(
                    sdp.type, sdpDescription);
            TrovaApiService.logData("", "Set remote SDP. sdpRemote" + sdpRemote.description);
            SDPObserver sdpObserver = new SDPObserver(callerId, videoCallEnabled ? "video" : "audio", shareScreen);
            peerConnection.setRemoteDescription(sdpObserver, sdpRemote);
            if (sdp.type.toString().equals("OFFER")) {
//                    if (sdpRemote.type.toString().equals("OFFER")) {
                Log.i("OnRemote Description", "OFFER");
                createAnswer(callerId, false);
//                    }

            }
            TrovaApiService.logData("", "isInitiator " + callerId);
        }
           /* }
        }).start();*/
    }

    public void close(final String callerId) {
       /* Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Thread(new Runnable() {
            public void run() {*/
        if (peerConnectionMap == null) {
            return;
        }
        TrovaApiService.logData("", "Closing peer connection. callOther " + callerId);
        PeerConnection peerConnection = peerConnectionMap.get(callerId);
        TrovaApiService.logData("", peerConnectionMap.toString());
        if (peerConnection != null) {
            try {
                        /*if (localAudioTrack != null) {
                            AudioStatsObserver audioStatsObserver = new AudioStatsObserver();
                            peerConnection.getStats(audioStatsObserver, localAudioTrack);
                        }
                        if (localVideoTrack != null) {
                            VideoStatsObserver videoStatsObserver = new VideoStatsObserver();
                            peerConnection.getStats(videoStatsObserver, localVideoTrack);
                        }*/

                //peerConnection.dispose();

//                Iterator it = peerConnectionMap.entrySet().iterator();
//                while (it.hasNext()) {
//                    Map.Entry item = (Map.Entry) it.next();
//                    if (item.getKey().equals(callerId)) {
//                        it.remove();
//                        break;
//                    }
//                }

                peerConnection.removeStream(lmediaStream);
                peerConnection.close();
                peerConnection.dispose();
                // lmediaStream.dispose();
                if (sspeerConnectionMap != null) {
                    PeerConnection ssConnection = sspeerConnectionMap.get(callerId);
                    if (ssConnection != null) {
//                        it = sspeerConnectionMap.entrySet().iterator();
//                        while (it.hasNext()) {
//                            Map.Entry item = (Map.Entry) it.next();
//                            if (item.getKey().equals(callerId)) {
//                                it.remove();
//                                break;
//                            }
//                        }

                        ssConnection.removeStream(lmediaStream);
                        ssConnection.close();
                        ssConnection.dispose();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        freeupAllSource();
        System.gc();
           /* }
        }));*/
    }

    public void freeupAllSource() {
        try {

            if (audioSource != null) {
                TrovaApiService.logData("", "Closing audio source after dispose.");
                try {
                    audioSource.dispose();
                } catch (Exception e) {

                    e.printStackTrace();
                }
                TrovaApiService.logData("", "Closing audio source dispose.");
                audioSource = null;
            }

            if (videoCapturer != null) {
                try {
                    videoCapturer.stopCapture();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

                videoCapturer.dispose();
                videoCapturer = null;
            }
            if (videoSource != null) {
                TrovaApiService.logData("", "Closing video source after dispose.");
                try {
                    videoSource.dispose();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                TrovaApiService.logData("", "Closing video source dispose.");
                videoSource = null;
            }
            TrovaApiService.logData("", "Closing peer connection factory.");
            if (factory != null) {
                try {
                    factory.dispose();
                } catch (Exception e) {
                    e.printStackTrace();
                } catch (Error e) {
                    e.printStackTrace();
                }
            }
//            TrovaApiService.logData("", "Closing peer connection factory1.");
            factory = null;
            remoteAudioTrack = null;
            localAudioTrack = null;
            localVideoTrack = null;
            if (audioTrackHashMap != null)
                audioTrackHashMap.clear();
            if (drainCanditateThread != null)
                drainCanditateThread.interrupt();

            if (drainShareCanditateThread != null)
                drainShareCanditateThread.interrupt();

            queuedRemoteCandidates = null;
            trovaApiService.sendcandidatesqueue = null;
            TrovaApiService.logData("", "Closing peer connection done.");
            if (events != null)
                events.onPeerConnectionClosed();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void closeConf(final String callerId) {
        // Handler handler = new Handler(Looper.getMainLooper());
        // handler.post(new Thread(new Runnable() {
        //   public void run() {
        try {
            TrovaApiService.logData("", "Closing peer connection. closeConf callOther " + callerId);
            PeerConnection peerConnection = peerConnectionMap.get(callerId);
            if (peerConnection != null) {
                peerConnectionMap.remove(callerId);
                TrovaApiService.logData("", peerConnectionMap.toString());
                //peerConnection.dispose();
                peerConnection.removeStream(lmediaStream);
                peerConnection.close();
                peerConnection.dispose();


            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public void closeAllInConf(final String callerId) {
        // Handler handler = new Handler(Looper.getMainLooper());
        // handler.post(new Thread(new Runnable() {
        //   public void run() {
        try {
            TrovaApiService.logData("", "Closing peer connection. closeConf callOther " + callerId);
            PeerConnection peerConnection = peerConnectionMap.get(callerId);
            if (peerConnection != null) {
                TrovaApiService.logData("", peerConnectionMap.toString());
                //peerConnection.dispose();
                peerConnection.removeStream(lmediaStream);
                peerConnection.close();
                peerConnection.dispose();


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void closeConfScreenShare(final String callerId) {
        // Handler handler = new Handler(Looper.getMainLooper());
        // handler.post(new Thread(new Runnable() {
        //   public void run() {
        try {
            TrovaApiService.logData("", "Closing peer connection. closeConf callOther " + callerId);
            PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
            TrovaApiService.logData("", sspeerConnectionMap.toString());
            if (peerConnection != null) {

                Iterator it = sspeerConnectionMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry item = (Map.Entry) it.next();
                    if (item.getKey().equals(callerId)) {
                        it.remove();
                        break;
                    }
                }

                //peerConnection.dispose();
//                peerConnection.removeStream(lmediaStream);
                peerConnection.close();
                peerConnection.dispose();


            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public void stopVideoSource() {
        /*Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Thread(new Runnable() {
            public void run() {*/
        if (videoSource != null) {
            TrovaApiService.logData("", "Stop video source.");
            try {
                videoCapturer.stopCapture();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
          /*  }
        }));*/
    }

    public void stopVideo(boolean mute) {
        if (localVideoTrack != null) {
            TrovaApiService.logData("", "Stop video source.");
            try {
                localVideoTrack.setEnabled(!mute);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void startVideoSource() {
      /*  Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Thread(new Runnable() {
            public void run() {*/
        if (videoSource != null) {
            TrovaApiService.logData("", "Stop video source.");
            videoCapturer.startCapture(1280, 720, 30);
        }
          /*  }
        }));*/
    }

    public void setAudioEnabled(final boolean enable) {
       /* Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Thread(new Runnable() {
            public void run() {*/
        if (localAudioTrack != null) {
            localAudioTrack.setEnabled(enable);
        }
         /*   }
        }));*/
    }

    public void setSpeakerMute() {
        if (audioTrackHashMap != null) {
            for (Map.Entry<String, AudioTrack> e : audioTrackHashMap.entrySet()) {
                AudioTrack audioTrack = e.getValue();
                if (audioTrack != null) {
                    audioTrack.setEnabled(false);
                }
            }
        }
        if (remoteAudioTrack != null)
            remoteAudioTrack.setEnabled(false);
    }

    public void setSpeakerUnMute() {
        if (audioTrackHashMap != null) {

            for (Map.Entry<String, AudioTrack> e : audioTrackHashMap.entrySet()) {
                AudioTrack audioTrack = e.getValue();
                if (audioTrack != null) {
                    audioTrack.setEnabled(true);
                }
            }

        }
        if (remoteAudioTrack != null)
            remoteAudioTrack.setEnabled(true);
    }

    public void hold() {
        if (videoSource != null)
            try {
                videoCapturer.stopCapture();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        if (remoteAudioTrack != null) {
            remoteAudioTrack.setEnabled(false);
            localAudioTrack.setEnabled(false);
        }
    }

    public void unHold() {
        if (videoSource != null)
            videoCapturer.startCapture(1280, 720, 30);
        if (remoteAudioTrack != null) {
            remoteAudioTrack.setEnabled(true);
            localAudioTrack.setEnabled(true);
        }
    }

    public void addRemoteVideo() {
        TrovaApiService.logData("", "addRemoteVideo");
//        if (remoteRender != null && remoteVideoTrack != null)
//            remoteVideoTrack.addRenderer(new VideoRenderer(remoteRender));
    }

    private enum ConnectedServer {
        STUN,
        RESTUN,
        TURN;
    }

    public interface PeerConnectionEvents {
        /**
         * Callback fired once local SDP is created and set.
         */
        void onLocalDescription(final SessionDescription sdp, final String callOther, final String callMode, final boolean screenShare);

        /**
         * Callback fired once local Ice candidate is generated.
         */
        void onIceCandidate(final IceCandidate candidate, final String callOther, final String callMode, final boolean screenShare);

        /**
         * Callback fired once connection is established (IceConnectionState is
         * CONNECTED).
         */
        void onIceConnected(String callOther, String mode);

        /**
         * Callback fired once connection is closed (IceConnectionState is
         * DISCONNECTED).
         */
        void onIceDisconnected();

        /**
         * Callback fired once peer connection is closed.
         */
        void onPeerConnectionClosed();

    }

    private class PCObserver implements PeerConnection.Observer {
        String callerKey;
        boolean screenShare;

        PCObserver(String callerKey) {
            this.callerKey = callerKey;
        }

        PCObserver(String callerKey, boolean screenShare) {
            this.callerKey = callerKey;
            this.screenShare = screenShare;
        }

        @Override
        public void onSignalingChange(PeerConnection.SignalingState signalingState) {
            TrovaApiService.logData("", "SignalingState: " + signalingState);
        }

        @Override
        public void onIceConnectionChange(final PeerConnection.IceConnectionState iceConnectionState) {
         /*   final Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Thread(new Runnable() {
                public void run() {*/
            String key = "null";
            TrovaApiService.logData("", "IceConnectionState: " + iceConnectionState);
            for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                String value = e.getValue();
                if (value.equalsIgnoreCase(callerKey)) {
                    key = e.getKey();
                    break;
                }
            }
            Log.i("IceConnectionState ->>-", "" + iceConnectionState);
            Log.i("PeerConnection ->>-", "" + iceConnectionState + " , User :" + key);
            if (iceConnectionState == PeerConnection.IceConnectionState.CONNECTED) {
                //queuedRemoteCandidates = null;
                trovaApiService.sendcandidatesqueue = null;
                reTryStarted = false;
                events.onIceConnected(callerKey, videoCallEnabled ? "video" : "audio");
            } else if (iceConnectionState == PeerConnection.IceConnectionState.CHECKING) {
                       /* handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // queuedRemoteCandidates = null;
                                trovaApiService.sendcandidatesqueue = null;
                                if (peerConnectionMap != null) {
                                    PeerConnection peerConnection = peerConnectionMap.get(callerKey);
                                    if (peerConnection != null && peerConnection.iceConnectionState() == PeerConnection.IceConnectionState.CHECKING) {
                                        TrovaApiService.logData("", "ICE connection ." + iceConnectionState);
                                        TrovaApiService.logData("", "connectedServer ." + connectedServer);
//                                    initReTryConncetion(callerKey);
                                    }
                                }
                            }
                        }, 8000);*/
            } else if (iceConnectionState == PeerConnection.IceConnectionState.DISCONNECTED) {
                events.onIceDisconnected();
            } else if (iceConnectionState == PeerConnection.IceConnectionState.FAILED) {
                TrovaApiService.logData("", "ICE connection ." + iceConnectionState);
                TrovaApiService.logData("", "connectedServer ." + connectedServer);
                JSONObject jsonObject = new JSONObject();
                if (peerConnectionMap != null && peerConnectionMap.size() == 1) {
                    trovaApiService.endPeerConnection(callerKey, key);
                    try {
                        jsonObject.put("status", "failed");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    HashMap<String, String> callersList = trovaApiService.callersList;
                    if (screenShare) {
                        callersList = trovaApiService.sharecallersList;
                    }
                    for (Map.Entry<String, String> e : callersList.entrySet()) {
                        String value = e.getValue();
                        if (value.equalsIgnoreCase(callerKey)) {
                            key = e.getKey();
                            jsonObject.put("callerId", key);
                            break;
                        }
                    }
                    jsonObject.put("status", "failed");
                    if (screenShare) {
                        jsonObject.put("trovaEvent", OnTrovaScreenShareState);
                    } else {
                        jsonObject.put("trovaEvent", OnTrovaCallState);
                    }
                    jsonObject.put("env", trovaApiService.preferenceUtil.isWidget() ? "Widget" : "Mobile");
                    TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else if (iceConnectionState == PeerConnection.IceConnectionState.CLOSED) {
                trovaApiService.sendcandidatesqueue = null;
                TrovaApiService.logData("", "ICE connection ." + iceConnectionState);
            }
        }

        @Override
        public void onIceConnectionReceivingChange(boolean b) {

        }

        @Override
        public void onIceGatheringChange(PeerConnection.IceGatheringState iceGatheringState) {

        }

        @Override
        public void onIceCandidate(final IceCandidate iceCandidate) {
            events.onIceCandidate(iceCandidate, callerKey, videoCallEnabled ? "video" : "audio", screenShare);
        }

        @Override
        public void onIceCandidatesRemoved(IceCandidate[] iceCandidates) {

        }

        @Override
        public void onAddStream(final MediaStream mediaStream) {
            TrovaApiService.logData("", "Weird-looking stream: " + mediaStream.audioTracks.size());
            TrovaApiService.logData("", "Weird-looking stream: " + mediaStream.videoTracks.size());
            if (mediaStream.audioTracks.size() > 1 || mediaStream.videoTracks.size() > 1) {
                TrovaApiService.logData("", "Weird-looking stream: " + mediaStream);
                return;
            }
            if (mediaStream.audioTracks.size() == 1) {
                remoteAudioTrack = mediaStream.audioTracks.get(0);
                for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                    String value = e.getValue();
                    if (value.equalsIgnoreCase(callerKey)) {
                        String key = e.getKey();
                        audioTrackHashMap.put(key, remoteAudioTrack);
                        break;
                    }
                }

                if (trovaApiService != null && trovaApiService.trovaAudioMute) {
                    remoteAudioTrack.setEnabled(false);
                } else {
                    remoteAudioTrack.setEnabled(true);
                }

            }
            if (mediaStream.videoTracks.size() == 1) {
                VideoTrack remoteVideoTrack = mediaStream.videoTracks.get(0);
                remoteVideoTrack.setEnabled(true);
                TrovaApiService.logData("", "Weird-looking stream: " + TrovaApiService.trovaApiCallback);
                JSONObject jsonObject = new JSONObject();
                try {
                    if (screenShare) {
                        jsonObject.put("trovaEvent", OnTrovaReceiveScreenShareStream);
                    } else {
                        jsonObject.put("trovaEvent", OnTrovaReceiveRemoteStream);
                    }
                    String key = "";
                    for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                        String value = e.getValue();
                        if (value.equalsIgnoreCase(callerKey)) {
                            key = e.getKey();
                            jsonObject.put("callerId", key);
                            break;
                        }
                    }
                    if (!TextUtils.isEmpty(key)) {
                        jsonObject.put("mode", "video");
                        jsonObject.put("stream", mediaStream);
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (mediaStream.audioTracks.size() == 1) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("trovaEvent", OnTrovaReceiveRemoteStream);
                    String key = "";
                    for (Map.Entry<String, String> e : trovaApiService.callersList.entrySet()) {
                        String value = e.getValue();
                        if (value.equalsIgnoreCase(callerKey)) {
                            key = e.getKey();
                            jsonObject.put("callerId", key);
                            break;
                        }
                    }
                    if (!TextUtils.isEmpty(key)) {
                        jsonObject.put("stream", mediaStream);
                        jsonObject.put("mode", "audio");
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        public void onRemoveStream(MediaStream mediaStream) {

        }

        @Override
        public void onDataChannel(DataChannel dataChannel) {

        }

        @Override
        public void onRenegotiationNeeded() {

        }

        @Override
        public void onAddTrack(RtpReceiver rtpReceiver, MediaStream[] mediaStreams) {

        }
    }

    private class SDPObserver implements SdpObserver {
        String callerId;
        String callMode;
        SessionDescription localSdp;
        SDPObserver sdpObserver;
        boolean shareScreen;

        SDPObserver(String callerId, String callMode) {
            this.callerId = callerId;
            this.callMode = callMode;
            sdpObserver = this;
        }

        SDPObserver(String callerId, String callMode, boolean shareScreen) {
            this.callerId = callerId;
            this.callMode = callMode;
            sdpObserver = this;
            this.shareScreen = shareScreen;
        }

        @Override
        public void onCreateSuccess(SessionDescription sessionDescription) {
            String sdpDescription = sessionDescription.description;
//            sdpDescription = preferCodec(sdpDescription, AUDIO_CODEC, true);
            if (shareScreen || videoCallEnabled)
                sdpDescription = preferCodec(sdpDescription, VIDEO_CODEC, false);
            final SessionDescription sdp = new SessionDescription(
                    sessionDescription.type, sdpDescription);
            localSdp = sdp;
            TrovaApiService.logData("", "Set local SDP from " + localSdp);
//            new Thread(new Runnable() {
//                public void run() {

            PeerConnection peerConnection = null;
            if (shareScreen) {
                if (sspeerConnectionMap != null) {
                    peerConnection = sspeerConnectionMap.get(callerId);
                }
                if (peerConnection != null) {
                    TrovaApiService.logData("", "Set local SDP from " + sdp.type);
                    peerConnection.setLocalDescription(sdpObserver, sdp);
                }
            } else {
                if (peerConnectionMap != null) {
                    peerConnection = peerConnectionMap.get(callerId);
                }
                if (peerConnection != null) {
                    TrovaApiService.logData("", "Set local SDP from " + sdp.type);
                    peerConnection.setLocalDescription(sdpObserver, sdp);
                }
            }

//                }
//            }).start();
        }

        @Override
        public void onSetSuccess() {
            TrovaApiService.logData("", "SDP set.");
//            new Thread(new Runnable() {
//                public void run() {

            if (shareScreen) {
                if (sspeerConnectionMap != null) {
                    PeerConnection peerConnection = sspeerConnectionMap.get(callerId);
                    if (peerConnection == null) {
                        return;
                    }
                    if (callInitiater) {
                        if (peerConnection.getRemoteDescription() == null) {
                            TrovaApiService.logData("", "Local SDP set succesfully 1");
                            events.onLocalDescription(localSdp, callerId, "video", shareScreen);
                        } else {
                            TrovaApiService.logData("", "Remote SDP set succesfully");
                            drainShareCandidatesByQueue(callerId);
                        }
                    } else {
                        if (peerConnection.getLocalDescription() != null) {
                            TrovaApiService.logData("", "Local SDP set succesfully 2");
                            if (localSdp != null) {
                                TrovaApiService.logData("", "Local SDP set succesfully 3");
                                events.onLocalDescription(localSdp, callerId, "video", shareScreen);
                                drainShareCandidatesByQueue(callerId);
                            }

                        }
                    }
                }
            } else {
                if (peerConnectionMap != null) {
                    PeerConnection peerConnection = peerConnectionMap.get(callerId);
                    if (peerConnection == null) {
                        return;
                    }
                    if (callInitiater) {
                        if (peerConnection.getRemoteDescription() == null) {
                            TrovaApiService.logData("", "Local SDP set succesfully 1");
                            events.onLocalDescription(localSdp, callerId, callMode, shareScreen);
                        } else {
                            TrovaApiService.logData("", "Remote SDP set succesfully");
                            drainCandidatesByQueue(callerId);
                        }
                    } else {
                        if (peerConnection.getLocalDescription() != null) {
                            TrovaApiService.logData("", "Local SDP set succesfully 2");
                            if (localSdp != null) {
                                TrovaApiService.logData("", "Local SDP set succesfully 3");
                                events.onLocalDescription(localSdp, callerId, callMode, shareScreen);
                                drainCandidatesByQueue(callerId);
                            }

                        }
                    }
                }
            }

//                }
//            }).start();
        }

        @Override
        public void onCreateFailure(String s) {
        }

        @Override
        public void onSetFailure(String s) {

        }
    }

    private class AudioStatsObserver implements StatsObserver {
        @Override
        public void onComplete(StatsReport[] statsReports) {
            String arr[] = new String[25];
            for (StatsReport statsReport : statsReports) {
                for (StatsReport.Value value : statsReport.values) {
                    switch (value.name) {
                        case "bytesReceived":
                            arr[0] = value.value;
                            break;
                        case "bytesSent":
                            arr[1] = value.value;
                            break;
                        case "packetsLost":
                            arr[4] = value.value;
                            break;
                        case "packetsReceived":
                            arr[5] = value.value;
                            break;
                        case "packetsSent":
                            arr[6] = value.value;
                            break;
                        case "transportId":
                            arr[14] = value.value;
                            break;
                        case "googJitterReceived":
                            arr[17] = value.value;
                            break;
                        case "googRtt":
                            arr[18] = value.value;
                            break;
                    }
                }
            }
            arr[2] = arr[0];
            arr[3] = arr[1];
            arr[7] = arr[4];
            arr[8] = arr[5];
            arr[9] = arr[6];
            arr[24] = trovaApiService.preferenceUtil.getUserId();
            trovaApiService.executeStoreAudioStatus(arr);
        }
    }

    private class VideoStatsObserver implements StatsObserver {
        @Override
        public void onComplete(StatsReport[] statsReports) {
            String arr[] = new String[25];
            for (StatsReport statsReport : statsReports) {
                for (StatsReport.Value value : statsReport.values) {
                    switch (value.name) {
                        case "bytesReceived":
                            arr[0] = value.value;
                            break;
                        case "bytesSent":
                            arr[1] = value.value;
                            break;
                        case "packetsLost":
                            arr[4] = value.value;
                            break;
                        case "packetsReceived":
                            arr[5] = value.value;
                            break;
                        case "packetsSent":
                            arr[6] = value.value;
                            break;
                        case "transportId":
                            arr[14] = value.value;
                            break;
                        case "googJitterReceived":
                            arr[17] = value.value;
                            break;
                        case "googRtt":
                            arr[18] = value.value;
                            break;
                    }
                }
            }
            arr[2] = arr[0];
            arr[3] = arr[1];
            arr[7] = arr[4];
            arr[8] = arr[5];
            arr[9] = arr[6];
            arr[24] = trovaApiService.preferenceUtil.getUserId();
            trovaApiService.executeStoreVideoStatus(arr);
        }
    }
}

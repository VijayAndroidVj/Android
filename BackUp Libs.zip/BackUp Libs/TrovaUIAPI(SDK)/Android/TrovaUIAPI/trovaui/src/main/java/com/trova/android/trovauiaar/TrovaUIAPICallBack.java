package com.trova.android.trovauiaar;

import org.json.JSONObject;

/**
 * Created by razin on 6/10/17.
 */

public interface TrovaUIAPICallBack {

    String OnTrovaUISDK_Init = "OnTrovaUISDK_Init";
    String OnTrovaUISessionUserOnline = "OnTrovaUISessionUserOnline";
    String OnTrovaUISession_Disconnect = "OnTrovaUISession_Disconnect";
    String OnTrovaUIXmit_Registration2Server = "OnTrovaUIXmit_Registration2Server";
    String OnTrovaUIXmit_SendPayload = "OnTrovaUIXmit_SendPayload";
    String OnTrovaUICall_Init = "OnTrovaUICall_Init";
    String OnTrovaUIReceiveCall = "OnTrovaUIReceiveCall";
    String OnTrovaUICall_End = "OnTrovaUICall_End";
    String OnTrovaUIReceiveEndCall = "OnTrovaUIReceiveEndCall";
    String OnTrovaUICall_Reject = "OnTrovaUICall_Reject";
    String OnTrovaUIReceiveRejectCall = "OnTrovaUIReceiveRejectCall";
    String OnTrovaUICall_InitMissedCall = "OnTrovaUICall_InitMissedCall";
    String OnTrovaUIReceiveMissedCall = "OnTrovaUIReceiveMissedCall";
    String OnTrovaUIReceiveCalleeBusy = "OnTrovaUIReceiveCalleeBusy";
    String OnTrovaUIAgentCall_Init = "OnTrovaUIAgentCall_Init";
    String OnTrovaUIGadgetCall_Init = "OnTrovaUIGadgetCall_Init";
    String OnTrovaUIChatList_Init = "OnTrovaUIChatList_Init";
    String OnTrovaUIChat_Init = "OnTrovaUIChat_Init";
    String OnTrovaUIGadgetChat_Init = "OnTrovaUIGadgetChat_Init";

    void setTrovaUICallBack(JSONObject jsonObject);
}

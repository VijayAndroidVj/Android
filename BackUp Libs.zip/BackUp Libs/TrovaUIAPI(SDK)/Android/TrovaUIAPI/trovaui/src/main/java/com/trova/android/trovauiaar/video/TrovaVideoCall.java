package com.trova.android.trovauiaar.video;

import arr.trova.in.trovawoui.BaseActivity;

/**
 * Created by razin on 04-10-2017..
 */

public class TrovaVideoCall extends BaseActivity {
   /* ImageView img_trova_video_call_video;
    ImageView img_trova_video_call_mic;
    private SurfaceViewRenderer incalllocalvideoview;
    private SurfaceViewRenderer incallremotevideoview;
    private PercentFrameLayout incallservervideolayout;
    private PercentFrameLayout incalllocalvideolayout;
    String callType;
    String otherUserID;
    String agentKey;
    String otherUserName = "";
    private boolean isRejected = false;
    private TextView tv_trova_video_call_caller_name;
    private ImageView img_trova_video_call_reject, img_trova_video_call_accept;
    public static TrovaVideoCall trovaVideoCall;
    private EglBase rootEglBase;
    public HashMap<Integer, String> videoList = new HashMap<>();
    boolean Mute;
    boolean isMicEnabled = true;
    boolean isVideoEnabled = true;
    private long startTime;
    TextView tv_trova_video_call_caller_id;
    boolean isAgentCall;
    TextView tv_trova_video_call_finding_agents;
    LinearLayout ll_trova_video_call_finding_agents;
    private static TrovaUIAPICallBack trovaUICallBack;
    TextView tv_trova_video_call_business_name;
    String businessName = "";

    private Camera mCamera;
    private CameraPreview mPreview;
    Camera.CameraInfo cameraInfo;
    int cameraCount;
    int camId = 0;
    private static final int PERMISSION_REQUEST_CODE = 1234;

    MediaPlayer mediaPlayer;
    Vibrator vibrator;
    long[] vibratepattern = {0, 200, 600};

    private VideoCapturer videoCapturer;
    private VideoSource videoSource;
    private AudioSource audioSource;
    private VideoTrack localVideoTrack;
    private AudioTrack localAudioTrack;
    private PeerConnectionFactory factory;
    private static final String VIDEO_TRACK_ID = "ARDAMSv0";
    private static final String AUDIO_TRACK_ID = "ARDAMSa0";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        trovaVideoCall = this;
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_trova_video_call);

        setInitUI();
        InitVideoUI();
        setRegisterUI();
        handleCallViews();

    }

    private void setInitUI() {
        img_trova_video_call_video = findViewById(R.id.img_trova_video_call_video);
        img_trova_video_call_mic = findViewById(R.id.img_trova_video_call_mic);
        tv_trova_video_call_business_name = (TextView) findViewById(R.id.tv_trova_video_call_business_name);
        tv_trova_video_call_caller_name = (TextView) findViewById(R.id.tv_trova_video_call_caller_name);
        tv_trova_video_call_caller_id = (TextView) findViewById(R.id.tv_trova_video_call_caller_id);
        img_trova_video_call_reject = findViewById(R.id.img_trova_video_call_reject);
        img_trova_video_call_accept = findViewById(R.id.img_trova_video_call_accept);
        img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_black_24dp);
        img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);
    }

    private void InitVideoUI() {
        incalllocalvideolayout = (PercentFrameLayout) findViewById(R.id.incalllocalvideolayout);
        incallservervideolayout = (PercentFrameLayout) findViewById(R.id.incallremotevideolayout);
        incalllocalvideolayout.setPosition(72, 72, 25, 25);
        incallservervideolayout.setPosition(0, 0, 100, 100);

        incalllocalvideoview = (SurfaceViewRenderer) findViewById(R.id.incalllocalvideoview);
        incallremotevideoview = (SurfaceViewRenderer) findViewById(R.id.incallremotevideoview);

        rootEglBase = EglBase.create();

        incalllocalvideoview.init(rootEglBase.getEglBaseContext(), null);
        incalllocalvideoview.setZOrderMediaOverlay(true);
        incalllocalvideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
        incalllocalvideoview.setMirror(false);
        incalllocalvideoview.requestLayout();

        incallremotevideoview.init(rootEglBase.getEglBaseContext(), null);
        incallremotevideoview.setZOrderMediaOverlay(false);
        incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
        incallremotevideoview.setMirror(false);
        incallremotevideoview.requestLayout();

        ll_trova_video_call_finding_agents = (LinearLayout) findViewById(R.id.ll_trova_video_call_finding_agents);
        tv_trova_video_call_finding_agents = (TextView) findViewById(R.id.tv_trova_video_call_finding_agents);

    }

    private void setRegisterUI() {
        img_trova_video_call_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trovaApi.trovaVideoMute(isVideoEnabled);
                isVideoEnabled = !isVideoEnabled;
                if (!isVideoEnabled) {
                    img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_off_black_24dp);
                } else {
                    img_trova_video_call_video.setImageResource(R.drawable.ic_videocam_black_24dp);
                }
            }
        });

        img_trova_video_call_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trovaApi.trovaMicMute(isMicEnabled);
                isMicEnabled = !isMicEnabled;
                if (isMicEnabled) {
                    img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);
                } else {
                    img_trova_video_call_mic.setImageResource(R.drawable.ic_mic_off_black_24dp);
                }
            }
        });

        img_trova_video_call_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        endCallDone = true;
                        trovaApi.trovaCall_End("video", otherUserID);
                        onfinish();
                    } else {
                        isRejected = true;
                        if (callType.equals("answer")) {
                            trovaApi.trovaCall_Reject("video", otherUserID);
                        } else {
                            trovaApi.trovaCall_InitMissedCall("video", otherUserID);
                        }
                        onfinish();
                    }
                } else {
                    onfinish();
                }
            }
        });

        img_trova_video_call_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                incallservervideolayout.removeAllViews();
                incallservervideolayout.addView(incallremotevideoview);
                incallremotevideoview.setZOrderMediaOverlay(false);
                incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                incallremotevideoview.setMirror(false);
                incalllocalvideolayout.setVisibility(View.VISIBLE);
                incalllocalvideoview.setVisibility(View.VISIBLE);
                trovaApi.trovaCall_Answer("video", otherUserID);
                img_trova_video_call_accept.setVisibility(View.GONE);
                img_trova_video_call_mic.setVisibility(View.VISIBLE);
                img_trova_video_call_video.setVisibility(View.VISIBLE);
                startTime = System.currentTimeMillis();
                mHandler.postDelayed(mUpdateTimeTask, 100);
                tv_trova_video_call_caller_name.setText(otherUserID);
                isConnected = true;
            }
        });
    }

    private void handleCallViews() {
        isAgentCall = getIntent().getIntExtra("isAgentCall", 0) == 1;
        callType = getIntent().getStringExtra("callType");
        if (getIntent().hasExtra("otherUserID")) {
            otherUserID = getIntent().getStringExtra("otherUserID");
        }
        if (getIntent().hasExtra("agentKey")) {
            agentKey = getIntent().getStringExtra("agentKey");
        }
        if (getIntent().hasExtra("otherUserName")) {
            otherUserName = getIntent().getStringExtra("otherUserName");
        }
        if (getIntent().hasExtra("businessName")) {
            businessName = getIntent().getStringExtra("businessName");
        }
        if (isAgentCall) {
            ll_trova_video_call_finding_agents.setVisibility(View.VISIBLE);
            tv_trova_video_call_finding_agents.setText(getString(R.string.finding_agents));
            mCallingHandler.postDelayed(mUpdateCalling, 1000);
//            mCallingHandler1.removeCallbacks(mUpdateCalling);
            if (!callType.equals("answer")) {
                makeAgentCall = trovaApi.trovaGadgetCall_Init(activity, "video", agentKey);
            }

        } else {
            tv_trova_video_call_business_name.setVisibility(View.GONE);
            ll_trova_video_call_finding_agents.setVisibility(View.GONE);
            preferenceUtil.setVideoUserOnline(otherUserID);
            if (callType.equals("answer")) {
                setRinger();
                tv_trova_video_call_caller_name.setText("Incoming " + otherUserID);
                img_trova_video_call_accept.setVisibility(View.VISIBLE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                img_trova_video_call_mic.setVisibility(View.GONE);
                img_trova_video_call_video.setVisibility(View.GONE);

            } else {
                if (businessName != null && !businessName.isEmpty()) {
                    tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                    tv_trova_video_call_business_name.setText(businessName);
                } else {
                    tv_trova_video_call_business_name.setVisibility(View.GONE);
                    tv_trova_video_call_caller_id.setText(otherUserID);
                }
                img_trova_video_call_accept.setVisibility(View.GONE);
                img_trova_video_call_reject.setVisibility(View.VISIBLE);
                img_trova_video_call_mic.setVisibility(View.GONE);
                img_trova_video_call_video.setVisibility(View.GONE);
                tv_trova_video_call_caller_name.setText("Calling " + otherUserID);
                makeNormalCall = trovaApi.trovaCall_Init(activity, "video", otherUserID);
            }

            incalllocalvideolayout.setVisibility(View.GONE);
            incalllocalvideoview.setVisibility(View.GONE);
            incallremotevideoview.setZOrderMediaOverlay(false);
            incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
            incallremotevideoview.setMirror(false);
            incallremotevideoview.requestLayout();
            requestCameraPermissionAndContinue();
        }
    }

    private void setRinger() {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        switch (audio.getRingerMode()) {
            case AudioManager.RINGER_MODE_NORMAL:
                mediaPlayer = MediaPlayer.create(getApplicationContext(), notification);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(vibratepattern, 0);
                break;
            case AudioManager.RINGER_MODE_SILENT:
                break;
            case AudioManager.RINGER_MODE_VIBRATE:
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                vibrator.vibrate(vibratepattern, 0);
                break;
        }
    }

    public void requestCameraPermissionAndContinue() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CODE);
            } else {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CODE);
            }
        } else {
            getCameraPreview();
        }
    }

    private void getCameraPreview() {
        cameraInfo = new Camera.CameraInfo();
        cameraCount = Camera.getNumberOfCameras();
        if (cameraCount > 0) {
            setCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
        } else {
            setCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
        }
    }

    private void setCamera(int cameraFace) {
        camId = cameraFace;
        mCamera = Camera.open(cameraFace);
        mCamera.setDisplayOrientation(90);
//        mPreview = new CameraPreview(this, mCamera);
        mPreview = new CameraPreview(this);
        incallservervideolayout.removeAllViews();
        incallservervideolayout.addView(mPreview);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getCameraPreview();
                } else {
                    requestCameraPermissionAndContinue();
                }
                break;
        }
    }

    private void flipCamera() {
        if (camId == Camera.CameraInfo.CAMERA_FACING_BACK) {
            setCamera(Camera.CameraInfo.CAMERA_FACING_FRONT);
        } else {
            setCamera(Camera.CameraInfo.CAMERA_FACING_BACK);
        }
    }

    @Override
    protected void onDestroy() {
        videoCapturer = null;
        videoSource = null;
        audioSource = null;
        localVideoTrack = null;
        localAudioTrack = null;
        factory = null;

        try {
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            if (vibrator != null) {
                vibrator.cancel();
            }
            trovaVideoCall = null;
            preferenceUtil.setVideoUserOnline("");
            mHandler.removeCallbacks(mUpdateTimeTask);
            if (otherUserID != null && !otherUserID.isEmpty()) {
                if (isConnected) {
                    if (!endCallDone)
                        trovaApi.trovaCall_End("video", otherUserID);
                } else if (!isRejected) {
                    trovaApi.trovaCall_Reject("video", otherUserID);
                }
            }
            if (incalllocalvideoview != null) {
                if (videoRendererLocal != null && videoTrackLocal != null)
                    videoTrackLocal.removeRenderer(videoRendererLocal);
                incalllocalvideoview.release();
                incalllocalvideoview = null;
            }
            if (incallremotevideoview != null) {
                if (videoRendererRemote != null && videoTrackRemote != null)
                    videoTrackRemote.removeRenderer(videoRendererRemote);
                incallremotevideoview.release();
                incallremotevideoview = null;
            }
            rootEglBase.release();

        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    private void onfinish() {
        if (isTaskRoot()) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                finishAndRemoveTask();
            } else {
                finish();
            }
        } else {
            finish();
        }
    }

    private VideoRenderer videoRendererRemote, videoRendererLocal;
    private VideoTrack videoTrackRemote, videoTrackLocal;

    public void TrovaEvents(JSONObject jsonObject) {
        String event = null;
        try {
            event = jsonObject.getString("trovaEvent");
            switch (event) {
                case OnTrovaReceiveCalleeBusy:
                    String callerId = jsonObject.getString("callerId");
                    Toast.makeText(activity, callerId + " is Busy right now", Toast.LENGTH_LONG).show();
                    onfinish();
                    break;
                case OnTrovaAgentInfo:
                    String callMode = jsonObject.getString("callMode");
                    callerId = jsonObject.getString("callerId");
                    String agentName = jsonObject.getString("agentName");
                    String businessName = jsonObject.getString("displayName");
                    if (callMode.equalsIgnoreCase("video")) {
                        otherUserID = callerId;
                        otherUserName = agentName;
                        ll_trova_video_call_finding_agents.setVisibility(View.GONE);
                        preferenceUtil.setVideoUserOnline(otherUserID);
                        if (businessName != null && !businessName.isEmpty()) {
                            tv_trova_video_call_business_name.setVisibility(View.VISIBLE);
                            tv_trova_video_call_business_name.setText(businessName);
                        } else {
                            tv_trova_video_call_business_name.setVisibility(View.GONE);
                        }
                        tv_trova_video_call_caller_name.setText("Calling " + otherUserID);
//                        trovaApi.trovaSetupCall(activity, "video", otherUserID);
                    }
                    requestCameraPermissionAndContinue();
                    break;
                case OnTrovaReceiveLocalStream:
                    try {
                        MediaStream mediaStream = (MediaStream) jsonObject.get("mediaStream");
                        videoList.put(0, "You");
                        if (mediaStream.videoTracks.size() == 1) {
                            videoTrackLocal = mediaStream.videoTracks.get(0);
                            videoTrackLocal.setEnabled(true);

                            videoRendererRemote = new VideoRenderer(incallremotevideoview);
                            videoTrackLocal.addRenderer(videoRendererRemote);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;

                case OnTrovaReceiveRemoteStream:
                    try {
                        MediaStream mediaStream = (MediaStream) jsonObject.get("mediaStream");
                        String callerPhone = jsonObject.getString("callerPhone").trim();
                        videoList.put(1, callerPhone);
                        videoTrackLocal.removeRenderer(videoRendererRemote);
                        videoTrackLocal.removeRenderer(videoRendererLocal);

                        videoRendererLocal = new VideoRenderer(incalllocalvideoview);
                        videoTrackLocal.addRenderer(videoRendererLocal);

                        videoTrackRemote = mediaStream.videoTracks.get(0);
                        videoTrackRemote.setEnabled(true);
                        videoRendererRemote = new VideoRenderer(incallremotevideoview);
                        videoTrackRemote.addRenderer(videoRendererRemote);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case OnTrovaCallState:
                    break;
                case OnTrovaReceiveEndCall:
                    if (incalllocalvideoview != null) {
                        incalllocalvideoview.release();
                        incalllocalvideoview = null;
                    }
                    if (incallremotevideoview != null) {
                        incallremotevideoview.release();
                        incallremotevideoview = null;
                    }
                    onfinish();
                    break;

                case OnTrovaReceiveRejectCall:
                    otherUserID = "";
                    onfinish();
                    break;

                case OnPermissionsRequired:
                    Toast.makeText(activity, "Permission Required", Toast.LENGTH_SHORT).show();
                    PermissionCheck.requestPermission(activity, PermissionCheck.checkPermission(activity, PermissionCheck.getAllVideoPermissions()), 1000);
                    break;
                case OnTrovaReceiveMissedCall:
                    try {
                        isRejected = true;
                        String callerPhone = jsonObject.get("callerId").toString();
                        callMode = jsonObject.get("callMode").toString();
                        if (callerPhone.equalsIgnoreCase(otherUserID) && callMode.equalsIgnoreCase("video")) {
                            if (incalllocalvideoview != null) {
                                incalllocalvideoview.release();
                                incalllocalvideoview = null;
                            }
                            if (incallremotevideoview != null) {
                                incallremotevideoview.release();
                                incallremotevideoview = null;
                            }
                            onfinish();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

              *//*  case OnVideoConnected:
                    tv_trova_video_call_caller_name.setText(otherUserID);
                    isConnected = true;
                    break;
*//*
                case OnTrovaAcceptedCall:

                    incallservervideolayout.removeAllViews();
                    incallservervideolayout.addView(incallremotevideoview);
                    incallremotevideoview.setZOrderMediaOverlay(false);
                    incallremotevideoview.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_BALANCED);
                    incallremotevideoview.setMirror(false);
                    incalllocalvideolayout.setVisibility(View.VISIBLE);
                    incalllocalvideoview.setVisibility(View.VISIBLE);


                    img_trova_video_call_accept.setVisibility(View.GONE);
                    img_trova_video_call_mic.setVisibility(View.VISIBLE);
                    img_trova_video_call_video.setVisibility(View.VISIBLE);
                    startTime = System.currentTimeMillis();
                    mHandler.postDelayed(mUpdateTimeTask, 100);
                    tv_trova_video_call_caller_name.setText(otherUserID);
                    isConnected = true;
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    boolean isConnected;
    boolean endCallDone;
    private Handler mHandler = new Handler();
    *//**
     * Background Runnable thread
     *//*
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            long millisUntilFinished = System.currentTimeMillis() - startTime;

            tv_trova_video_call_caller_id.setText(String.format(Locale.getDefault(), "%s %02d:%02d:%02d", getString(R.string.call_duration),
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            // Running this thread after 100 milliseconds
            mHandler.postDelayed(this, 1000);
        }
    };

    private Handler mCallingHandler = new Handler();
    private int callingTxtCount = 1;
    *//**
     * Background Runnable thread
     *//*
    private Runnable mUpdateCalling = new Runnable() {
        public void run() {
            switch (callingTxtCount) {
                case 0:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s", getString(R.string.finding_agents)));
                    callingTxtCount = 1;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                case 1:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s.", getString(R.string.finding_agents)));
                    callingTxtCount = 2;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                case 2:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s..", getString(R.string.finding_agents)));
                    callingTxtCount = 3;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
                default:
                    tv_trova_video_call_finding_agents.setText(String.format(Locale.getDefault(), "%s...", getString(R.string.finding_agents)));
                    callingTxtCount = 0;
                    mCallingHandler.postDelayed(mUpdateCalling, 1000);
                    break;
            }
        }
    };

    boolean makeAgentCall = false;
    boolean makeNormalCall = false;


    @Override
    protected void onResume() {
        super.onResume();
        if (permissionGranted) {
            permissionGranted = false;
            if (!callType.equalsIgnoreCase("answer")) {
                if (isAgentCall) {
                    if (!makeAgentCall) {
                        makeAgentCall = trovaApi.trovaGadgetCall_Init(activity, "video", agentKey);
                    }

                } else {
                    if (!makeNormalCall) {
                        makeNormalCall = trovaApi.trovaCall_Init(activity, "video", otherUserID);
                    }
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public static void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
        trovaUICallBack = trovaUIAPICallBack;
    }

    private void postEvent(String event) {
        if (trovaUICallBack != null) {
            JSONObject jobj = new JSONObject();
            try {
                jobj.put("trovaEvent", event);
                jobj.put("callerId", otherUserID);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            trovaUICallBack.setTrovaUICallBack(jobj);
        }
    }*/
}


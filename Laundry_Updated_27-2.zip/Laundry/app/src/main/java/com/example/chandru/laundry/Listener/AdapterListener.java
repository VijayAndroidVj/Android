package com.example.chandru.laundry.Listener;



public interface AdapterListener {
    void adapterActionListener(int state, Object data);
}

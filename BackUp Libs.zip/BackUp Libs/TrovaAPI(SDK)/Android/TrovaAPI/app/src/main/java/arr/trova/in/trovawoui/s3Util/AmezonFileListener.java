package arr.trova.in.trovawoui.s3Util;

/**
 * Created by iyara_rajan on 10-08-2017.
 */

public interface AmezonFileListener {

    void onSuccessResult(String serverPath, String localPath);

    void onFailure(String status, String localPath);

    void onProgressChange(int percentage, String localPath);
}

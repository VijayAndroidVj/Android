package com.trova.android.trovauiaar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.trova.android.trovauiaar.chat.ChatListActivity;
import com.trova.android.trovauiaar.chat.TrovaChat;
import com.trova.android.trovauiaar.service.TrovaService;
import com.trova.android.trovauiaar.video.ReachVideoCall;
import com.trova.android.trovauiaar.voice.ReachVoiceCall;

import java.util.HashMap;

import arr.trova.in.trovawoui.Utils.NetworkUtil;
import arr.trova.in.trovawoui.Utils.PreferenceUtil;
import arr.trova.in.trovawoui.services.TrovaApiService;
import arr.trova.in.trovawoui.trovaSDK_Init;

import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUIAgentCall_Init;
import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUICall_Init;
import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUIChat_Init;
import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUIGadgetCall_Init;
import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUIGadgetChat_Init;

/**
 * Created by razin on 22/8/17.
 */

public class trovaUISDK_Init {
    private Context context;
    public PreferenceUtil preferenceUtil;

    private trovaUISDK_Init() {
    }


    /**
     * This constructor user to create object for access all api's
     *
     * @param context         - Context
     * @param type            - {"TYPE1 or TYPE2}
     * @param bKey            - Business key
     * @param userId          - User Id
     * @param userName        - User name
     * @param userEmail       - User Email
     * @param userPhone       - User Phone
     * @param userCountryCode - User Country Code
     * @param nodeUrl         - Socket Url
     * @param port            - Socket Port
     * @param callBack        - Callback
     */
    public trovaUISDK_Init(Context context, final String type, final String bKey, final String userId, final String userName, final String userEmail, final String userPhone, final String userCountryCode, final TrovaUIAPICallBack callBack, final String nodeUrl, final String port) {
        this.context = context;
        preferenceUtil = new PreferenceUtil(context);
        Intent intent = new Intent(context, TrovaService.class);
        context.startService(intent);
        setCallBack(callBack);
        Globalclass.trovaSDK_init = new trovaSDK_Init(context, type, bKey, userName, userId, userEmail, userPhone, userCountryCode, TrovaService.trovaApiCallback, nodeUrl, port);/*"https://dev.trova.in", "8080");*/
    }

    private void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
        TrovaService.setCallBack(trovaUIAPICallBack);
        // TrovaChat.setCallBack(trovaUIAPICallBack);
    }


    /**
     * Connect Socket
     */
    public void trovaUISession_Connect() {
        if (Globalclass.trovaSDK_init != null)
            Globalclass.trovaSDK_init.trovaSession_Connect();

    }

    /**
     * DisConnect Socket
     */
    public void trovaUISession_Disconnect() {
        if (Globalclass.trovaSDK_init != null)
            Globalclass.trovaSDK_init.trovaSession_Disconnect();

    }

    public static enum RegsitrationType {
        FCM,
        APIN,
        VOIP;

        private RegsitrationType() {
        }
    }

    /**
     * Registration to Server
     */
    public void trovaUIXmit_Registration2Server(RegsitrationType tokenType, String token) {
        if (Globalclass.trovaSDK_init != null) {
            trovaSDK_Init.RegsitrationType regsitrationType = trovaSDK_Init.RegsitrationType.VOIP;
            if (tokenType.toString().equalsIgnoreCase(RegsitrationType.FCM.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.FCM;
            } else if (tokenType.toString().equalsIgnoreCase(RegsitrationType.APIN.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.APIN;
            } else if (tokenType.toString().equalsIgnoreCase(RegsitrationType.VOIP.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.VOIP;
            }
            Globalclass.trovaSDK_init.trovaXmit_Registration2Server(regsitrationType, token);
        }
    }

    /**
     * Send Payload from FCM
     */
    public void trovaUIXmit_SendPayload(RegsitrationType tokenType, String payLoad) {
        if (Globalclass.trovaSDK_init != null && tokenType != null) {
            trovaSDK_Init.RegsitrationType regsitrationType = trovaSDK_Init.RegsitrationType.VOIP;
            if (tokenType.toString().equalsIgnoreCase(RegsitrationType.FCM.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.FCM;
            } else if (tokenType.toString().equalsIgnoreCase(RegsitrationType.APIN.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.APIN;
            } else if (tokenType.toString().equalsIgnoreCase(RegsitrationType.VOIP.toString())) {
                regsitrationType = trovaSDK_Init.RegsitrationType.VOIP;
            }
            Globalclass.trovaSDK_init.trovaXmit_SendPayload(regsitrationType, payLoad);
        }
    }

    /**
     * Initiate Call UI for one to One
     *
     * @param activity
     * @param callMode
     * @param otherUserName
     * @param otherUserId
     */
    public void trovaUICall_Init(Activity activity, String callMode, String otherUserName, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaUICall_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaUICall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent CallActivity;
            if (callMode.trim().toLowerCase().equalsIgnoreCase("audio")) {
                CallActivity = new Intent(activity, ReachVoiceCall.class);
            } else {
                CallActivity = new Intent(activity, ReachVideoCall.class);
            }
            CallActivity.putExtra("status", 0);
            CallActivity.putExtra("otherUserName", otherUserName);
            CallActivity.putExtra("otherUserID", otherUserId);
            CallActivity.putExtra("callType", "dial");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(CallActivity);

            values.put("trovaEvent", OnTrovaUICall_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * Initiate Gadget Call UI for one to Many
     *
     * @param activity
     * @param callMode
     * @param agentKey
     */
    public void trovaUIGadgetCall_Init(Activity activity, String callMode, String agentKey) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaUIGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(agentKey)) {
            values.put("trovaEvent", OnTrovaUIGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "agentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaUIGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent CallActivity;
            if (callMode.trim().toLowerCase().equalsIgnoreCase("audio")) {
                CallActivity = new Intent(activity, ReachVoiceCall.class);
            } else {
                CallActivity = new Intent(activity, ReachVideoCall.class);
            }
            CallActivity.putExtra("status", 1);
            CallActivity.putExtra("agentKey", agentKey);
            CallActivity.putExtra("callType", "dial");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(CallActivity);

            values.put("trovaEvent", OnTrovaUIGadgetCall_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }

    /**
     * Initiate Agent Call UI for Agent to Widget
     *
     * @param activity
     * @param callMode
     * @param otherUserId
     * @param filePath
     * @param autoRecording
     * @param agentKey
     */
    public void trovaUIAgentCall_Init(Activity activity, String callMode, String otherUserId, String filePath, boolean autoRecording, String agentKey) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaUIAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaUIAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "otherUserId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(filePath)) {
            values.put("trovaEvent", OnTrovaUIAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "filePath is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(agentKey)) {
            values.put("trovaEvent", OnTrovaUIAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "agentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaUIAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent CallActivity;
            if (callMode.trim().toLowerCase().equalsIgnoreCase("audio")) {
                CallActivity = new Intent(activity, ReachVoiceCall.class);
            } else {
                CallActivity = new Intent(activity, ReachVideoCall.class);
            }
            CallActivity.putExtra("status", 2);
            CallActivity.putExtra("agentKey", agentKey);
            CallActivity.putExtra("filePath", filePath);
            CallActivity.putExtra("autoRecording", autoRecording);
            CallActivity.putExtra("otherUserId", otherUserId);
            CallActivity.putExtra("callType", "dial");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(CallActivity);

        }
    }

    /**
     * Init UI Chat List
     */
    public void trovaUIChat_Init(String otherUserId, String otherUserName) {
        HashMap<String, Object> values = new HashMap<>();
        if (otherUserId == null || otherUserId.isEmpty()) {
            values.put("trovaEvent", OnTrovaUIChat_Init);
            values.put("result", "failed");
            values.put("msg", "otherUserId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent CallActivity = new Intent(context, TrovaChat.class);
            CallActivity.putExtra("otherUserID", otherUserId);
            CallActivity.putExtra("otherUserName", otherUserName);
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(CallActivity);
        }
    }

    /**
     * Init UI Chat List
     */
    public void trovaUIGadgetChat_Init(String agentKey) {
        HashMap<String, Object> values = new HashMap<>();
        if (agentKey == null || agentKey.isEmpty()) {
            values.put("trovaEvent", OnTrovaUIGadgetChat_Init);
            values.put("result", "failed");
            values.put("msg", "agentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent CallActivity = new Intent(context, TrovaChat.class);
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            CallActivity.putExtra("agentKey", agentKey);
            CallActivity.putExtra("isWidgetChat", true);
            CallActivity.putExtra("incoming", 0);
            context.startActivity(CallActivity);
        }
    }

    /**
     * Init UI Chat List
     */
    public void trovaUIChatList_Init() {
        Intent CallActivity = new Intent(context, ChatListActivity.class);
        CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(CallActivity);
    }

    public void trovaSetupIncomingCallUI(Context context, String mode, String otherUserName, String otherUserID) {
        Intent CallActivity = null;

        if (!mode.isEmpty() && !otherUserID.isEmpty()) {
            if (mode.equalsIgnoreCase("audio")) {
                CallActivity = new Intent(context, ReachVoiceCall.class);
            } else if (mode.equalsIgnoreCase("video")) {
                CallActivity = new Intent(context, ReachVideoCall.class);
            }
            CallActivity.putExtra("status", 0);
            CallActivity.putExtra("otherUserName", otherUserName);
            CallActivity.putExtra("otherUserID", otherUserID);
            CallActivity.putExtra("callType", "answer");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(CallActivity);
        }
    }
 /*
    public void trovaSetupAgentIncomingCallUI(Context context, String mode) {
        Intent CallActivity = null;
        if (!mode.isEmpty()) {
            if (mode.equalsIgnoreCase("audio")) {
                CallActivity = new Intent(context, TrovaVoiceCall.class);
            } else if (mode.equalsIgnoreCase("video")) {
                CallActivity = new Intent(context, TrovaVideoCall.class);
            }
            CallActivity.putExtra("isAgentCall", 1);
            CallActivity.putExtra("callType", "answer");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(CallActivity);
        }
    }*/

   /* public void trovaSetupChatUI(Context context, String otherUserName, String otherUserID, ArrayList<ChatMessageModel> chatList) {
        if (chatList != null && !otherUserID.isEmpty()) {
            Intent trovaChatActivity = new Intent(context, TrovaChat.class);
            trovaChatActivity.putExtra("otherUserName", otherUserName);
            trovaChatActivity.putExtra("otherUserID", otherUserID);
            trovaChatActivity.putExtra("chatList", chatList);
            trovaChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(trovaChatActivity);
        }
    }

    public void trovaSetupAgentChatUI(Activity activity, String agentKey, ArrayList<ChatMessageModel> chatList) {

        if (agentKey != null && !agentKey.isEmpty() && chatList != null) {
            Intent trovaChatActivity = new Intent(activity, TrovaChat.class);
            trovaChatActivity.putExtra("isAgentChat", 1);
            trovaChatActivity.putExtra("agentKey", agentKey);
            trovaChatActivity.putExtra("chatList", chatList);
            trovaChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(trovaChatActivity);
        }

    }*/

    /*   public void trovaAppendChatUI(ArrayList<ChatMessageModel> chatList) {
           if (TrovaChat.trovaChat != null) {
               TrovaChat.trovaChat.TrovaEvents(chatList);
           }
       }

       public void trovaSendFcmToken(String fcmToken) {
           if (trovaApi != null)
               trovaApi.trovaXmit_Registration2Server(trovaSDK_Init.RegsitrationType.FCM, fcmToken);
       }

       public void trovaSendPayload(String payLoad) {
           if (trovaApi != null)
               trovaApi.trovaXmit_SendPayload(trovaSDK_Init.RegsitrationType.FCM, payLoad);
       }

       public void trovaDis() {
           if (trovaApi != null)
               trovaApi.trovaSession_Disconnect();
       }

       public void restartTrova(Context context) {
    Intent intent = new Intent(context, TrovaService.class);
        context.startService(intent);
        new

    Handler(Looper.getMainLooper()).

    postDelayed(new Runnable() {
        @Override
        public void run () {
            if (trovaApi != null)
                trovaApi.trovaSession_Connect();
        }
    },500);
    }*/
}

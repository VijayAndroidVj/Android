package com.trova.android.trovauiaar.pstn;

import android.content.Context;

import java.util.Date;

/**
 * Created by razin on 4/12/17.
 */

public class CallReceiver extends PhonecallReceiver {

    public static boolean isOnPSTNCall = false;

    @Override
    protected void onIncomingCallStarted(final Context ctx, String number, Date start) {
        isOnPSTNCall = true;
    }

    @Override
    protected void onIncomingCallEnded(Context ctx, String number, Date start, Date end) {
        isOnPSTNCall = false;
    }
}
package com.trova.android.trovauiaar.voice;

import arr.trova.in.trovawoui.BaseActivity;

public class TrovaVoiceCall extends BaseActivity {

   /* TextView tv_trova_voice_call_title;
    TextView tv_trova_voice_call_finding_agents;
    TextView tv_trova_voice_call_business_name;
    TextView tv_trova_voice_call_caller_name;
    TextView tv_trova_voice_call_caller_id;
    ImageView img_trova_voice_call_speaker;
    ImageView img_trova_voice_call_mic;
    ImageView img_trova_voice_call_reject;
    ImageView img_trova_voice_call_accept;
    private long startTime;
    String callType;
    String otherUserName;
    String otherUserID;
    PreferenceUtil SP;
    boolean isConnected = false, endCallDone = false;
    public static TrovaVoiceCall trovaVoiceCall;
    boolean isSpeaker;
    boolean isMicEnabled = true;
    boolean isAgentCall;
    String agentKey;
    LinearLayout ll_trova_voice_call_details;
    LinearLayout ll_trova_voice_call_finding_agent;
    private static TrovaUIAPICallBack trovaUICallBack;


    boolean makeAgentCall = false;
    boolean makeNormalCall = false;
    String businessName = "";

    MediaPlayer mediaPlayer;
    Vibrator vibrator;
    long[] vibratepattern = {0, 200, 600};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        trovaVoiceCall = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trova_voice_call);
        SP = new PreferenceUtil(this);
        callType = getIntent().getStringExtra("callType");
        isAgentCall = getIntent().getIntExtra("isAgentCall", 0) == 1;

        if (getIntent().hasExtra("agentKey")) {
            agentKey = getIntent().getStringExtra("agentKey");
        }

        if (getIntent().hasExtra("otherUserID")) {
            otherUserID = getIntent().getStringExtra("otherUserID");
        }
        if (getIntent().hasExtra("otherUserName")) {
            otherUserName = getIntent().getStringExtra("otherUserName");
        }
        if (getIntent().hasExtra("businessName")) {
            businessName = getIntent().getStringExtra("businessName");
        }
        setInitUI();
        setRegisterUI();
        handleCallViews();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (permissionGranted) {
            permissionGranted = false;
            if (!callType.equalsIgnoreCase("answer"))
                if (isAgentCall) {
                    if (!makeAgentCall) {
                        if (trovaApi != null)
                            makeAgentCall = trovaApi.trovaGadgetCall_Init(activity, "audio", agentKey);
                    }

                } else {
                    if (!makeNormalCall) {
                        makeNormalCall = trovaApi.trovaCall_Init(activity, "audio", otherUserID);
                    }
                }
        }
    }


    private boolean isRejected = false;

    @Override
    protected void onDestroy() {
        mHandler.removeCallbacks(mUpdateTimeTask);
        if (otherUserID != null && !otherUserID.isEmpty()) {
            if (isConnected) {
                if (!endCallDone)
                    trovaApi.trovaCall_End("audio", otherUserID);
            } else if (!isRejected) {
                trovaApi.trovaCall_Reject("audio", otherUserID);
            }
        }
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
        trovaVoiceCall = null;
        TrovaService.displayName = "";
        TrovaService.callerName = "";
        super.onDestroy();
    }

    private void onfinish() {
        if (isTaskRoot()) {
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                finishAndRemoveTask();
            } else {
                finish();
            }
        } else {
            finish();
        }
    }

    private Handler mCallingHandler1 = new Handler();
    private int callingTxtCount = 1;
    *//**
     * Background Runnable thread
     *//*
    private Runnable mUpdateCalling = new Runnable() {
        public void run() {
            switch (callingTxtCount) {
                case 0:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s", getString(R.string.finding_agents)));
                    callingTxtCount = 1;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                case 1:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s.", getString(R.string.finding_agents)));
                    callingTxtCount = 2;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                case 2:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s..", getString(R.string.finding_agents)));
                    callingTxtCount = 3;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
                default:
                    tv_trova_voice_call_finding_agents.setText(String.format(Locale.getDefault(), "%s...", getString(R.string.finding_agents)));
                    callingTxtCount = 0;
                    mCallingHandler1.postDelayed(mUpdateCalling, 1000);
                    break;
            }
        }
    };

    private void handleCallViews() {
        img_trova_voice_call_speaker.setVisibility(View.GONE);
        img_trova_voice_call_mic.setVisibility(View.GONE);

        if (isAgentCall) {
            ll_trova_voice_call_details.setVisibility(View.GONE);
            ll_trova_voice_call_finding_agent.setVisibility(View.VISIBLE);
            tv_trova_voice_call_finding_agents.setText(getString(R.string.finding_agents));
            mCallingHandler1.postDelayed(mUpdateCalling, 1000);

            if (TrovaService.displayName != null && !TrovaService.displayName.isEmpty()) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(TrovaService.displayName);
                tv_trova_voice_call_caller_name.setText(TrovaService.callerName);
                tv_trova_voice_call_caller_id.setText("");
            }

        } else {
            ll_trova_voice_call_finding_agent.setVisibility(View.GONE);
            ll_trova_voice_call_details.setVisibility(View.VISIBLE);
            if (TrovaService.displayName != null && !TrovaService.displayName.isEmpty()) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(TrovaService.displayName);
                tv_trova_voice_call_caller_name.setText(TrovaService.callerName);
                tv_trova_voice_call_caller_id.setText("");
            } else {
                tv_trova_voice_call_business_name.setVisibility(View.GONE);
                if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                    tv_trova_voice_call_caller_name.setText(otherUserID);
                    tv_trova_voice_call_caller_id.setText("");
                } else {
                    tv_trova_voice_call_caller_name.setText(otherUserName);
                    tv_trova_voice_call_caller_id.setText(otherUserID);
                }
            }
        }
        if (callType.equals("answer")) {
            setRinger();
            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
            img_trova_voice_call_accept.setVisibility(View.VISIBLE);
            tv_trova_voice_call_title.setText("Incoming");
        } else {
            if (businessName != null && !businessName.isEmpty()) {
                tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                tv_trova_voice_call_business_name.setText(businessName);
            } else {
                tv_trova_voice_call_business_name.setVisibility(View.GONE);
                tv_trova_voice_call_caller_id.setText(otherUserID);
            }
            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
            img_trova_voice_call_accept.setVisibility(View.GONE);
            tv_trova_voice_call_title.setText("Calling");
            if (isAgentCall) {
                makeAgentCall = trovaApi.trovaGadgetCall_Init(activity, "audio", agentKey);
            } else {
                makeNormalCall = trovaApi.trovaCall_Init(activity, "audio", otherUserID);
            }

        }
    }

    private void setRinger() {
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        switch (audio.getRingerMode()) {
            case AudioManager.RINGER_MODE_NORMAL:
                mediaPlayer = MediaPlayer.create(getApplicationContext(), notification);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                vibrator.vibrate(vibratepattern, 0);
                break;
            case AudioManager.RINGER_MODE_SILENT:
                break;
            case AudioManager.RINGER_MODE_VIBRATE:
                vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                // Vibrate for 500 milliseconds
                vibrator.vibrate(vibratepattern, 0);
                break;
        }
    }

    private void setRegisterUI() {
        img_trova_voice_call_speaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isSpeaker) {
                    try {
                        AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                        am.setMode(AudioManager.STREAM_VOICE_CALL);
                        am.setSpeakerphoneOn(true);
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
//                    rtcApi.trovaUnMuteAudioStream();
                    img_trova_voice_call_speaker.setImageResource(R.drawable.ic_volume_up_black_24dp);
                    isSpeaker = false;
                } else {
                    try {
                        AudioManager am = (AudioManager) getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
                        am.setMode(AudioManager.STREAM_VOICE_CALL);
                        am.setSpeakerphoneOn(false);
                    } catch (Exception e) {

                        e.printStackTrace();
                    }
                    img_trova_voice_call_speaker.setImageResource(R.drawable.ic_volume_off_black_24dp);
                    isSpeaker = true;
                }

            }
        });
        img_trova_voice_call_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                trovaApi.trovaMicMute(isMicEnabled);
                isMicEnabled = !isMicEnabled;
                if (isMicEnabled) {
                    img_trova_voice_call_mic.setImageResource(R.drawable.ic_mic_black_24dp);
                } else {
                    img_trova_voice_call_mic.setImageResource(R.drawable.ic_mic_off_black_24dp);
                }

            }
        });
        img_trova_voice_call_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                if (otherUserID != null && !otherUserID.isEmpty()) {
                    if (isConnected) {
                        endCallDone = true;
                        trovaApi.trovaCall_End("audio", otherUserID);
                    } else {
                        isRejected = true;
                        if (callType.equals("answer")) {
                            trovaApi.trovaCall_Reject("audio", otherUserID);
                        } else {
                            trovaApi.trovaCall_InitMissedCall("audio", otherUserID);
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    mHandler.removeCallbacks(mUpdateTimeTask);
                                    otherUserID = "";
                                    setResult(RESULT_CANCELED);
                                    onfinish();
                                }
                            });
                        }
                    }
                } else {
                    onfinish();
                }
            }
        });
        img_trova_voice_call_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                if (vibrator != null) {
                    vibrator.cancel();
                }
                trovaApi.trovaCall_Answer("audio", otherUserID);
                runOnUiThread(new Runnable() {
                    public void run() {
                        img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
                        img_trova_voice_call_mic.setVisibility(View.VISIBLE);
                        img_trova_voice_call_accept.setVisibility(View.GONE);
                        img_trova_voice_call_reject.setVisibility(View.VISIBLE);
                        tv_trova_voice_call_title.setText("On call");
                        isConnected = true;
                        startTime = System.currentTimeMillis();
                        mHandler.postDelayed(mUpdateTimeTask, 100);
                    }
                });
            }
        });
    }

    private void setInitUI() {
        tv_trova_voice_call_title = (TextView) findViewById(R.id.tv_trova_voice_call_title);
        tv_trova_voice_call_finding_agents = (TextView) findViewById(R.id.tv_trova_voice_call_finding_agents);
        tv_trova_voice_call_business_name = (TextView) findViewById(R.id.tv_trova_voice_call_business_name);
        tv_trova_voice_call_caller_name = (TextView) findViewById(R.id.tv_trova_voice_call_caller_name);
        tv_trova_voice_call_caller_id = (TextView) findViewById(R.id.tv_trova_voice_call_caller_id);
        img_trova_voice_call_speaker = (ImageView) findViewById(R.id.img_trova_voice_call_speaker);
        img_trova_voice_call_mic = (ImageView) findViewById(R.id.img_trova_voice_call_mic);
        img_trova_voice_call_reject = (ImageView) findViewById(R.id.img_trova_voice_call_reject);
        img_trova_voice_call_accept = (ImageView) findViewById(R.id.img_trova_voice_call_accept);
        ll_trova_voice_call_details = (LinearLayout) findViewById(R.id.ll_trova_voice_call_details);
        ll_trova_voice_call_finding_agent = (LinearLayout) findViewById(R.id.ll_trova_voice_call_finding_agent);
    }

    private Handler mHandler = new Handler();
    private Handler mCallingHandler = new Handler();
    *//**
     * Background Runnable thread
     *//*
    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            long millisUntilFinished = System.currentTimeMillis() - startTime;

            tv_trova_voice_call_caller_id.setText(String.format(Locale.getDefault(), "%s %02d:%02d:%02d", "Call duration",
                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                    TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
                            TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                    TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
                            TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            // Running this thread after 100 milliseconds
            mHandler.postDelayed(this, 1000);
        }
    };

    public void TrovaEvents(JSONObject jsonObject) {

        String event;
        try {
            event = jsonObject.getString("trovaEvent");
            switch (event) {
                case OnTrovaReceiveCalleeBusy:
                    String callerId = jsonObject.getString("callerId");
                    Toast.makeText(activity, callerId + " is Busy right now", Toast.LENGTH_LONG).show();
                    onfinish();
                    break;
                case OnTrovaAgentInfo:
                    String callMode = jsonObject.getString("callMode");
                    if (callMode.equalsIgnoreCase("audio")) {
                        callerId = jsonObject.getString("callerId");
                        String agentName = jsonObject.getString("agentName");
                        String businessName = jsonObject.getString("displayName");
                        otherUserID = callerId;
                        otherUserName = agentName;
                        ll_trova_voice_call_finding_agent.setVisibility(View.GONE);
                        ll_trova_voice_call_details.setVisibility(View.VISIBLE);
                        mCallingHandler1.removeCallbacks(mUpdateCalling);
                        if (businessName != null && !businessName.isEmpty()) {
                            tv_trova_voice_call_business_name.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_business_name.setText(businessName);
                        } else {
                            tv_trova_voice_call_business_name.setVisibility(View.GONE);
                        }
                        if (otherUserName.isEmpty() || otherUserName.equalsIgnoreCase("")) {
                            tv_trova_voice_call_caller_name.setText(otherUserID);
                            tv_trova_voice_call_caller_id.setText("");
                        } else {
                            tv_trova_voice_call_caller_name.setText(otherUserName);
                            tv_trova_voice_call_caller_id.setText(otherUserID);
                        }
                    }

                    break;
                case OnTrovaReceiveMissedCall:
                    isRejected = true;
                    runOnUiThread(new Runnable() {
                        public void run() {
                            mHandler.removeCallbacks(mUpdateTimeTask);
//                            if(SP.isApplicationLaunched) {
                            setResult(RESULT_CANCELED);
                            onfinish();
//                            } else {
//                                finishAndRemoveTask();
//                            }
                        }
                    });
                    break;
                case OnTrovaReceiveEndCall:
                    runOnUiThread(new Runnable() {
                        public void run() {
                            mHandler.removeCallbacks(mUpdateTimeTask);
//                            if(SP.isApplicationLaunched) {
                            setResult(RESULT_CANCELED);
                            onfinish();
//                            } else {
//                                finishAndRemoveTask();
//                            }
                        }
                    });
                    break;

                case OnTrovaReceiveRejectCall:
                    runOnUiThread(new Runnable() {
                        public void run() {
                            mHandler.removeCallbacks(mUpdateTimeTask);
                            otherUserID = "";
//                            if(SP.isApplicationLaunched) {
                            setResult(RESULT_CANCELED);
                            onfinish();
//                            } else {
//                                finishAndRemoveTask();
//                            }
                        }
                    });
                    break;

                case OnTrovaAcceptedCall:
                    runOnUiThread(new Runnable() {
                        public void run() {
                            img_trova_voice_call_speaker.setVisibility(View.VISIBLE);
                            img_trova_voice_call_mic.setVisibility(View.VISIBLE);
                            img_trova_voice_call_accept.setVisibility(View.GONE);
                            img_trova_voice_call_reject.setVisibility(View.VISIBLE);
                            tv_trova_voice_call_title.setText("On call");
                            isConnected = true;
                            startTime = System.currentTimeMillis();
                            mHandler.postDelayed(mUpdateTimeTask, 100);
                            trovaApi.trovaAudioMute(false);
                        }
                    });
                    break;
                case OnTrovaReceiveLocalStream:
//                mCallingHandler.removeCallbacks(mUpdateCalling);
//                txtCallType.setText("Connected");
//                viewOffHookCallViews();
//                startTime = System.currentTimeMillis();
//                mHandler.postDelayed(mUpdateTimeTask, 100);
//                isConnected = true;
                    break;
//                case OnFailed:
//                    runOnUiThread(new Runnable() {
//                        public void run() {
//                            mHandler.removeCallbacks(mUpdateTimeTask);
////                            if(SP.isApplicationLaunched) {
//                            setResult(RESULT_CANCELED);
//                            onfinish();
////                            } else {
////                                finishAndRemoveTask();
////                            }
//                        }
//                    });
//                    break;

                case OnPermissionsRequired:
                    Toast.makeText(activity, "Permission Required", Toast.LENGTH_SHORT).show();
                    PermissionCheck.requestPermission(activity, PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions()), 1000);
                    break;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
        trovaUICallBack = trovaUIAPICallBack;
    }

    private void postEvent(String event) {
        if (trovaUICallBack != null) {
            JSONObject jobj = new JSONObject();
            try {
                jobj.put("trovaEvent", event);
                jobj.put("callerId", otherUserID);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            trovaUICallBack.setTrovaUICallBack(jobj);
        }
    }*/
}

package arr.trova.in.trovawoui.s3Util;

import android.content.Context;
import android.util.Log;

import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.services.s3.AmazonS3Client;

import org.json.JSONObject;

import java.io.File;

import arr.trova.in.trovawoui.services.TrovaApiService;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.InProgress;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Download;
import static arr.trova.in.trovawoui.s3Util.Upload.amazonAWSBucket;


public class DownloadS3 {

    public DownloadS3() {
    }


    /**
     * This method is used to Download the file to S3 by using transferUtility class
     *
     * @param context
     * @param filePathToStore
     */
    public void downloadFileFromS3(final Context context, String filePathToStore, final String ServerPath) {
        try {
            boolean isFailed = false;
            File file = (filePathToStore == null || filePathToStore.isEmpty()) ? null : new File(filePathToStore);
            File sfile = (ServerPath == null || ServerPath.isEmpty()) ? null : new File(ServerPath);
            if (file == null || sfile == null) {
                isFailed = true;
            } else {
                Upload.setTransferUtility(context);
                String key = ServerPath;
                if (key.contains("amazonaws.com/")) {
                    key = ServerPath.split("amazonaws.com/")[1];
                }
//                key = key.replaceAll("%20", "_");
//                key = key.replaceAll(" ", "_");
                Log.d("Downlaod s3", key);
                TransferObserver transferObserver = Upload.transferUtility.download(
                        amazonAWSBucket,     /* The bucket to download from */
                        key,    /* The key for the object to download */
                        file        /* The file to download the object to */
                );
                Log.d("Downlaod s3", key);
                downloadTransferObserverListener(transferObserver, filePathToStore, Upload.amazonS3Client, ServerPath);
            }
            if (isFailed) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("trovaEvent", OnTrovaAmazonS3_Download);
                    jsonObject.put("state", "failed");
                    JSONObject jsondata = new JSONObject();
                    jsondata.put("localFilePath", filePathToStore);
                    jsondata.put("serverPath", ServerPath);
                    jsonObject.put("data", jsondata);
                    Log.i("S3 downld onSuccess", jsonObject.toString());
                    TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        } catch (ArithmeticException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * * This is listener method of the TransferObserver
     * Within this listener method, we get status of uploading and downloading file,
     * to display percentage of the part of file to be uploaded or downloaded to S3
     * It displays an error, when there is a problem in  uploading or downloading file to or from S3.
     *
     * @param transferObserver
     * @param localFilePath
     * @param amazonS3Client
     * @param serverPath
     */

    private void downloadTransferObserverListener(TransferObserver transferObserver, final String localFilePath, final AmazonS3Client amazonS3Client, final String serverPath) {

        transferObserver.setTransferListener(new TransferListener() {

            @Override
            public void onStateChanged(int id, final TransferState state) {

                if (state == TransferState.COMPLETED) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("trovaEvent", OnTrovaAmazonS3_Download);
                        jsonObject.put("state", "success");
                        JSONObject jsondata = new JSONObject();
                        jsondata.put("localFilePath", localFilePath);
                        jsondata.put("serverPath", serverPath);
                        jsonObject.put("data", jsondata);
                        Log.i("S3 downld onSuccess", jsonObject.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                } else if (state == TransferState.CANCELED || state == TransferState.FAILED) {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("trovaEvent", OnTrovaAmazonS3_Download);
                        jsonObject.put("state", "failed");
                        JSONObject jsondata = new JSONObject();
                        jsondata.put("localFilePath", localFilePath);
                        jsondata.put("serverPath", serverPath);
                        jsondata.put("message", state.name());
                        jsonObject.put("data", jsondata);
                        Log.i("S3 downld onSuccess", jsonObject.toString());
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }


            @Override
            public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                if (bytesTotal != 0)
                    try {
                        int percentage = (int) (bytesCurrent / bytesTotal * 100);
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("trovaEvent", OnTrovaAmazonS3_Download);
                        jsonObject.put("state", InProgress);
                        JSONObject jsondata = new JSONObject();
                        jsondata.put("localFilePath", localFilePath);
                        jsondata.put("serverPath", serverPath);
                        jsondata.put("percentage", percentage);
                        jsonObject.put("data", jsondata);
                        Log.i("S3 downld onSuccess", jsonObject.toString());
                        TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                    } catch (ArithmeticException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

            }

            @Override
            public void onError(int id, final Exception ex) {
                Log.e("error", "error");
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("trovaEvent", OnTrovaAmazonS3_Download);
                    jsonObject.put("state", "failed");
                    JSONObject jsondata = new JSONObject();
                    jsondata.put("localFilePath", localFilePath);
                    jsondata.put("serverPath", serverPath);
                    jsonObject.put("data", jsondata);
                    Log.i("S3 downld onSuccess", jsonObject.toString());
                    TrovaApiService.trovaApiCallback.TrovaEvents(jsonObject);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });
    }
}

package com.example.chandru.laundry.Pojo;


public class addservice {

}

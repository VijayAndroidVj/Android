package arr.trova.in.trovawoui.Utils;

import android.content.Context;
import android.content.SharedPreferences;


/**
 * This class used to store and get the preference value
 */

public class PreferenceUtil {
    private static boolean isApplicationLaunched = false;
    public SharedPreferences sharedpreferences;
    public String TROVA_USERKEY = "TROVA_USERKEY";
    public String TROVA_AGENT_KEY = "TROVA_AGENT_KEY";
    private String TROVA_USERNAME = "TROVA_USERNAME";
    private String TROVA_USER_PHONE = "TROVA_USER_PHONE";
    private String TROVA_CHAT_TO_USER_ONLINE = "TROVA_CHAT_TO_USER_ONLINE";
    private String TROVA_AUDIO_TO_USER_ONLINE = "TROVA_AUDIO_TO_USER_ONLINE";
    private String TROVA_VIDEO_TO_USER_ONLINE = "TROVA_VIDEO_TO_USER_ONLINE";
    private String TROVA_USER_CCODE = "TROVA_USER_CCODE";
    private String TROVA_USER_EMAIL = "TROVA_USER_EMAIL";
    private String TROVA_FCM_TOKEN = "TROVA_FCM_TOKEN";
    private String TROVA_S3_BUCKET = "TROVA_S3_BUCKET";
    private String TROVA_S3_COGNITIO_ID = "TROVA_S3_COGNITIO_ID";
    private String TROVA_S3_REGION = "TROVA_S3_REGION";
    private String TROVA_BUSINESS_KEY = "TROVA_BUSINESS_KEY";
    private String TROVA_USERID = "TROVA_USERID";
    private String TROVA_OLD_USERID = "TROVA_OLD_USERID";
    private String TROVA_LOAD_URL = "TROVA_LOAD_URL";
    private String TROVA_PORT = "TROVA_PORT";
    private String TROVA_IS_WIDGET = "TROVA_IS_WIDGET";
    private String TROVA_IS_RECORD = "TROVA_IS_RECORD";
    private String TROVA_RECORD_FOLDER_NAME = "TROVA_RECORD_FOLDER_NAME";

    private Context context;

    public PreferenceUtil(Context context) {
        this.context = context;
        sharedpreferences = context.getSharedPreferences("TrovaAar" + context.getPackageName(), Context.MODE_PRIVATE);
    }

    public String getUserName() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USERNAME, "");
    }


    public String getUserPhone() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USER_PHONE, "");
    }

    public void setChatUserOnline(String number) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_CHAT_TO_USER_ONLINE, number);
        editor.apply();
    }

    public void setOldUerID(String userId) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_OLD_USERID, userId);
        editor.apply();
    }

    public void setConfRecordFolder(String foldername) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_RECORD_FOLDER_NAME, foldername);
        editor.apply();
    }

    public String getOldUserId() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_OLD_USERID, "");
    }

    public String getRecordFolder() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_RECORD_FOLDER_NAME, "");
    }

    public void setUserKey(String userkey) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_USERKEY, userkey);
        editor.apply();
    }

    public void setUserId(String userid) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_USERID, userid);
        editor.apply();
    }

    public boolean isWidget() {
        return sharedpreferences != null && sharedpreferences.getBoolean(TROVA_IS_WIDGET, false);
    }

    public void setWidget(boolean isWiget) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putBoolean(TROVA_IS_WIDGET, isWiget);
        editor.apply();
    }

    public boolean isChatUserOnline(String number) {
        String user = sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_CHAT_TO_USER_ONLINE, "");
        return user.equalsIgnoreCase(number);
    }

    public void setAudioUserOnline(String number) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_AUDIO_TO_USER_ONLINE, number);
        editor.apply();
    }

    public boolean isAudioUserOnline(String number) {
        String user = sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_AUDIO_TO_USER_ONLINE, "");
        return user.equalsIgnoreCase(number);
    }

    public void setVideoUserOnline(String number) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TROVA_VIDEO_TO_USER_ONLINE, number);
        editor.apply();
    }

    public boolean isVideoUserOnline(String number) {
        String user = sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_VIDEO_TO_USER_ONLINE, "");
        return user.equalsIgnoreCase(number);
    }

    public void saveInitValues(String bKey, String UserId, String name, String userEmail, String userPhone, String userCC, String loadUrl, String port) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor = sharedpreferences.edit();
        editor.putString(TROVA_USERID, UserId);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_USERNAME, name);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_BUSINESS_KEY, bKey);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_USER_EMAIL, userEmail);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_USER_PHONE, userPhone);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_USER_CCODE, userCC);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_LOAD_URL, loadUrl);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_PORT, port);
        editor.apply();

    }

    public void saveInitFcmValues(String fcmToken) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor = sharedpreferences.edit();
        editor.putString(TROVA_FCM_TOKEN, fcmToken);
        editor.apply();
    }

    public void saveInitAwsValues(String amazonAWSBucket, String amazonCognitoId, String region) {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor = sharedpreferences.edit();
        editor.putString(TROVA_S3_BUCKET, amazonAWSBucket);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_S3_COGNITIO_ID, amazonCognitoId);
        editor.apply();

        editor = sharedpreferences.edit();
        editor.putString(TROVA_S3_REGION, region);
        editor.apply();

    }

    public String getCcode() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USER_CCODE, "");
    }

    public String getBusinessKey() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_BUSINESS_KEY, "");
    }

    public String getUserEmail() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USER_EMAIL, "");
    }

    public String getS3CognitioId() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_S3_COGNITIO_ID, "");
    }

    public String getS3Region() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_S3_REGION, "");
    }

    public String getS3Bucket() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_S3_BUCKET, "");
    }

    public String getFcmToken() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_FCM_TOKEN, "");
    }

    public String getUserId() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USERID, "");
    }

    public String getAgentKey() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_AGENT_KEY, "");
    }

    public String getUserKey() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_USERKEY, "");
    }

    public String getLoadUrl() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_LOAD_URL, "");
    }

    public String getPort() {
        return sharedpreferences == null ? "" : sharedpreferences.getString(TROVA_PORT, "");
    }

    public void logout() {
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor = sharedpreferences.edit();
        editor.putString(TROVA_USERID, "");
        editor.putString(TROVA_OLD_USERID, "");
        editor.putString(TROVA_AGENT_KEY, "");
        editor.putString(TROVA_USERKEY, "");
        editor.putString(TROVA_USER_EMAIL, "");
        editor.putString(TROVA_USERNAME, "");

        editor.apply();
    }
}

package arr.trova.in.trovawoui.Utils;

import org.json.JSONObject;

/**
 * Created by iyara_rajan on 10-08-2017.
 */

public interface TrovaReceiveCallBack {

    void receiveCalls(String from, String callType);

    void receiveTextChat(JSONObject data);

    void receiveFileChat(JSONObject data);

    void receiveMissedCall(String from, String callMode);

}

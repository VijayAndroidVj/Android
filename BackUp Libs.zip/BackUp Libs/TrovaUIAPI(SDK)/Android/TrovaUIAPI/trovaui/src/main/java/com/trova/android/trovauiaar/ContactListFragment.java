package com.trova.android.trovauiaar;

import android.app.Fragment;

/**
 * Created by razin on 24/11/17.
 */

public class ContactListFragment extends Fragment {

   /*// ContactListFragmentAdapter contactListAdapter;
    DataBaseHandler dataBaseHandler;
    JSONArray jarrayContacts = new JSONArray();
    public static JSONArray jarrayFilteredContacts = new JSONArray();
    RecyclerView recyclerviewContact;
    SearchView searchviewContact;
   // private static ReachEscalationCallBack reachEscalationCallBack;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_contacts, container, false);
        recyclerviewContact = view.findViewById(R.id.recyclerviewContact);
        searchviewContact = (SearchView) view.findViewById(R.id.searchviewContact);
        view.findViewById(R.id.recyclerviewContact).setVisibility(View.VISIBLE);
        view.findViewById(R.id.txtContactInfo).setVisibility(View.GONE);
        setRegisterUI();
        fetchContacts();
        setAdapter();
        return view;
    }

    private void setRegisterUI() {
        searchviewContact.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                jarrayFilteredContacts = new JSONArray();
                for (int i = 0; i < jarrayContacts.length(); i++) {
                    try {
                        if (jarrayContacts.getJSONObject(i).getString("contact_name").toLowerCase().contains(newText) || jarrayContacts.getJSONObject(i).getString("contact_number").contains(newText)) {
                            jarrayFilteredContacts.put(jarrayContacts.get(i));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                contactListAdapter.notifyDataSetChanged();
                return false;
            }
        });
    }

    private void fetchContacts() {
        dataBaseHandler = new DataBaseHandler(getActivity());
        ArrayList<UserModel> arrList = dataBaseHandler.getFilteredContactList();
//        ArrayList<UserModel> arrList = dataBaseHandler.getAllAgentDisplayCallLogs();
        for (int i = 0; i < arrList.size(); i++) {
            UserModel userModel = arrList.get(i);
            JSONObject job = new JSONObject();
            try {
                job.put("contact_name", userModel.getName());
                job.put("contact_number", userModel.getPhone());
                job.put("contact_user_id", userModel.getUserId());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            jarrayContacts.put(job);
        }
        jarrayFilteredContacts = jarrayContacts;
    }

    public void setAdapter() {
        RecyclerView.LayoutManager LayoutManager = new LinearLayoutManager(getActivity());
        recyclerviewContact.setLayoutManager(LayoutManager);
        recyclerviewContact.setItemAnimator(new DefaultItemAnimator());
        contactListAdapter = new ContactListFragmentAdapter(getActivity(), reachEscalationCallBack);
        recyclerviewContact.setAdapter(contactListAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public static void setCallBack(ReachEscalationCallBack reachEscalationCallBack1) {
        reachEscalationCallBack = reachEscalationCallBack1;
    }*/
}

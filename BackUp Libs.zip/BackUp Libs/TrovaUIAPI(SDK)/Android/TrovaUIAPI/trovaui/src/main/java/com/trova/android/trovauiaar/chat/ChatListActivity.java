package com.trova.android.trovauiaar.chat;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.View;
import android.widget.TextView;

import com.trova.android.trovauiaar.Db.DataBaseHandler;
import com.trova.android.trovauiaar.R;
import com.trova.android.trovauiaar.model.UserModel;

import java.util.ArrayList;

import static android.view.View.VISIBLE;


/**
 * Created by vijay on 1/5/18.
 */


public class ChatListActivity extends AppCompatActivity implements View.OnClickListener {
    private ContactListAdapter contactListAdapter;
    private DataBaseHandler dataBaseHandler;
    static boolean isAgentLog;
    public static ChatListActivity chatListActivity;
    private ArrayList<UserModel> contact_list;


    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
        chatListActivity = this;
        dataBaseHandler = new DataBaseHandler(this);
        setView();
        setRegisterUI();
        reload();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFinishing()) {
            chatListActivity = null;
        }
    }

    public void fetchAgentContacts() {
        try {
            contact_list = dataBaseHandler.getAllAgentDisplayCallLogs();
        } catch (Exception var7) {
            var7.printStackTrace();
        }
    }

    public void fetchContacts() {
        try {
            contact_list = dataBaseHandler.getAllContactDisplayCallLogs();
        } catch (Exception var7) {
            var7.printStackTrace();
        }

    }

    private void setAdapter() {
        if (contact_list == null || contact_list.size() == 0) {
            (this.findViewById(R.id.tv_contact_info)).setVisibility(VISIBLE);
            (this.findViewById(R.id.rv_contact_list)).setVisibility(View.GONE);
        } else {
            (this.findViewById(R.id.tv_contact_info)).setVisibility(View.GONE);
            (this.findViewById(R.id.rv_contact_list)).setVisibility(VISIBLE);
        }

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this.getApplicationContext());


        rv_contact_list.setLayoutManager(mLayoutManager);
        rv_contact_list.setItemAnimator(new DefaultItemAnimator());
        contactListAdapter = new ContactListAdapter(this, contact_list);
        rv_contact_list.setAdapter(contactListAdapter);
    }

    private void setRegisterUI() {
        searchView_contact_list.setOnQueryTextListener((new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            public boolean onQueryTextChange(String newText) {
                try {
                    if (contactListAdapter != null) {
                        contactListAdapter.filter(newText);
                    }
                } catch (Exception var4) {
                    var4.printStackTrace();
                }

                return false;
            }
        }));
        searchView_contact_list.onActionViewExpanded();
        searchView_contact_list.clearFocus();
        searchView_contact_list.setFocusable(false);

    }

    RecyclerView rv_contact_list;
    View tv_contact_info;
    TextView tv_contact_list_title;
    TextView tv_log_contact_Chat_title;
    TextView tv_log_gadget_Chat_title;
    SearchView searchView_contact_list;
    View btnContactsChatLog;
    View btnAgentChatLog;
    View llChatLogs;

    private void setView() {
        findViewById(R.id.img_contact_list_back).setOnClickListener(this);
        rv_contact_list = findViewById(R.id.rv_contact_list);
        tv_contact_list_title = findViewById(R.id.tv_contact_list_title);
        tv_log_contact_Chat_title = findViewById(R.id.tv_log_contact_Chat_title);
        tv_log_gadget_Chat_title = findViewById(R.id.tv_log_gadget_Chat_title);
        tv_contact_info = findViewById(R.id.tv_contact_info);
        searchView_contact_list = findViewById(R.id.searchView_contact_list);
        btnContactsChatLog = findViewById(R.id.btnContactsChatLog);
        btnAgentChatLog = findViewById(R.id.btnAgentChatLog);
        llChatLogs = findViewById(R.id.llChatLogs);

        btnContactsChatLog.setOnClickListener(this);
        btnAgentChatLog.setOnClickListener(this);
        tv_contact_info.setVisibility(View.GONE);
        rv_contact_list.setVisibility(VISIBLE);

        searchView_contact_list.setQueryHint("Type to search");
        searchView_contact_list.setIconified(false);
        searchView_contact_list.clearFocus();

        llChatLogs.setVisibility(VISIBLE);
        btnContactsChatLog.setOnClickListener(this);
        btnAgentChatLog.setOnClickListener(this);
    }

    public void onClick(@Nullable View view) {

        int i = view.getId();
        if (i == R.id.img_contact_list_back) {
            this.finish();
        } else if (i == R.id.btnContactsChatLog) {
            if (isAgentLog) {
                isAgentLog = false;
                tv_contact_list_title.setText("Chat List");
                btnContactsChatLog.setBackgroundResource(R.drawable.bg_tab_call_log_selected_left);
                btnAgentChatLog.setBackgroundResource(R.drawable.bg_tab_call_log_unselected_right);
                tv_log_contact_Chat_title.setTextColor(ContextCompat.getColor(this, R.color.white));
                tv_log_gadget_Chat_title.setTextColor(ContextCompat.getColor(this, R.color.button_background));
                fetchContacts();
                setAdapter();
            }

        } else if (i == R.id.btnAgentChatLog) {
            if (!isAgentLog) {
                isAgentLog = true;
                tv_contact_list_title.setText("Gadget Chat List");
                btnAgentChatLog.setBackgroundResource(R.drawable.bg_tab_call_log_selected_right);
                btnContactsChatLog.setBackgroundResource(R.drawable.bg_tab_call_log_unselected_left);
                tv_log_gadget_Chat_title.setTextColor(ContextCompat.getColor(this,
                        R.color.white));
                tv_log_contact_Chat_title.setTextColor(ContextCompat.getColor(this,
                        R.color.button_background));
                fetchAgentContacts();
                setAdapter();
            }
        }

    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onResume() {
        super.onResume();
        if (isAgentLog) {
            fetchAgentContacts();
            setAdapter();
        } else {
            fetchContacts();
            setAdapter();
        }
    }

    public void reload() {
        try {
            if (isAgentLog) {
                isAgentLog = false;
                btnAgentChatLog.callOnClick();
            } else {
                isAgentLog = true;
                btnContactsChatLog.callOnClick();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

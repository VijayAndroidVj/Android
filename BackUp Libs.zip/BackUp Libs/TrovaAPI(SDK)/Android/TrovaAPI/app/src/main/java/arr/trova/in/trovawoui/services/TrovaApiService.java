package arr.trova.in.trovawoui.services;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.media.AudioManager;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.IceCandidate;
import org.webrtc.SessionDescription;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import aar.trova.in.trovawoui.BuildConfig;
import arr.trova.in.trovawoui.ConfigServer;
import arr.trova.in.trovawoui.Constants;
import arr.trova.in.trovawoui.Utils.AppRTCClient;
import arr.trova.in.trovawoui.Utils.NetworkUtil;
import arr.trova.in.trovawoui.Utils.PreferenceUtil;
import arr.trova.in.trovawoui.Utils.RTCConnection;
import arr.trova.in.trovawoui.Utils.TrovaApiCallback;
import arr.trova.in.trovawoui.s3Util.DownloadS3;
import arr.trova.in.trovawoui.s3Util.Upload;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnGetAllSyncAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnGetAllUnDeliverdMessages;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnRecvSyncAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAcceptedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentChatInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCallState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaConference_End;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaGetAllMessages;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRececiveConfCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCalleeBusy;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCloseChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveConfScreenShare;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndConfCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndScreenShare;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveFile;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveGetAllOfflineReceiveMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveGetAllSyncSendMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveListAvailableAgents;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveMissedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveNotification;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRejectCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRequestToConf;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSDK_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSessionUserOnline;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaWidgetChatInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaWidgetInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_Registration2Server;

public class TrovaApiService extends Service implements SensorEventListener, AppRTCClient.SignalingEvents, RTCConnection.PeerConnectionEvents {
    public static TrovaApiCallback trovaApiCallback;

    static {
        try {
            System.loadLibrary("jingle_peerconnection_so");
        } catch (Error e) {
            e.printStackTrace();
        }
        Thread.UncaughtExceptionHandler h = new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(Thread th, Throwable ex) {
                System.out.println("Uncaught exception: " + ex);
            }
        };
        Thread.setDefaultUncaughtExceptionHandler(h);
    }

    private final IBinder mBinder = new LocalBinder();
    public BlockingQueue<String> sendcandidatesqueue;
    public String trovaUserKey;
    public String trovaConferenceType;
    public String trovaAgentKey;
    public PreferenceUtil preferenceUtil;
    //    private TrovaReceiveCallBack trovaReceiveCallBack;
    public HashMap<String, String> callersList = new HashMap<>();
    public HashMap<String, String> sharecallersList = new HashMap<>();
    public boolean trovaDisconnect = false;
    public boolean trovaAudioMute = false;
    private BlockingQueue<String> queue;
    private BlockingQueue<String> pendingQueue;
    private boolean inCall = false;
    private boolean isAgentInfoReceived = false;
    private boolean allowRegister = true;
    private boolean isAgentChatInfoReceived = false;
    private ServiceBroadCast receiver = new ServiceBroadCast();
    private Socket socket;
    private RTCConnection rtcConnection;
    private AppRTCClient.SignalingEvents callEvents;
    private String version;
    private boolean roomJoined;
    private boolean recordCall;
    private boolean isConferenceOwner;
    private String confId = "";
    private boolean isLoggedIn = false;
    public static final boolean DEBUG = true;


    public static void constructCallback(TrovaApiCallback trovaApiCallback, HashMap<String, Object> values) {
        try {
            JSONObject jsonObject = new JSONObject();
            for (Map.Entry<String, Object> e : values.entrySet()) {
                Object value = e.getValue();
                String key = e.getKey();
                if (value == null)
                    jsonValuePut(jsonObject, key, "");
                else if (value instanceof String)
                    jsonValuePut(jsonObject, key, (String) value);
                else if (value instanceof String[])
                    jsonValuePut(jsonObject, key, (String[]) value);
                else if (value instanceof Integer)
                    jsonValuePut(jsonObject, key, (Integer) value);
                else if (value instanceof Long)
                    jsonValuePut(jsonObject, key, (Long) value);
                else if (value instanceof Boolean)
                    jsonValuePut(jsonObject, key, (Boolean) value);
                else if (value instanceof JSONObject)
                    jsonValuePut(jsonObject, key, (JSONObject) value);
                else if (value instanceof ArrayList)
                    jsonValuePut(jsonObject, key, (ArrayList<String>) value);
            }
            trovaApiCallback.TrovaEvents(jsonObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setTrovaCallBack(TrovaApiCallback trovaCallBack) {
        trovaApiCallback = trovaCallBack;
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, String value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, String[] value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, ArrayList<String> value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, long value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, JSONObject value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, int value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {

            e.printStackTrace();
        }
    }

    public static void jsonValuePut(JSONObject jsonObject, String key, boolean value) {
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void logData(String tag, String message) {
        if (DEBUG)
            System.out.println(tag + " - " + message);
    }

    IceCandidate toJavaCandidate(JSONObject json) throws JSONException {
        logData("", "toJavaCandidate");
        logData("", json.toString());

        String sdpMid;
        if (json.has("sdpMid")) {
            sdpMid = json.getString("sdpMid");
        } else {
            sdpMid = json.getString("id");
        }

        int sdpMLineIndex;
        if (json.has("sdpMLineIndex")) {
            sdpMLineIndex = json.getInt("sdpMLineIndex");
        } else {
            sdpMLineIndex = json.getInt("label");
        }
        logData("", sdpMid);
        logData("", String.valueOf(sdpMLineIndex));
        logData("", json.getString("candidate"));
        return new IceCandidate(sdpMid,
                sdpMLineIndex,
                json.getString("candidate"));
    }

    private void executeStoreCall(String userKey, boolean addConf) {
        if (!TextUtils.isEmpty(userKey) && !userKey.equalsIgnoreCase("null")) {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userKey", userKey);
            jsonValuePut(userObj, "deviceCon", preferenceUtil.isWidget() ? "Widget" : "Mobile");
            jsonValuePut(userObj, "version", version);
            if (addConf)
                jsonValuePut(userObj, "confId", confId);
            else
                jsonValuePut(userObj, "confId", "");

            jsonValuePut(userObj, "pid", android.os.Process.myPid());
            logData("executeStoreCall", userObj.toString());
            if (socket != null && socket.connected()) {
                socket.emit("jSigSock", userObj);
                logData("TrovaApiService --> ", "jSigSock" + "+++++|||||||emitting" + userObj.toString());
                roomJoined = true;
            } else {
                roomJoined = false;
            }
        }
    }

    private void emit(final String e, JSONObject j) {
//        if (DEBUG) {
//            new Handler(Looper.getMainLooper()).post(new Runnable() {
//                @Override
//                public void run() {
//                    Toast.makeText(TrovaApiService.this, "Emitting :" + e + " :: Socket :" + (socket == null ? "not connected" : socket.connected() ? "connected" : "not connected"), Toast.LENGTH_SHORT).show();
//                    // this will run in the main thread
//                }
//            });
//        }
        jsonValuePut(j, "deviceCon", preferenceUtil.isWidget() ? "Widget" : "Mobile");
        if (socket != null && socket.connected() && roomJoined) {
            socket.emit(e, j);
            logData("TrovaApiService --> ", e + "+++++|||||||emitting" + j.toString());
        } else {
            try {
                executePendingQueuePost(e, j);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void executePendingQueuePost(String eventName, JSONObject jsonObject) {
        try {
            if (pendingQueue == null) {
                pendingQueue = new LinkedBlockingQueue<>();
                jsonValuePut(jsonObject, "EventName", eventName);
                pendingQueue.put(jsonObject.toString());
                runPendingQueueThread();
            } else {
                if (!pendingQueue.contains(jsonObject.toString())) {
                    jsonValuePut(jsonObject, "EventName", eventName);
                    pendingQueue.put(jsonObject.toString());
                }
            }
            logData("Posting to Pending Queue", jsonObject.toString());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void executeMakeCallConf(String mode, ArrayList<String> participants, String confId) {
        try {
            if (isLoggedIn) {
                JSONObject jo = new JSONObject();
                jo.put("trovaEvent", OnTrovaSessionUserOnline);
                jo.put("result", "success");
                trovaApiCallback.TrovaEvents(jo);
                onlyDisconnectSocket();
                this.confId = "";
            } else {
                this.confId = md5(preferenceUtil.getBusinessKey() + confId);
                initRtc();
                rtcConnection.callingAudioVideo(mode);
                rtcConnection.createStream(this);
                trovaConferenceType = "Conference";
                logData("", "makecall Called ..... ...");
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "version", version);
                jsonValuePut(userObj, "participantsId", participants);
                jsonValuePut(userObj, "userKey", getUserKey());
                jsonValuePut(userObj, "callMode", mode);
                jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
                jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
                jsonValuePut(userObj, "env", "Mobile");
                jsonValuePut(userObj, "type", trovaConferenceType);
                jsonValuePut(userObj, "confId", this.confId);
                jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
                logData("executejMakeConfCall", userObj.toString());
                emit("jMakeConf", userObj);
                if (mode.equalsIgnoreCase("video"))
                    makeSpeakerOn();
                else {
                    makeEarPiece();
                }

            }
            isLoggedIn = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void makeEarPiece() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setMode(AudioManager.MODE_IN_CALL);
                am.setSpeakerphoneOn(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void makeSpeakerOn() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setMode(AudioManager.STREAM_VOICE_CALL);
                am.setSpeakerphoneOn(true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getUserKey() {
        if (TextUtils.isEmpty(trovaUserKey) && preferenceUtil != null) {
            trovaUserKey = preferenceUtil.getUserKey();
        }
        return trovaUserKey;
    }

    private String md5(String in) {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
            digest.reset();
            digest.update(in.getBytes());
            byte[] a = digest.digest();
            int len = a.length;
            StringBuilder sb = new StringBuilder(len << 1);
            for (byte anA : a) {
                sb.append(Character.forDigit((anA & 0xf0) >> 4, 16));
                sb.append(Character.forDigit(anA & 0x0f, 16));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void executeMakecall(String callerId, String callMode) {
        inCall = true;
        trovaConferenceType = "Normal";
        logData("", "makecall Called ..... ...");
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "version", version);
        jsonValuePut(userObj, "callerId", callerId);
        jsonValuePut(userObj, "userKey", getUserKey());
        jsonValuePut(userObj, "callMode", callMode);
        jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
        jsonValuePut(userObj, "env", "Mobile");
        logData("executeMakecall", userObj.toString());
        if (getUserKey() != null)
            emit("jMakeCall", userObj);

        if (callMode.equalsIgnoreCase("video"))
            makeSpeakerOn();
        else {
            makeEarPiece();
        }
    }

    private void executeReciveCall(JSONObject jsonObject) {

        logData("", "executeReciveCalld ..... ...");
        try {
            String callMode = jsonObject.getString("callMode");
            String callerId = jsonObject.getString("callerId");
            String callerKey = jsonObject.getString("callerKey");
            String callerName = jsonObject.has("userName") ? jsonObject.getString("userName") : "";
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            String agentKey = jsonObject.has("agentKey") ? jsonObject.getString("agentKey") : "";
            String confId = jsonObject.has("confId") ? jsonObject.getString("confId") : "";
            if (DEBUG)
                Log.i("onReceiveCalls ", "type : " + callMode + " , From : " + callerKey);
            callersList.put(callerId, callerKey);
            /*if (!TextUtils.isEmpty(confId) && !TextUtils.isEmpty(agentKey) && inCall) {
                try {
                    this.confId = confId;
                    trovaConferenceType = "Gadget";
                    trovaAgentKey = agentKey;
                    initRtc();
                    if (rtcConnection.lmediaStream == null) {
                        rtcConnection.callingAudioVideo(callMode);
                        rtcConnection.createStream(this);
                    }

                    rtcConnection.createPeerConnection(callerKey);
                    rtcConnection.createOffer(callerKey);

                    JSONObject userObj = new JSONObject();
                    jsonValuePut(userObj, "callerId", callerId);
                    jsonValuePut(userObj, "callMode", callMode);
                    jsonValuePut(userObj, "env", env.toLowerCase());
                    jsonValuePut(userObj, "trovaEvent", OnTrovaAcceptedCall);
                    trovaApiCallback.TrovaEvents(userObj);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else*/
            {
                if (preferenceUtil.isWidget()) {
                    this.confId = confId;
                    trovaConferenceType = "Gadget";
                    trovaAgentKey = agentKey;
                } else if (TextUtils.isEmpty(confId) && TextUtils.isEmpty(agentKey) && !inCall) {
                    this.confId = "";
                    trovaConferenceType = "Normal";
                    trovaAgentKey = "";
                }
                inCall = true;
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "callerId", callerId);
                jsonValuePut(userObj, "callMode", callMode);
                jsonValuePut(userObj, "env", env.toLowerCase());
                jsonValuePut(userObj, "callerName", callerName);
                jsonValuePut(userObj, "agentKey", agentKey);
                jsonValuePut(userObj, "confId", confId);
                jsonValuePut(userObj, "trovaEvent", OnTrovaReceiveCall);
                trovaApiCallback.TrovaEvents(userObj);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executeReciveConfCall(JSONObject jsonObject) {

        logData("", "executeReciveCalld ..... ...");
        try {
            String callMode = jsonObject.getString("callMode");
            String callerId = jsonObject.getString("callerId");
            String callerKey = jsonObject.getString("callerKey");
            if (DEBUG)
                Log.i("onReceiveCalls ", "type : " + callMode + " , From : " + callerKey);
            callersList.put(callerId, callerKey);
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "callerId", callerId);
            jsonValuePut(userObj, "callMode", callMode);
            jsonValuePut(userObj, "env", env.toLowerCase());
            jsonValuePut(userObj, "trovaEvent", OnTrovaRececiveConfCall);
            trovaApiCallback.TrovaEvents(userObj);
            if (rtcConnection != null && rtcConnection.peerConnectionMap != null) {
                rtcConnection.closeConf(callerKey);

            }
//            executeAnswerCall(callerKey, callMode);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executeAnswerCall(String callerKey, String callMode) {

        if (callersList.containsKey(callerKey)) {
            callerKey = callersList.get(callerKey);
        }
        logData("", "Answer Called ........");
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "callerKey", callerKey);
        jsonValuePut(userObj, "userKey", getUserKey());
        jsonValuePut(userObj, "callMode", callMode);
        jsonValuePut(userObj, "agentKey", trovaAgentKey);
        logData("executeAnswerCall", userObj.toString());
        emit("jAnswerCall", userObj);
    }


    private void executeCallAccepted(JSONObject obj) {
        String callerKey;
        String callMode;
        inCall = true;
        try {
            String callerId = obj.getString("callerId");
            callerKey = obj.getString("callerKey");
            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            callersList.put(callerId, callerKey);
            callMode = obj.get("callMode").toString();
            try {

                initRtc();
                if (rtcConnection.lmediaStream == null) {
                    rtcConnection.callingAudioVideo(callMode);
                    rtcConnection.createStream(this);
                }

                rtcConnection.createPeerConnection(callerKey);
                rtcConnection.createOffer(callerKey);

                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "callerId", callerId);
                jsonValuePut(userObj, "callMode", callMode);
                jsonValuePut(userObj, "env", env.toLowerCase());
                jsonValuePut(userObj, "trovaEvent", OnTrovaAcceptedCall);
                trovaApiCallback.TrovaEvents(userObj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeCallConnection(String callerKey, String callMode, JSONObject rtcData, boolean screenShare) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "userKey", getUserKey());
        if (callersList != null && callersList.containsKey(callerKey)) {
            callerKey = callersList.get(callerKey);
        }
        jsonValuePut(userObj, "callerKey", callerKey);
        jsonValuePut(userObj, "callMode", callMode);
        jsonValuePut(userObj, "RTCData", rtcData);
        if (confId == null) {
            confId = "";
        }
        jsonValuePut(userObj, "confId", confId);
        if (trovaConferenceType != null && trovaConferenceType.equalsIgnoreCase("Gadget")) {
            if (TextUtils.isEmpty(trovaAgentKey))
                jsonValuePut(userObj, "folderName", preferenceUtil.getRecordFolder());
            else
                jsonValuePut(userObj, "folderName", trovaAgentKey);
        } else {
            jsonValuePut(userObj, "folderName", preferenceUtil.getRecordFolder());

        }

        logData("executeCallConnection ", userObj.toString());
        emit(screenShare ? "jScreenShareCon" : "jCallCon", userObj);
    }

    private void executeAddToConf(JSONObject obj) {
        try {
            String senderID = obj.has("senderId") ? obj.getString("senderId") : "";
            String senderKey = obj.has("senderKey") ? obj.getString("senderKey") : "";
            String widgetKey = obj.has("widgetKey") ? obj.getString("widgetKey") : "";
            String widgetId = obj.has("widgetId") ? obj.getString("widgetId") : "";
            mainAgentUserId = obj.has("mainAgentUserId") ? obj.getString("mainAgentUserId") : "";
            callersList.put(senderID, senderKey);
            callersList.put(widgetId, widgetKey);
            Object objectnoification = obj.get("extraData");

            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            JSONObject jsonObject = new JSONObject();
//            String event = jsonObject.getString("event");
            if (senderID != null && !senderID.isEmpty())
                jsonObject.put("senderId", senderID);
            if (objectnoification instanceof JSONObject) {
                jsonObject.put("extraData", jsonObject.toString());
            } else {
                jsonObject.put("extraData", objectnoification.toString());
            }
            if (inCall) {
                if (!TextUtils.isEmpty(senderID))
                    executeCallBusy(senderID);
            } else {
                trovaAgentKey = obj.getString("agentKey");
                confId = obj.getString("confId");
                trovaConferenceType = "Gadget";
                jsonObject.put("env", env.toLowerCase());
                jsonObject.put("trovaEvent", OnTrovaRequestToConf);
                trovaApiCallback.TrovaEvents(jsonObject);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeRecivedNotification(JSONObject obj) {
        try {
            String senderID = obj.has("senderId") ? obj.getString("senderId") : "";
            Object objectnoification = obj.get("notification");

            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            JSONObject jsonObject = new JSONObject();
//            String event = jsonObject.getString("event");
            if (senderID != null && !senderID.isEmpty())
                jsonObject.put("senderId", senderID);
            if (objectnoification instanceof JSONObject) {
                jsonObject.put("notification", objectnoification.toString());
            } else {
                jsonObject.put("notification", objectnoification == null ? "" : objectnoification.toString());
            }
            jsonObject.put("env", env.toLowerCase());
            jsonObject.put("trovaEvent", OnTrovaReceiveNotification);
            trovaApiCallback.TrovaEvents(jsonObject);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private String mainAgentUserId;

    public void despatchAddToConfNotification(String extraData, String receiverId) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "extraData", extraData);
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "senderKey", getUserKey());
        jsonValuePut(userObj, "receiverId", receiverId);
        jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
        jsonValuePut(userObj, "confId", confId);
        if (TextUtils.isEmpty(mainAgentUserId)) {
            mainAgentUserId = preferenceUtil.getUserId();
        }
        jsonValuePut(userObj, "mainAgentUserId", mainAgentUserId);
        jsonValuePut(userObj, "agentKey", trovaAgentKey);
        boolean added = false;
        if (callersList.size() > 0) {
            for (Map.Entry<String, String> e : callersList.entrySet()) {
                String value = e.getValue();
                if (value.contains("GADGET")) {
                    String key = e.getKey();
                    jsonValuePut(userObj, "widgetKey", value);
                    jsonValuePut(userObj, "widgetId", key);
                    added = true;
                    break;
                }
            }
        }
        if (!added) {
            jsonValuePut(userObj, "widgetKey", "");
            jsonValuePut(userObj, "widgetId", "");
        }
        emit("jAddToConf", userObj);
    }

    public void despatchNotification(String notification, String receiverId, String priority, int ttl, String subTitle, String displayText) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "notification", notification);
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "senderKey", getUserKey());
        jsonValuePut(userObj, "receiverId", receiverId);
        jsonValuePut(userObj, "priority", priority);
        jsonValuePut(userObj, "ttl", ttl);
        jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
        jsonValuePut(userObj, "subTitle", subTitle);
        jsonValuePut(userObj, "displayText", displayText);
        emit("jSendNotification", userObj);
    }

    private void executeReceiveConnection(JSONObject obj) {
        try {
            String rtcDataStr = obj.getString("RTCData");
            String callerKey = obj.getString("callerKey");
            JSONObject rtcData = new JSONObject(rtcDataStr);
            String type = rtcData.getString("type")/*.toUpperCase()*/;
            if (!type.equals("candidate"))
                type = type.toUpperCase();
            logData("", "type :" + type);
            if (type.equals("candidate")) {
                if (callEvents != null) {
                    callEvents.onRemoteIceCandidate(toJavaCandidate(rtcData), callerKey, false);
                }
            } else if (type.equals("OFFER") || type.equals("ANSWER")) {

                if (rtcConnection == null) {
                    initRtc();
                }
                if (type.equals("OFFER")) {
                    rtcConnection.createPeerConnection(callerKey);

                }
                logData("", "OFFER" + callEvents);
                if (callEvents != null) {
                    SessionDescription sdp = new SessionDescription(
                            SessionDescription.Type.fromCanonicalForm(type),
                            rtcData.getString("sdp"));
                    callEvents.onRemoteDescription(sdp, callerKey, false);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executeEndcall(String callerKey, String callType) {
        logData("", "sendEndcall2Server Called ........");
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "userKey", getUserKey());
        if (callersList != null && callersList.containsKey(callerKey)) {
            callerKey = callersList.get(callerKey);
        }
        jsonValuePut(userObj, "callerKey", callerKey);
        jsonValuePut(userObj, "callMode", callType);
        logData("executeEndcall", userObj.toString());
        emit("jEndCall", userObj);
    }

    private void excecuteEnableMic(boolean mute) {
        try {
            if (rtcConnection != null) {
                if (mute) {
                    rtcConnection.setAudioEnabled(false);
                } else {
                    rtcConnection.setAudioEnabled(true);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void executeVideoMute(boolean mute) {
        try {
            if (rtcConnection != null) {
                rtcConnection.stopVideo(mute);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void audioStreamEnable(boolean mute) {
        if (rtcConnection != null) {
            try {
                if (mute) {
                    trovaAudioMute = true;
                    rtcConnection.setSpeakerMute();
                } else {
                    trovaAudioMute = false;
                    rtcConnection.setSpeakerUnMute();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void executeTrovaSendConfNotification(String confId, String notification, String priority, int ttl) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "confId", md5(preferenceUtil.getBusinessKey() + confId));
            jsonValuePut(userObj, "notification", notification);
            jsonValuePut(userObj, "priority", priority);
            jsonValuePut(userObj, "ttl", ttl);
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "userKey", getUserKey());
            emit("jSendConfNotification", userObj);
            logData("", "executeTrovaSendConfNotification Called ........" + userObj.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeEndConfOnly(ArrayList<String> participants, String callType, String confId, boolean isfromConf) {

        try {
            logData("", "sendEndcall2Server Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "participantsId", participants);
            jsonValuePut(userObj, "callMode", callType);
            jsonValuePut(userObj, "isConferenceOwner", isConferenceOwner ? "true" : "false");
            jsonValuePut(userObj, "confId", isfromConf ? confId : md5(preferenceUtil.getBusinessKey() + confId));
            logData("executeEndConfcall", userObj.toString());
            emit("jEndConf", userObj);
            this.confId = "";
            if (rtcConnection != null && rtcConnection.peerConnectionMap != null) {
                if (rtcConnection.peerConnectionMap.size() == 0) {
                    rtcConnection.freeupAllSource();
                    recordCall = false;
                    trovaConferenceType = "";
                    this.confId = "";
                    trovaAgentKey = "";
                    inCall = false;
                    isAgentInfoReceived = false;
                    mainAgentUserId = "";
                    callersList.clear();
                } else {
                    inCall = false;
                    trovaConferenceType = "";
                    mainAgentUserId = "";
                    int count = 0;
                    int totalsize = rtcConnection.peerConnectionMap.size();
                    for (Object o : rtcConnection.peerConnectionMap.entrySet()) {
                        Map.Entry item = (Map.Entry) o;
                        count = count + 1;
                        String key = (String) item.getKey();
                        if (count == totalsize) {
                            rtcConnection.close(key);
                        } else {
                            rtcConnection.closeAllInConf(key);
                        }
                    }
                    rtcConnection.peerConnectionMap.clear();
                    callersList.clear();
                }
                    /*otherUserId = callersList.get(otherUserId);
                    if (rtcConnection.peerConnectionMap.containsKey(otherUserId)) {
                        rtcConnection.closeConf(otherUserId);
                }*/
            } else {
                recordCall = false;
                isAgentInfoReceived = false;
                trovaConferenceType = "";
                this.confId = "";
                trovaAgentKey = "";
                mainAgentUserId = "";
                inCall = false;
                if (rtcConnection != null) {
                    rtcConnection.freeupAllSource();
                    rtcConnection.lmediaStream = null;
                }
                rtcConnection = null;
                callersList.clear();
            }
            if (rtcConnection == null || rtcConnection.peerConnectionMap == null || rtcConnection.peerConnectionMap.size() == 0) {
                recordCall = false;
                trovaConferenceType = "";
                this.confId = "";
                trovaAgentKey = "";
                mainAgentUserId = "";
                inCall = false;
                isAgentInfoReceived = false;
                if (rtcConnection != null) {
                    rtcConnection.freeupAllSource();
                    rtcConnection.lmediaStream = null;
                }
                rtcConnection = null;
                callersList.clear();
                Log.w("Rtc ", "null");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeEndConfcall(ArrayList<String> participants, String callType, String confId, boolean isfromConf) {

        try {
            logData("", "sendEndcall2Server Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "participantsId", participants);
            jsonValuePut(userObj, "callMode", callType);
            jsonValuePut(userObj, "isConferenceOwner", isConferenceOwner ? "true" : "false");
            jsonValuePut(userObj, "confId", isfromConf ? confId : md5(preferenceUtil.getBusinessKey() + confId));
            logData("executeEndConfcall", userObj.toString());
            emit("jEndConf", userObj);
            this.confId = "";
            if (rtcConnection != null) {
                boolean clear = false;
                int count = 0;

                int totalsize = rtcConnection.peerConnectionMap.size();
                if (totalsize == 0) {
                    if (rtcConnection != null) {
                        rtcConnection.freeupAllSource();
                        rtcConnection.lmediaStream = null;
                    }
                } else {
                    for (Object o : rtcConnection.peerConnectionMap.entrySet()) {
                        Map.Entry item = (Map.Entry) o;
                        count = count + 1;
                        String key = (String) item.getKey();
                        if (count == totalsize) {
                            rtcConnection.close(key);
                        } else {
                            rtcConnection.closeAllInConf(key);
                        }
                        clear = true;
                    }
                }
                rtcConnection.peerConnectionMap.clear();
                rtcConnection.sspeerConnectionMap.clear();
                if (clear || totalsize == 0) {
                    rtcConnection = null;
                    callEvents = null;
                }

                trovaAudioMute = false;

                JSONObject jsonObject1 = new JSONObject();
                try {
                    jsonObject1.put("trovaEvent", OnTrovaConference_End);
                    jsonObject1.put("callerId", participants.toString());
                    jsonObject1.put("callMode", callType);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                trovaApiCallback.TrovaEvents(jsonObject1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void endPeerConnection(String callerKey, String callerId) {
        try {
            if (trovaConferenceType == null || !trovaConferenceType.equalsIgnoreCase("Conference")) {
                inCall = false;
                isAgentInfoReceived = false;
                if (rtcConnection != null && rtcConnection.peerConnectionMap.containsKey(callerKey)) {
                    rtcConnection.close(callerKey);
                    rtcConnection = null;
                    callEvents = null;
                    trovaConferenceType = "";
                    mainAgentUserId = "";
                }
                callersList.remove(callerId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReciveEndcall(JSONObject obj) {
        try {
            inCall = false;
            isAgentInfoReceived = false;
            String callerId = obj.get("callerId").toString();
            String callerKey = obj.get("callerKey").toString();
            String callMode = obj.has("callMode") ? obj.get("callMode").toString() : "";
            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            if (rtcConnection != null && rtcConnection.peerConnectionMap.containsKey(callerKey)) {
                rtcConnection.close(callerKey);
                rtcConnection = null;
                callEvents = null;
                trovaConferenceType = "";
                mainAgentUserId = "";
            }
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaReceiveEndCall);
                jsonObject1.put("callerId", callerId);
                jsonObject1.put("callMode", callMode);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
            callersList.remove(callerId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeRejectCall(String otherUserId, String callerKey, String callMode) {
        logData("", "reject Called ........");
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "userKey", getUserKey());
        jsonValuePut(userObj, "callerKey", callerKey);
        jsonValuePut(userObj, "callMode", callMode);
        emit("jRejectCall", userObj);

        callersList.remove(otherUserId);

    }

    private void executeReciveRejectCall(JSONObject obj) {
        try {
            inCall = false;
            isAgentInfoReceived = false;
            //setTostMessage("Call rejected", context);
            // String callerKey = obj.get("callerKey").toString();
            String callMode = obj.get("callMode").toString();
            String callerId = obj.get("callerId").toString();
            callersList.remove(callerId);
            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("trovaEvent", OnTrovaReceiveRejectCall);
                jsonObject.put("callerId", callerId);
                jsonObject.put("callMode", callMode);
                jsonObject.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (rtcConnection == null || rtcConnection.peerConnectionMap == null || rtcConnection.peerConnectionMap.size() == 0) {
                inCall = false;
                trovaConferenceType = "";
                mainAgentUserId = "";
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private boolean callSigSock = false;

    private void executeRegistrationResult(JSONObject jsonObject) {
        try {
            allowRegister = true;
            String result = jsonObject.getString("result");
            if (DEBUG)
                Log.i("sregisterresult", jsonObject.toString() + " trovaApiCallback : " + trovaApiCallback);
            if (result.equals("success")) {
                String userkey = "";
                if (jsonObject.has("userKey")) {
                    userkey = jsonObject.getString("userKey");
                } else {
                    userkey = jsonObject.getString("userkey");
                }

                String oldUserKey = getUserKey();
                if (DEBUG)
                    Log.w("Inside Out: ", "Old Userkey :" + oldUserKey + " , New Userkey :" + userkey);

                if (TextUtils.isEmpty(oldUserKey) || oldUserKey.equalsIgnoreCase(userkey)) {
                    preferenceUtil.setUserKey(userkey);
                    preferenceUtil.setOldUerID(preferenceUtil.getUserId());
                    if (DEBUG)
                        Log.w("Inside : ", "Old Userkey :" + oldUserKey + " , New Userkey :" + userkey);
                    trovaUserKey = userkey;
                    executeStoreCall(userkey, false);
                    callSigSock = true;
                } else {
                    preferenceUtil.sharedpreferences.edit().clear().apply();
                    callSigSock = false;
                    trovaUserKey = "";
                    result = "alreadySignedIn";
                    disconnectSocket();
                }

            } else {
                preferenceUtil.setUserKey("");
                preferenceUtil.setOldUerID("");
            }
            if (DEBUG)
                Log.i("sregisterresult1", jsonObject.toString());
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaSDK_Init);
                jsonObject1.put("result", result);
                String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                if (env.equalsIgnoreCase("dashboard")) {
                    env = "browser";
                }
                if (result.equalsIgnoreCase("success")) {
                    jsonObject1.put("msg", "Registered Successfully");
                } else {
                    String userId = preferenceUtil.getUserId();
                    String bKey = preferenceUtil.getBusinessKey();
                    if (TextUtils.isEmpty(userId))
                        jsonObject1.put("msg", "userId is empty");
                    else if (TextUtils.isEmpty(bKey)) {
                        jsonObject1.put("msg", "businessKey is empty");
                    } else {
                        jsonObject1.put("msg", "Already signed in different device");
                    }
                }
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void executeRegisterProfile(boolean isWidget, String bKey, String name, String email, String phone, String cCode) {
        if (allowRegister) {
            allowRegister = false;
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "contactPhone", phone);
            jsonValuePut(userObj, "contactName", name);
            jsonValuePut(userObj, "contactEmail", email);
            jsonValuePut(userObj, "contactCcode", cCode);
            jsonValuePut(userObj, "businessKey", bKey);
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            String oldUserId = preferenceUtil.getOldUserId();
            if (!oldUserId.equalsIgnoreCase(preferenceUtil.getUserId()) || TextUtils.isEmpty(getUserKey())) {
                jsonValuePut(userObj, "mode", "insert");
                trovaUserKey = "";
                preferenceUtil.setUserKey("");
            } else {
                jsonValuePut(userObj, "mode", "update");
            }
            emit(isWidget ? "jWidgetRegister" : "jRegister", userObj);
            if (DEBUG)
                Log.i(isWidget ? "jWidgetRegister" : "jRegister", userObj.toString());
        }

    }

    private void executeCreateConnection(String callerId) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "callerId", callerId);
        emit("jCreateConnection", userObj);
    }

    public void executeStoreAudioStatus(String[] audioStats) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "audioStats", Arrays.toString(audioStats));
        emit("jAudioStats", userObj);
    }

    public void executeStoreVideoStatus(String[] videoStats) {
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "videoStats", Arrays.toString(videoStats));
        emit("jVideoStats", userObj);
    }

    private void executeQueuePost(JSONObject jsonObject) {
        try {
            if (queue == null) {
                queue = new LinkedBlockingQueue<>();
                queue.put(jsonObject.toString());
                runQueueThread();
            } else {
                queue.put(jsonObject.toString());
            }
            logData("Posting to Queue", jsonObject.toString());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void executeCandidateQueuePost(JSONObject jsonObject) {
        if (sendcandidatesqueue == null) {
            sendcandidatesqueue = new LinkedBlockingQueue<>();
            runCandidatesQueueThread();
        }
        try {
            logData("Posting to Queue", jsonObject.toString());
            sendcandidatesqueue.put(jsonObject.toString());
        } catch (InterruptedException e) {

            e.printStackTrace();
        }
    }

    public void disconnectSocket() {
        callSigSock = false;
        roomJoined = false;
        if (socket != null) {
            socket.off();
            socket.disconnect();
            logData("", "Calling disconnectSocket ............");
            socket.close();
            if (pendingQueue != null)
                pendingQueue.clear();
            pendingThread = null;
            socket = null;
        }
    }


    public void onlyDisconnectSocket() {
        callSigSock = false;
        roomJoined = false;
        if (socket != null) {
            socket.disconnect();
            socket = null;
            if (pendingQueue != null)
                pendingQueue.clear();
            pendingThread = null;
            logData("", "Calling disconnectSocket ............");
        }
    }

    private Thread pendingThread;

    private void runPendingQueueThread() {
        if (pendingThread == null) {
            pendingThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    String queu;
                    while (true) {
                        try {
                            if (socket != null && socket.connected()) {
                                queu = pendingQueue.take();

                                JSONObject jsonObject = new JSONObject(queu);
                                String event = jsonObject.has("EventName") ? jsonObject.getString("EventName") : "";
                                if (!event.isEmpty())
                                    jsonObject.remove("EventName");

                                socket.emit(event, jsonObject);
                                logData("TrovaApiService --> ", event + "+++++|||||||emitting Pending" + jsonObject.toString());
                            } else {
                                Thread.sleep(1000);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            });
            pendingThread.start();
        }

    }


    private void runQueueThread() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String queu;
                String callerId;

                while (true) {
                    try {
                        queu = queue.take();
                        final JSONObject jsonObject = new JSONObject(queu);

                        if (DEBUG) {
//                            new Handler(Looper.getMainLooper()).post(new Runnable() {
//                                @Override
//                                public void run() {
//                                    try {
//                                        Toast.makeText(TrovaApiService.this, "Emitting :" + jsonObject.getString("trovaEvent") + " :: Socket :" + (socket == null ? "not connected" : socket.connected() ? "connected" : "not connected"), Toast.LENGTH_SHORT).show();
//                                    } catch (JSONException e) {
//                                        e.printStackTrace();
//                                    }
//                                    // this will run in the main thread
//                                }
//                            });
                        }

                        switch (jsonObject.getString("trovaEvent")) {
                            case "sInitReciverCall":
                                String callerKey = jsonObject.getString("callerKey");
                                if (rtcConnection != null) {
                                    rtcConnection.createPeerConnection(callerKey);
                                    rtcConnection.createOffer(callerKey);
                                }

                                break;
                            case "sRecvCall":
//                                    initRtc();
                                executeReciveCall(jsonObject);
                                break;
                            case "sJoinedConf":
//                                    initRtc();
                                executeJoinedConf(jsonObject);
                                break;
                            case "sRecvConfCall":
                                //initRtc();
                                executeReciveConfCall(jsonObject);
                                break;
                            case "sRecvCon":
                                executeReceiveConnection(jsonObject);
                                break;
                            case "sRecvNotification":
                                executeRecivedNotification(jsonObject);
                                break;
                            case "sAddToConf":
                                executeAddToConf(jsonObject);
                                break;
                            case "sAcceptedCall":
                                executeCallAccepted(jsonObject);
                                break;
                            case "sRecvConfScreenShare":
                                executesRecvConfScreenShare(jsonObject);
                                break;
                            case "sRecvScreenShareCon":
                                executesRecvScreenShareCon(jsonObject);
                                break;
                            case "sEndConfScreenShare":
                                executesEndConfScreenShare(jsonObject);
                                break;
                            case "sVideoMute":
                                executeReciveVideoMute(jsonObject);
                                break;
                            case "sVideoUnMute":
                                executeReciveVideoUnMute(jsonObject);
                                break;
                            case "sRejectCall":
                                executeReciveRejectCall(jsonObject);
                                break;
                            case "sCalleeBusy":
                                executeReceiveCalleeBusy(jsonObject);
                                break;
                            case "sMissedCall":
                                if (DEBUG)
                                    Log.i("onReceiveMessage ", "sMissedCall : " + jsonObject.toString());
//                                callerKey = jsonObject.getString("callerKey");
                                callerId = jsonObject.getString("callerId");
                                String callMode = jsonObject.getString("callMode");
                                String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                                if (env.equalsIgnoreCase("dashboard")) {
                                    env = "browser";
                                }
                                JSONObject jsonObject1 = new JSONObject();
                                try {
                                    jsonObject1.put("trovaEvent", OnTrovaReceiveMissedCall);
                                    jsonObject1.put("callerId", callerId);
                                    jsonObject1.put("callMode", callMode);
                                    jsonObject1.put("env", env.toLowerCase());
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                trovaApiCallback.TrovaEvents(jsonObject1);
                                if (rtcConnection == null || rtcConnection.peerConnectionMap == null || rtcConnection.peerConnectionMap.size() == 0) {
                                    inCall = false;
                                    trovaConferenceType = "";
                                    mainAgentUserId = "";
                                }
                                break;
                            case "sEndCall":
                                executeReciveEndcall(jsonObject);
                                break;
                            case "sEndConfCall":
                                executeReciveEndConfCall(jsonObject);
                                break;
                            case "sRegisterResult":
                                executeRegistrationResult(jsonObject);
                                break;
                            case "sSockResult":
                                executeSockResult(jsonObject);
                                break;
                            case "sUpdateAgentChatStatus":
                                executeReceiveAgentChatStatus(jsonObject);
                                break;
                            case "sUpdateAgentStatus":
                                executeReceiveAgentStatus(jsonObject);
                                break;
                            case "sListAvailableAgents":
                                executeReceiveAgentListStatus(jsonObject);
                                break;
                            case "sAgentChatInfo":
                                executeReceivesAgentChatInfo(jsonObject);
                                break;
                            case "sAgentInfo":
                                executeReceivesAgentInfo(jsonObject);
                                break;
                            case "sCloseChat":
                                isAgentChatInfoReceived = false;
                                callerId = jsonObject.get("callerId").toString();
                                jsonObject1 = new JSONObject();
                                try {
                                    env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                                    if (env.equalsIgnoreCase("dashboard")) {
                                        env = "browser";
                                    }
                                    jsonObject1.put("trovaEvent", OnTrovaReceiveCloseChat);
                                    jsonObject1.put("callerId", callerId);
                                    jsonObject1.put("env", env.toLowerCase());
                                    trovaApiCallback.TrovaEvents(jsonObject1);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;
                            case "sRecvChat":
                                if (DEBUG)
                                    Log.i("onReceiveMessage ", "message : " + jsonObject.toString());
                                jsonObject1 = new JSONObject();
                                JSONObject main = new JSONObject(jsonObject.toString());
                                JSONObject messageData = new JSONObject(main.getString("chatdata"));
                                if (messageData.getString("mode").equals("text")) {
                                    String senderId = "";
                                    if (messageData.has("senderId")) {
                                        senderId = messageData.getString("senderId");
                                    } else if (main.has("senderId")) {
                                        senderId = main.getString("senderId");
                                    }

                                    String sendername = "";
                                    if (messageData.has("senderName")) {
                                        sendername = messageData.getString("senderName");
                                    } else if (main.has("senderName")) {
                                        sendername = main.getString("senderName");
                                    }
                                    env = main.has("deviceCon") ? main.getString("deviceCon") : "";
                                    if (env.equalsIgnoreCase("dashboard")) {
                                        env = "browser";
                                    }
                                    jsonObject1.put("senderId", senderId);
                                    jsonValuePut(jsonObject1, "senderName", sendername);
                                    jsonObject1.put("productId", messageData.getString("productId"));
                                    jsonObject1.put("messageId", messageData.getString("messageId"));
                                    jsonObject1.put("message", messageData.getString("message"));
                                    jsonValuePut(jsonObject1, "env", env.toLowerCase());
                                    jsonValuePut(jsonObject1, "trovaEvent", OnTrovaReceiveChat);
                                    trovaApiCallback.TrovaEvents(jsonObject1);
                                } else {
                                    String senderId = "";
                                    if (messageData.has("senderId")) {
                                        senderId = messageData.getString("senderId");
                                    } else if (main.has("senderId")) {
                                        senderId = main.getString("senderId");
                                    }

                                    env = main.has("deviceCon") ? main.getString("deviceCon") : "";
                                    if (env.equalsIgnoreCase("dashboard")) {
                                        env = "browser";
                                    }

                                    String sendername = "";
                                    if (messageData.has("senderName")) {
                                        sendername = messageData.getString("senderName");
                                    } else if (main.has("senderName")) {
                                        sendername = main.getString("senderName");
                                    }
                                    jsonValuePut(jsonObject1, "senderName", sendername);
                                    jsonObject1.put("senderId", senderId);
                                    jsonObject1.put("productId", messageData.getString("productId"));
                                    jsonObject1.put("messageId", messageData.getString("messageId"));
                                    jsonObject1.put("fileType", messageData.getString("filetype"));
                                    jsonObject1.put("fileName", messageData.getString("filename"));
                                    jsonObject1.put("filePath", messageData.getString("filepath"));
                                    jsonObject1.put("mediaDuration", messageData.getString("mediaduration"));
                                    jsonObject1.put("fileSize", messageData.getString("filesize"));
                                    jsonValuePut(jsonObject1, "env", env.toLowerCase());
                                    jsonObject1.put("trovaEvent", OnTrovaReceiveFile);
                                    trovaApiCallback.TrovaEvents(jsonObject1);
                                }
                                break;
                            case "sGetAllSynMessages":
                                executeReceiveAllMessage(jsonObject);
                                break;
                            case "sGetAllMessages":
                                executeReceiveAllMessage(jsonObject);
                                break;
                            case "sGetAllSyncSendMessage":
                                executeReceiveGetAllSyncSendMessage(jsonObject);
                                break;
                            case "sGetAllUnDeliverdMessage":
                                executeReceiveGetAllUndelivered(jsonObject);
                                break;
                            case "sGetAllOfflineReceiveMessage":
                                executeReceiveGetAllOfflineMessage(jsonObject);
                                break;
                            case "sGetAllSyncAppState":
                                executeReceiveGetAllSyncAppState(jsonObject);
                                break;
                            case "sSyncAppState":
                                executeReceiveSyncAppState(jsonObject);
                                break;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }).start();

    }

    private void executeJoinedConf(JSONObject jsonObject) {

        logData("", "executeReciveCalld ..... ...");
        try {
            String callMode = jsonObject.getString("callMode");
            String callerId = jsonObject.getString("callerId");
            String callerKey = jsonObject.getString("callerKey");
            String callerName = jsonObject.has("callerName") ? jsonObject.getString("callerName") : "";
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            String agentKey = jsonObject.has("agentKey") ? jsonObject.getString("agentKey") : "";
            String confId = jsonObject.has("confId") ? jsonObject.getString("confId") : "";
            if (DEBUG)
                Log.i("onReceiveCalls ", "type : " + callMode + " , From : " + callerKey);
            callersList.put(callerId, callerKey);
            if (!TextUtils.isEmpty(confId) && !TextUtils.isEmpty(agentKey) && inCall) {
                try {
                    this.confId = confId;
                    trovaConferenceType = "Gadget";
                    trovaAgentKey = agentKey;
                    initRtc();
                    if (rtcConnection.lmediaStream == null) {
                        rtcConnection.callingAudioVideo(callMode);
                        rtcConnection.createStream(this);
                    }

                    rtcConnection.createPeerConnection(callerKey);
                    rtcConnection.createOffer(callerKey);

                    JSONObject userObj = new JSONObject();
                    jsonValuePut(userObj, "callerId", callerId);
                    jsonValuePut(userObj, "callMode", callMode);
                    jsonValuePut(userObj, "env", env.toLowerCase());
                    jsonValuePut(userObj, "trovaEvent", OnTrovaAcceptedCall);
                    trovaApiCallback.TrovaEvents(userObj);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                if (preferenceUtil.isWidget()) {
                    this.confId = confId;
                    trovaConferenceType = "Gadget";
                    trovaAgentKey = agentKey;
                } else if (TextUtils.isEmpty(confId) && TextUtils.isEmpty(agentKey) && !inCall) {
                    this.confId = "";
                    trovaConferenceType = "Normal";
                    trovaAgentKey = "";
                }
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "callerId", callerId);
                jsonValuePut(userObj, "callMode", callMode);
                jsonValuePut(userObj, "env", env.toLowerCase());
                jsonValuePut(userObj, "callerName", callerName);
                jsonValuePut(userObj, "agentKey", agentKey);
                jsonValuePut(userObj, "confId", confId);
                jsonValuePut(userObj, "trovaEvent", OnTrovaAcceptedCall);
                trovaApiCallback.TrovaEvents(userObj);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveGetAllSyncSendMessage(JSONObject jsonObject) {
        try {
            String message = jsonObject.getString("message");
            JSONObject jsonObject1 = new JSONObject();
            try {
                String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                if (env.equalsIgnoreCase("dashboard")) {
                    env = "browser";
                }
                jsonObject1.put("trovaEvent", OnTrovaReceiveGetAllSyncSendMessage);
                jsonObject1.put("data", message);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void executeReceiveSyncAppState(JSONObject jsonObject) {
        try {
            String appstate = jsonObject.getString("appstate");
//            String userKey = jsonObject.getString("userKey");
            String syncId = jsonObject.getString("syncId");
            String generatedTime = jsonObject.getString("generatedTime");
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnRecvSyncAppState);
                jsonObject1.put("appstate", appstate);
                jsonObject1.put("syncId", syncId);
                jsonObject1.put("generatedTime", generatedTime);
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveGetAllSyncAppState(JSONObject jsonObject) {
        try {
            String message = jsonObject.getString("message");
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnGetAllSyncAppState);
                jsonObject1.put("message", message);
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveCalleeBusy(JSONObject jsonObject) {
        try {
            String callerId = jsonObject.getString("callerId");
//            String callerKey = jsonObject.getString("callerKey");
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaReceiveCalleeBusy);
                jsonObject1.put("callerId", callerId);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveGetAllOfflineMessage(JSONObject jsonObject) {
        try {
            String message = jsonObject.getString("message");

            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaReceiveGetAllOfflineReceiveMessage);
                jsonObject1.put("data", message);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveGetAllUndelivered(JSONObject jsonObject) {
        try {
            String message = jsonObject.getString("message");
            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnGetAllUnDeliverdMessages);
                jsonObject1.put("message", message);
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceiveAllMessage(JSONObject jsonObject) {
        try {
            String message = jsonObject.getString("message");
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaGetAllMessages);
                jsonObject1.put("data", message);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceivesAgentChatInfo(JSONObject jsonObject) {
        try {
            String callerId = jsonObject.getString("callerId");
            String callerKey = jsonObject.getString("callerKey");
            String displayName = jsonObject.has("displayName") ? jsonObject.getString("displayName") : "";
            String agentName = jsonObject.has("agentName") ? jsonObject.getString("agentName") : "";
//            String bkey = jsonObject.getString("bkey");
            if (!isAgentChatInfoReceived) {
                isAgentChatInfoReceived = true;
                String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                if (env.equalsIgnoreCase("dashboard")) {
                    env = "browser";
                }
                JSONObject jsonObject1 = new JSONObject();
                try {
                    jsonObject1.put("trovaEvent", OnTrovaAgentChatInfo);
                    jsonObject1.put("callerId", callerId);
                    jsonObject1.put("displayName", displayName);
                    jsonObject1.put("agentName", agentName);
                    jsonObject1.put("env", env.toLowerCase());
                    trovaApiCallback.TrovaEvents(jsonObject1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeReceivesAgentInfo(JSONObject jsonObject) {
        try {
            String callerId = jsonObject.getString("callerId");
//            String callerKey = jsonObject.getString("callerKey");
            String agentName = jsonObject.getString("agentName");
//            String bkey = jsonObject.getString("bkey");
            String mode = jsonObject.getString("mode");
            String displayName = jsonObject.getString("displayName");

            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            if (!isAgentInfoReceived) {
                rtcConnection = null;
                mainAgentUserId = callerId;
                isAgentInfoReceived = true;
                JSONObject jsonObject1 = new JSONObject();
                try {
                    jsonObject1.put("trovaEvent", OnTrovaAgentInfo);
                    jsonObject1.put("callerId", callerId);
                    jsonObject1.put("agentName", agentName);
                    jsonObject1.put("displayName", displayName);
                    jsonObject1.put("callMode", mode);
                    jsonObject1.put("env", env.toLowerCase());
                    trovaApiCallback.TrovaEvents(jsonObject1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                inCall = true;
                ArrayList<String> list = new ArrayList<>();
                makeAgentConfCall(mode, list, trovaAgentKey, callerId, preferenceUtil.getUserId(), false);
                audioUnmute();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void makeJoinedConfCall(String mode, ArrayList<String> list, String trovaAgentKey, String callerId, String confId) {
        try {
            if (isLoggedIn) {
                JSONObject jo = new JSONObject();
                jo.put("trovaEvent", OnTrovaSessionUserOnline);
                jo.put("result", "success");
                trovaApiCallback.TrovaEvents(jo);
                onlyDisconnectSocket();
                this.confId = "";
            } else {
                recordCall = true;
                trovaConferenceType = "Gadget";
                preferenceUtil.setConfRecordFolder(trovaAgentKey);
                this.confId = md5(preferenceUtil.getBusinessKey() + confId);
                initRtc();
                rtcConnection.callingAudioVideo(mode);
                rtcConnection.createStream(this);

                logData("", "makecall Called ..... ...");
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "version", version);
                jsonValuePut(userObj, "participantsId", list);
                jsonValuePut(userObj, "userKey", getUserKey());
                jsonValuePut(userObj, "callMode", mode);
                jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
                jsonValuePut(userObj, "agentKey", trovaAgentKey);
                jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
                jsonValuePut(userObj, "env", "Mobile");
                jsonValuePut(userObj, "type", trovaConferenceType);
                jsonValuePut(userObj, "callerId", callerId);
                jsonValuePut(userObj, "confId", this.confId);
                jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
                logData("executejJoinedConfCall", userObj.toString());
                emit("jJoinConf", userObj);
                if (mode.equalsIgnoreCase("video"))
                    makeSpeakerOn();
                else {
                    makeEarPiece();
                }

            }
            isLoggedIn = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void makeAgentConfCall(String mode, ArrayList<String> list, String trovaAgentKey, String callerId, String confId, boolean createeStream) {
        try {
            if (isLoggedIn) {
                JSONObject jo = new JSONObject();
                jo.put("trovaEvent", OnTrovaSessionUserOnline);
                jo.put("result", "success");
                trovaApiCallback.TrovaEvents(jo);
                onlyDisconnectSocket();
                this.confId = "";
            } else {
                recordCall = true;
                trovaConferenceType = "Gadget";
                preferenceUtil.setConfRecordFolder(trovaAgentKey);
                this.confId = md5(preferenceUtil.getBusinessKey() + confId);
                if (createeStream) {
                    initRtc();
                    rtcConnection.callingAudioVideo(mode);
                    rtcConnection.createStream(this);
                } else {
                    rtcConnection = null;
                }

                logData("", "makecall Called ..... ...");
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "version", version);
                jsonValuePut(userObj, "participantsId", list);
                jsonValuePut(userObj, "userKey", getUserKey());
                jsonValuePut(userObj, "callMode", mode);
                jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
                jsonValuePut(userObj, "agentKey", trovaAgentKey);
                jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
                jsonValuePut(userObj, "env", "Mobile");
                jsonValuePut(userObj, "type", trovaConferenceType);
                jsonValuePut(userObj, "callerId", callerId);
                jsonValuePut(userObj, "confId", this.confId);
                jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
                logData("executejMakeConfCall", userObj.toString());
                emit("jMakeConf", userObj);
                if (mode.equalsIgnoreCase("video"))
                    makeSpeakerOn();
                else {
                    makeEarPiece();
                }

            }
            isLoggedIn = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void executeReceiveAgentChatStatus(JSONObject jsonObject) {
        try {
            String callerId = jsonObject.getString("callerId");
            String callerKey = jsonObject.getString("callerKey");
            String displayName = jsonObject.has("displayName") ? jsonObject.getString("displayName") : "";
            String widgetUserName = jsonObject.has("agentName") ? jsonObject.getString("agentName") : "";
            String bkey = jsonObject.getString("bkey");
            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            String agentKey = jsonObject.has("agentKey") ? jsonObject.getString("agentKey") : "";
//            if (!TextUtils.isEmpty(agentKey)) {
//                trovaAgentKey = agentKey;
//            }
//            confId = jsonObject.has("confId") ? jsonObject.getString("confId") : "";

            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "callerKey", callerKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "bkey", bkey);
            jsonValuePut(userObj, "displayName", displayName);
            logData("jUpdateAgentStatus", userObj.toString());
            jsonValuePut(userObj, "agentName", preferenceUtil.getUserName());
            jsonValuePut(userObj, "agentKey", agentKey);
            emit("jUpdateAgentChatStatus", userObj);

            JSONObject jo = new JSONObject();
            jo.put("trovaEvent", OnTrovaWidgetChatInfo);
            jo.put("widgetUserName", widgetUserName);
            jo.put("widgetCallerId", callerId);
            jo.put("displayName", displayName);
            jo.put("agentKey", agentKey);
            jo.put("env", env.toLowerCase());
            trovaApiCallback.TrovaEvents(jo);


        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    private void executeReceiveAgentListStatus(JSONObject jsonObject) {
        try {
//            "callerKey":"4c7dad9e9ae58e998bc153661c480788",
            String callerId = jsonObject.getString("callerId");
            String callerName = jsonObject.getString("callerName");
            String mode = jsonObject.getString("mode");
            String agentName = jsonObject.has("agentName") ? jsonObject.getString("agentName") : "";
            String displayName = jsonObject.has("displayName") ? jsonObject.getString("displayName") : "";
            String agentKey = jsonObject.has("agentKey") ? jsonObject.getString("agentKey") : "";
            trovaConferenceType = "Gadget";

            JSONObject object = new JSONObject();

            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            object.put("env", env.toLowerCase());
            object.put("widgetUserName", callerName);
            object.put("widgetCallerId", callerId);
            object.put("callMode", mode);
            object.put("displayName", displayName);
            object.put("agentName", agentName);
            object.put("agentKey", agentKey);
            object.put("trovaEvent", OnTrovaReceiveListAvailableAgents);
            trovaApiCallback.TrovaEvents(object);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeReceiveAgentStatus(JSONObject jsonObject) {
        try {
//            callerId':data.userId,'callerKey':data.userKey,'bkey':data.businessKey
            String callerId = jsonObject.getString("callerId");
            String callerName = jsonObject.getString("callerName");
            String callerKey = jsonObject.getString("callerKey");
            String bkey = jsonObject.getString("bkey");
            String agentName = preferenceUtil.getUserName();
            String displayName = jsonObject.has("displayName") ? jsonObject.getString("displayName") : "";
            String listLookUp = jsonObject.has("listLookUp") ? jsonObject.getString("listLookUp") : "";
            String mode = jsonObject.getString("mode");
            String agentKey = jsonObject.has("agentKey") ? jsonObject.getString("agentKey") : "";
            if (!inCall) {
                trovaConferenceType = "Gadget";
                if (!TextUtils.isEmpty(agentKey)) {
                    trovaAgentKey = agentKey;
                }

                confId = jsonObject.has("confId") ? jsonObject.getString("confId") : "";
                JSONObject userObj = new JSONObject();
                jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
                jsonValuePut(userObj, "callerName", callerName);
                jsonValuePut(userObj, "callerKey", callerKey);
                jsonValuePut(userObj, "userKey", getUserKey());
                jsonValuePut(userObj, "bkey", bkey);
                jsonValuePut(userObj, "agentKey", agentKey);
                jsonValuePut(userObj, "listLookUp", listLookUp);
                jsonValuePut(userObj, "agentName", agentName);
                jsonValuePut(userObj, "displayName", displayName);
                jsonValuePut(userObj, "mode", mode);
                logData("jUpdateAgentStatus", userObj.toString());
                JSONObject object = new JSONObject();

                String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
                if (env.equalsIgnoreCase("dashboard")) {
                    env = "browser";
                }
                object.put("env", env.toLowerCase());
                object.put("widgetUserName", callerName);
                object.put("widgetCallerId", callerId);
                object.put("displayName", displayName);
                object.put("callMode", mode);
                object.put("listLookUp", listLookUp);
                object.put("agentKey", agentKey);
                object.put("trovaEvent", OnTrovaWidgetInfo);
                trovaApiCallback.TrovaEvents(object);

                emit("jUpdateAgentStatus", userObj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeSockResult(JSONObject jsonObject) {
        try {
            String loggedIn = jsonObject.getString("loggedIn");
            if (loggedIn.equals("true")) {
                isLoggedIn = true;
                onlyDisconnectSocket();
                isLoggedIn = false;
                confId = "";
                JSONObject jo = new JSONObject();
                jo.put("trovaEvent", OnTrovaSessionUserOnline);
                jo.put("alreadyLoggedIn", "yes");
                jo.put("env", jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "");
                trovaApiCallback.TrovaEvents(jo);
            } else {
                isLoggedIn = false;
                JSONObject jo = new JSONObject();
                jo.put("trovaEvent", OnTrovaSessionUserOnline);
                jo.put("alreadyLoggedIn", "no");
                jo.put("env", jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "");
                trovaApiCallback.TrovaEvents(jo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executesRecvScreenShareCon(JSONObject jsonObject) {
        try {
            String rtcDataStr = jsonObject.getString("RTCData");
            String callerKey = jsonObject.getString("callerKey");
            JSONObject rtcData = new JSONObject(rtcDataStr);
            String type = rtcData.getString("type")/*.toUpperCase()*/;
            if (!type.equals("candidate"))
                type = type.toUpperCase();
            logData("", "type :" + type);
            if (type.equals("candidate")) {
                if (callEvents != null) {
                    callEvents.onRemoteIceCandidate(toJavaCandidate(rtcData), callerKey, true);
                }
            } else if (type.equals("OFFER") || type.equals("ANSWER")) {

                if (rtcConnection == null) {
                    initRtc();
                }

                if (type.equals("OFFER")) {
                    rtcConnection.createScreenSharePeerConnection(callerKey);
                }
                logData("", "OFFER" + callEvents);
                if (callEvents != null) {
                    SessionDescription sdp = new SessionDescription(
                            SessionDescription.Type.fromCanonicalForm(type),
                            rtcData.getString("sdp"));
                    callEvents.onRemoteDescription(sdp, callerKey, true);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executesEndConfScreenShare(JSONObject jsonObject) {
        try {

            String callerId = jsonObject.get("callerId").toString();
            String callerKey = jsonObject.get("callerKey").toString();
            rtcConnection.closeConfScreenShare(callerKey);

            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            JSONObject jsonObject1 = new JSONObject();
            try {
                jsonObject1.put("trovaEvent", OnTrovaReceiveEndScreenShare);
                jsonObject1.put("callerId", callerId);
                jsonObject1.put("env", env.toLowerCase());
                trovaApiCallback.TrovaEvents(jsonObject1);
            } catch (Exception e) {
                e.printStackTrace();
            }

            sharecallersList.remove(callerId);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executesRecvConfScreenShare(JSONObject jsonObject) {
        try {
            final String callerKey = jsonObject.get("callerKey").toString();
            String callerId = jsonObject.get("callerId").toString();

            sharecallersList.put(callerId, callerKey);

            String env = jsonObject.has("deviceCon") ? jsonObject.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }

            logData("", "Answer Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "callerKey", callerKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jAnswerScreenShare", userObj.toString());
            emit("jAnswerScreenShare", userObj);

            JSONObject object = new JSONObject();
            jsonValuePut(object, "callerId", callerId);
            jsonValuePut(object, "env", env.toLowerCase());
            jsonValuePut(object, "trovaEvent", OnTrovaReceiveConfScreenShare);
            trovaApiCallback.TrovaEvents(object);


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeReciveVideoMute(JSONObject jsonObject) {
        if (DEBUG) {
            if (jsonObject != null)
                Log.i("executeReciveVideoMute", jsonObject.toString());
        }
    }

    private void executeReciveVideoUnMute(JSONObject jsonObject) {
        if (DEBUG) {
            if (jsonObject != null)
                Log.i("executeRcvVideoUnMute", jsonObject.toString());
        }
    }


    private void executeReciveEndConfCall(JSONObject obj) {
        try {

            String callerId = obj.get("callerId").toString();
            String callerKey = obj.get("callerKey").toString();
            String callMode = obj.has("callMode") ? obj.get("callMode").toString() : "video";
            String env = obj.has("deviceCon") ? obj.getString("deviceCon") : "";
            if (env.equalsIgnoreCase("dashboard")) {
                env = "browser";
            }
            if (rtcConnection != null && rtcConnection.peerConnectionMap.containsKey(callerKey)) {

                JSONObject jsonObject1 = new JSONObject();
                try {
                    if (TextUtils.isEmpty(trovaConferenceType) || !trovaConferenceType.equalsIgnoreCase("Gadget")) {
                        jsonObject1.put("trovaEvent", OnTrovaReceiveEndConfCall);

                        if (rtcConnection.peerConnectionMap.size() <= 1) {
                            inCall = false;
                            mainAgentUserId = "";
                            trovaConferenceType = "";
                        }
                        rtcConnection.closeConf(callerKey);
                        jsonObject1.put("callerId", callerId);
                        jsonObject1.put("callMode", callMode);
                        jsonObject1.put("env", env.toLowerCase());
                        trovaApiCallback.TrovaEvents(jsonObject1);
                    } else {
                        jsonObject1.put("trovaEvent", OnTrovaReceiveEndCall);

                        if (callerKey.contains("GADGET") || mainAgentUserId.equalsIgnoreCase(callerId)) {
                            inCall = false;
                            trovaConferenceType = "";
                            mainAgentUserId = "";
                            int count = 0;
                            int totalsize = rtcConnection.peerConnectionMap.size();
                            for (Object o : rtcConnection.peerConnectionMap.entrySet()) {
                                Map.Entry item = (Map.Entry) o;
                                count = count + 1;
                                String key = (String) item.getKey();
                                if (count == totalsize) {
                                    rtcConnection.close(key);
                                } else {
                                    rtcConnection.closeAllInConf(key);
                                }
                            }
                            callersList.clear();
                            rtcConnection.peerConnectionMap.clear();
                            executeEndConfOnly(new ArrayList<String>(), callMode, confId, true);
                            jsonObject1.put("callerId", callerId);
                            jsonObject1.put("callMode", callMode);
                            jsonObject1.put("env", env.toLowerCase());
                            trovaApiCallback.TrovaEvents(jsonObject1);
//                            rtcConnection.close(callerId);
                        } else {
                            rtcConnection.closeConf(callerKey);
                            callersList.remove(callerId);
                            jsonObject1.put("callerId", callerId);
                            jsonObject1.put("callMode", callMode);
                            jsonObject1.put("env", env.toLowerCase());
                            trovaApiCallback.TrovaEvents(jsonObject1);
                        }

                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            callersList.remove(callerId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void runCandidatesQueueThread() {

        if (rtcConnection != null && rtcConnection.sendCanditateThread == null) {
            rtcConnection.sendCanditateThread = new Thread(new Runnable() {
                @Override
                public void run() {

                    while (!(Thread.currentThread().isInterrupted())) {
                        String queue;
                        String callerId;
                        if (sendcandidatesqueue != null && sendcandidatesqueue.size() > 0)
                            try {
                                queue = sendcandidatesqueue.take();
                                if (queue != null) {
                                    System.out.println("runqueue thread " + queue);
                                    final JSONObject jsonObject = new JSONObject(queue);
                                    ///logData("rtcConnection.isSdpSent", rtcConnection != null && rtcConnection.isSdpSent);
                                    switch (jsonObject.getString("trovaEvent")) {
                                        case "handleOnIceCandidate":
                                            if (rtcConnection != null && rtcConnection.isSdpSent) {
                                                callerId = jsonObject.getString("callerId");
                                                String callMode = jsonObject.getString("callMode");
                                                boolean screenShare = jsonObject.getBoolean("screenShare");
                                                JSONObject jsonBody = jsonObject.getJSONObject("jsonBody");
                                                executeCallConnection(callerId, callMode, jsonBody, screenShare);
                                                if (DEBUG)
                                                    Log.i("candidates : send", jsonBody.toString() + "callerId" + callerId);
                                            } else {
                                                executeCandidateQueuePost(jsonObject);
                                            }
                                            break;
                                    }
                                }
                            } catch (Exception e) {
                                logData("Thread stoped", "");
                                // Thread.currentThread().interrupt();

                                e.printStackTrace();
                            }
                    }
                }
            });
            rtcConnection.sendCanditateThread.start();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            logData("TrovaService", "onCreate Called .......");
            LocalBroadcastManager.getInstance(this).registerReceiver(receiver, getIntentFilter());
            preferenceUtil = new PreferenceUtil(this);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private IntentFilter getIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Constants.SETUPCALL);
        intentFilter.addAction(Constants.ANSWERCALL);
        intentFilter.addAction(Constants.ADDTOCONF);
        intentFilter.addAction(Constants.ENDCALL);
        intentFilter.addAction(Constants.CHANGE_CAMERA);
        intentFilter.addAction(Constants.SEND_MESSAGE);
        intentFilter.addAction(Constants.EXECUTE_POST);
        intentFilter.addAction(Constants.REGISTER);
        intentFilter.addAction(Constants.JSEND_NOTIFICATION);
        intentFilter.addAction(Constants.HANDLE_FCM_ID);
        intentFilter.addAction(Constants.HANDLE_FCM_MESSAGES);
        intentFilter.addAction(Constants.REJECTCALL);
        intentFilter.addAction(Constants.MISSEDCALL);
        intentFilter.addAction(Constants.MAKECONF);
        intentFilter.addAction(Constants.TROVAENDCONF);
        intentFilter.addAction(Constants.ENABLE_MIC);
        intentFilter.addAction(Constants.ENABLE_AUDIO_SPEAKER);
        intentFilter.addAction(Constants.ENABLE_VIDEO);
        intentFilter.addAction(Constants.TROVA_CONF_NOTIFICATION);
        intentFilter.addAction(Constants.TROVA_CONNECT);
        intentFilter.addAction(Constants.TROVA_DISCONNECT);
        intentFilter.addAction(Constants.UPLOAD);
        intentFilter.addAction(Constants.DOWNLOAD);
        intentFilter.addAction(Constants.AVAILABLE_AGENTS);
        intentFilter.addAction(Constants.SETUPGADGETCALL);
        intentFilter.addAction(Constants.SETUPAGENTCALL);
        intentFilter.addAction(Constants.SETUPAGENTCHAT);
        intentFilter.addAction(Constants.TROVA_CLOSE_CHAT);
        intentFilter.addAction(Constants.TROVA_CLOSE_AGENT_CHAT);

        intentFilter.addAction(Constants.SYN_MESSAGE);
        intentFilter.addAction(Constants.UPDATEMESSAGEID);


        intentFilter.addAction(Constants.CALLEEBUSY);
        intentFilter.addAction(Constants.SYNCAPPSTATE);
        intentFilter.addAction(Constants.GETALLSYNCAPPSTATE);
        intentFilter.addAction(Constants.UPDATESYNCAPPSTATE);

        intentFilter.addAction(Constants.TROVASDKFREE);
        intentFilter.addAction(Constants.TROVAGETSCREENSHARE);
        intentFilter.addAction(Constants.TROVA_GROUP_CHAT);
        intentFilter.addAction(Constants.TROVA_REMOVE_GROUP_CHAT);
        intentFilter.addAction(Constants.START_RECORD);

        return intentFilter;
    }

    private void intsocketconnection() {
        if (queue == null) {
            queue = new LinkedBlockingQueue<>();
            runQueueThread();
        }

        version = BuildConfig.VERSION_NAME;
        runSocket();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        logData("TrovaService", "onStartCommand Called .......");
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        disconnectSocket();
        roomJoined = false;
        try {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
//        executeTrovaSdkFree();

        super.onTaskRemoved(rootIntent);
    }

    private void runSocket() {
        if (socket == null) {
            initSocket();
            socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "onConnect Called ................");
                    roomJoined = false;
                    if (callSigSock)
                        executeStoreCall(getUserKey(), true);
                }
            }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_DISCONNECT Called ................");
                    roomJoined = false;

                }
            }).on(Socket.EVENT_CONNECT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_CONNECT_ERROR Called ................" + args.toString());

                    roomJoined = false;
                }
            }).on(Socket.EVENT_RECONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_RECONNECT Called ................");

                    roomJoined = false;
                }
            }).on(Socket.EVENT_RECONNECT_ATTEMPT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_RECONNECT_ATTEMPT Called ................" + args);

                    roomJoined = false;
                }
            }).on(Socket.EVENT_RECONNECT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_RECONNECT_ERROR Called ................" + args);

                    roomJoined = false;
                }
            }).on(Socket.EVENT_RECONNECT_FAILED, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_RECONNECT_FAILED Called ................" + args);

                    roomJoined = false;
                }
            }).on(Socket.EVENT_RECONNECTING, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_RECONNECTING Called ................");

                    roomJoined = false;
                }
            }).on(Socket.EVENT_CONNECT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_CONNECT_ERROR Called ................" + args.toString());

                    roomJoined = false;
                }
            }).on(Socket.EVENT_CONNECT_TIMEOUT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_CONNECT_TIMEOUT Called ................");

                    roomJoined = false;
                }
            }).on(Socket.EVENT_CONNECTING, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_CONNECTING Called ................");

                    roomJoined = false;
                }
            }).on(Socket.EVENT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "EVENT_ERROR Called ................");

                    roomJoined = false;
                }
            }).on("sMessage", new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logData("Socket", "sMessage ................ called");
                    JSONObject jsonObject = (JSONObject) args[0];
                    logData("Socket", jsonObject.toString());
                    try {
                        executeQueuePost(jsonObject);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    private void initSocket() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[]{};
                        }

                        public void checkClientTrusted(X509Certificate[] chain,
                                                       String authType) throws CertificateException {
                        }

                        public void checkServerTrusted(X509Certificate[] chain,
                                                       String authType) throws CertificateException {
                        }
                    }
            };
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            OkHttpClient okHttpClient = new OkHttpClient.Builder()
                    .hostnameVerifier(new RelaxedHostNameVerifier())
                    .sslSocketFactory(sc.getSocketFactory(), (X509TrustManager) trustAllCerts[0])
                    .build();

// default settings for all sockets
            IO.setDefaultOkHttpWebSocketFactory(okHttpClient);
            IO.setDefaultOkHttpCallFactory(okHttpClient);

// set as an option
            IO.Options opts = new IO.Options();
            opts.callFactory = okHttpClient;
            opts.webSocketFactory = okHttpClient;
            opts.secure = true;
            opts.port = 443;
            String loadUrl = preferenceUtil.getLoadUrl().trim();
            String port = preferenceUtil.getPort().trim();
            if (TextUtils.isEmpty(loadUrl) || TextUtils.isEmpty(port)) {
                loadUrl = "https://dev.trova.in:8080";
            } else {
                if (!loadUrl.endsWith(":")) {
                    loadUrl = loadUrl + ":";
                }
                loadUrl = loadUrl + port;
            }
            socket = IO.socket(loadUrl, opts);

         /*   SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            IO.setDefaultSSLContext(sc);
            HttpsURLConnection.setDefaultHostnameVerifier(new RelaxedHostNameVerifier());
            IO.Options options = new IO.Options();
            options.sslContext = sc;
            options.secure = true;
            options.port = 443;
            socket = IO.socket("https://dev.trova.in:8088", options);*/
            if (DEBUG)
                Log.d("Initsocket", "called");
        } catch (URISyntaxException | NoSuchAlgorithmException | KeyManagementException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values[0] == 0) {
        } else {
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onRemoteDescription(final SessionDescription sdp, final String callerId, final boolean shareScreen) {
        if (rtcConnection == null) {
            TrovaApiService.logData("", "Received remote SDP for non-initilized peer connection.");
            return;
        }
        rtcConnection.setRemoteDescription(sdp, callerId, shareScreen);
    }

    @Override
    public void onRemoteIceCandidate(final IceCandidate candidate, final String callerId, boolean shareScreen) {
        if (rtcConnection == null) {
            TrovaApiService.logData("", "Received ICE candidate for a non-initialized peer connection.");
            return;
        }
        rtcConnection.addRemoteIceCandidate(candidate, callerId, shareScreen);
    }

    private void endcall(String callerId, String callType) {
        String callerKey = callerId;
        if (callersList != null && callersList.containsKey(callerId)) {
            callerKey = callersList.get(callerId);
        }
        executeEndcall(callerKey, callType);
        if (rtcConnection != null && callersList.containsKey(callerId)) {
            rtcConnection.close(callerKey);
            rtcConnection = null;
            callEvents = null;
        }
        trovaAudioMute = false;
        callersList.remove(callerId);
    }


    private void audioUnmute() {
        if (rtcConnection != null)
            rtcConnection.setAudioEnabled(true);
    }

    @Override
    public void onLocalDescription(SessionDescription sdp, String callerId, String callMode, boolean shareScreen) {
        JSONObject jsonBody = new JSONObject();
        try {
            logData("", sdp.description);
            System.out.println(sdp);
            jsonBody.put("sdp", sdp.description);
            jsonBody.put("type", sdp.type);
            executeCallConnection(callerId, callMode, jsonBody, shareScreen);
            rtcConnection.isSdpSent = true;
        } catch (JSONException e) {
            e.printStackTrace();
        }
       /* try {
            logData("", sdp.description);
            jsonBody.put("sdp", sdp.description);
            jsonBody.put("type", sdp.type);
            executeCallConnection(callerId, jsonBody, shareScreen);
            rtcConnection.isSdpSent = true;
            logData("TrovaApiService.rtcConnection.isSdpSent", rtcConnection.isSdpSent);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/
    }

    @Override
    public void onIceCandidate(IceCandidate candidate, String callerId, String callMode, boolean screenShare) {
        JSONObject jsonBody = new JSONObject();
        try {
            logData("sendingcandidate", candidate.toString());
            logData("sendingcandidate", callerId);
            jsonBody.put("candidate", candidate.sdp);
            jsonBody.put("type", "candidate");
            jsonBody.put("sdpMLineIndex", candidate.sdpMLineIndex);
            jsonBody.put("sdpMid", candidate.sdpMid);
            jsonBody.put("label", candidate.sdpMLineIndex);
            jsonBody.put("id", candidate.sdpMid);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("trovaEvent", "handleOnIceCandidate");
                jsonObject.put("callerId", callerId);
                jsonObject.put("callMode", callMode);
                jsonObject.put("screenShare", screenShare);
                jsonObject.put("jsonBody", jsonBody);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            executeCandidateQueuePost(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        /*try {
            logData("sendingcandidate", candidate.toString());
            logData("sendingcandidate", callerId);
            jsonBody.put("candidate", candidate.sdp);
            jsonBody.put("type", "candidate");
            jsonBody.put("label", candidate.sdpMLineIndex);
            jsonBody.put("id", candidate.sdpMid);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("trovaEvent", "handleOnIceCandidate");
                jsonObject.put("callerId", callerId);
                jsonObject.put("screenShare", screenShare);
                jsonObject.put("jsonBody", jsonBody);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            executeCandidateQueuePost(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }*/
    }

    @Override
    public void onIceConnected(String callOther, String mode) {
        JSONObject jsonObject = new JSONObject();
        try {
            if (recordCall) {
                executeSendStartRecord(callOther);
            }
            for (Map.Entry<String, String> e : callersList.entrySet()) {
                String value = e.getValue();
                if (value.equalsIgnoreCase(callOther)) {
                    String key = e.getKey();
                    jsonObject.put("callerId", key);
                    break;
                }
            }
            jsonObject.put("status", "connected");
            jsonValuePut(jsonObject, "env", preferenceUtil.isWidget() ? "Widget" : "Mobile");
            jsonObject.put("trovaEvent", OnTrovaCallState);
            trovaApiCallback.TrovaEvents(jsonObject);


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void executeSendStartRecord(String callerKey) {
        if (!TextUtils.isEmpty(confId)) {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "confId", confId);
            jsonValuePut(userObj, "folderName", preferenceUtil.getRecordFolder());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "callerKey", callerKey);
//            emit("jRecordCall", userObj);
        }
    }

    @Override
    public void onIceDisconnected() {

    }

    @Override
    public void onPeerConnectionClosed() {

    }

    private void initRtc() {
        if (rtcConnection == null) {
            callEvents = TrovaApiService.this;
            rtcConnection = new RTCConnection(this);
            rtcConnection.initiatePeerConnectionEvents(TrovaApiService.this);
        }
    }

    private void executeMessageData(String bKey, String messageJson, String OtherUserId, String subTitle, String displayText) {

        if (TextUtils.isEmpty(trovaUserKey) && preferenceUtil != null) {
            trovaUserKey = getUserKey();
        }
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "messageJson", messageJson);
        jsonValuePut(userObj, "userKey", trovaUserKey);
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "receiverId", OtherUserId);
        jsonValuePut(userObj, "businessKey", bKey);
        jsonValuePut(userObj, "subTitle", subTitle);
        jsonValuePut(userObj, "deviceCon", preferenceUtil.isWidget() ? "Widget" : "Mobile");
        jsonValuePut(userObj, "displayText", displayText);
        jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
        emit("jSendChat", userObj);
    }

    private void executeMissedCall(String callerId, String callMode) {
        isAgentInfoReceived = false;
        logData("", "Missed Called ........");
        JSONObject userObj = new JSONObject();
        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
        jsonValuePut(userObj, "userKey", getUserKey());
        jsonValuePut(userObj, "callerId", callerId);
        jsonValuePut(userObj, "callMode", callMode);
        jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
        emit("jMissedCall", userObj);
    }

    public void sendRegistrationToServer(final String token) {

        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {

                try {
                    if (TextUtils.isEmpty(preferenceUtil.getUserId())) {
                        JSONObject jsonObject = new JSONObject();
                        jsonValuePut(jsonObject, "trovaEvent", OnTrovaXmit_Registration2Server);
                        jsonValuePut(jsonObject, "result", "failed");
                        jsonValuePut(jsonObject, "message", "userId is empty");
                        trovaApiCallback.TrovaEvents(jsonObject);
                    } else if (NetworkUtil.isNetworkNotAvailable(TrovaApiService.this)) {
                        JSONObject jsonObject = new JSONObject();
                        jsonValuePut(jsonObject, "trovaEvent", OnTrovaXmit_Registration2Server);
                        jsonValuePut(jsonObject, "result", "failed");
                        jsonValuePut(jsonObject, "msg", "Network not available");
                        trovaApiCallback.TrovaEvents(jsonObject);
                    } else {
                        String tkn = token;
                        if (TextUtils.isEmpty(token)) {
                            tkn = preferenceUtil.getFcmToken();
                        }
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() {
                                        return null;
                                    }

                                    public void checkClientTrusted(
                                            X509Certificate[] certs, String authType) {
                                    }

                                    public void checkServerTrusted(
                                            X509Certificate[] certs, String authType) {
                                    }
                                }
                        };
                        try {
                            SSLContext sc = SSLContext.getInstance("SSL");
                            sc.init(null, trustAllCerts, new SecureRandom());
                            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                        } catch (Exception e) {
                        }
                        String url = ConfigServer.FcmServerKey + "addToken";
                        HttpURLConnection con = null;
                        try {
                            URL obj = new URL(url);
                            con = (HttpURLConnection) obj.openConnection();
                            con.setRequestMethod("POST");

                            String urlParameters = "userId=" + preferenceUtil.getUserId() + "&userKey=" + getUserKey() + "&businessKey=" + preferenceUtil.getBusinessKey() + " &token=" + tkn + "&os=android&isChatOnly=0";
                            con.setDoOutput(true);
                            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                            wr.writeBytes(urlParameters);
                            wr.flush();
                            wr.close();
                            int responseCode = con.getResponseCode();
                            BufferedReader in = new BufferedReader(
                                    new InputStreamReader(con.getInputStream()));
                            String inputLine;
                            StringBuilder response = new StringBuilder();

                            while ((inputLine = in.readLine()) != null) {
                                response.append(inputLine);
                            }
                            if (DEBUG) {
                                Log.e("FCM to Server rescode", responseCode + "");
                                Log.e("FCM to Serve response", response + "");
                            }
                            try {
                                JSONObject jsonObject = new JSONObject();
                                jsonValuePut(jsonObject, "trovaEvent", OnTrovaXmit_Registration2Server);
                                jsonValuePut(jsonObject, "result", "success");
                                jsonValuePut(jsonObject, "message", "fcm token updated successfully");
                                trovaApiCallback.TrovaEvents(jsonObject);
                            } catch (Exception e0) {
                                e0.printStackTrace();
                            }

                            in.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            try {
                                JSONObject jsonObject = new JSONObject();
                                jsonValuePut(jsonObject, "trovaEvent", OnTrovaXmit_Registration2Server);
                                jsonValuePut(jsonObject, "result", "failed");
                                jsonValuePut(jsonObject, "message", e.getMessage());
                                trovaApiCallback.TrovaEvents(jsonObject);
                            } catch (Exception e1) {
                                e1.printStackTrace();
                            }
                        } finally {
                            if (con != null) {
                                try {
                                    con.disconnect();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonValuePut(jsonObject, "trovaEvent", OnTrovaXmit_Registration2Server);
                        jsonValuePut(jsonObject, "result", "failed");
                        jsonValuePut(jsonObject, "message", e.getMessage());
                        trovaApiCallback.TrovaEvents(jsonObject);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }

            }
        });

        thread.start();

    }

    private class RelaxedHostNameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    private class ServiceBroadCast extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                String intentPackagename = (intent == null || intent.getPackage() == null) ? "" : intent.getPackage();
                String contextPackagename = (context == null || context.getPackageName() == null) ? "" : context.getPackageName();
                if (intent == null) {
                    return;
                }
                String action = intent.getAction();
                if (!TextUtils.isEmpty(action) && intentPackagename.equals(contextPackagename)) {
                    switch (action) {
                        case Constants.SETUPCALL:
                            String mode = intent.getStringExtra("mode");
                            String otherUserId = intent.getStringExtra("otherUserId");
                            executeMakecall(otherUserId, mode);
                            audioUnmute();
                            break;
                        case Constants.SETUPAGENTCHAT:
                            String AgentKey = intent.getStringExtra("AgentKey");
                            executeAgentMakechat(AgentKey);
                            break;
                        case Constants.TROVA_CLOSE_CHAT:
                            String otherUserid = intent.getStringExtra("otherUserId");
                            executetrovaCloseChat(otherUserid);
                            break;
                        case Constants.TROVA_CLOSE_AGENT_CHAT:
                            otherUserid = intent.getStringExtra("otherUserId");
                            executetrovaCloseAgentChat(otherUserid);
                            break;
                        case Constants.AVAILABLE_AGENTS:
                            inCall = true;
                            mode = intent.getStringExtra("mode");
                            AgentKey = intent.getStringExtra("AgentKey");
                            executeAvailableAgents(AgentKey, mode);
                            audioUnmute();
                            break;

                        case Constants.SETUPGADGETCALL:
                            inCall = true;
                            mode = intent.getStringExtra("mode");
                            AgentKey = intent.getStringExtra("AgentKey");
                            executeGadgetMakecall(AgentKey, mode);
                            audioUnmute();
                            break;
                        case Constants.SETUPAGENTCALL:
                            inCall = true;
                            mode = intent.getStringExtra("mode");
                            trovaAgentKey = intent.getStringExtra("AgentKey");
                            trovaConferenceType = "Gadget";
                            String callerId = intent.getStringExtra("otherUserId");
                            ArrayList<String> list = new ArrayList<>();
                            makeAgentConfCall(mode, list, trovaAgentKey, callerId, callerId, false);
                            audioUnmute();
                            break;
                        case Constants.ADDTOCONF:
                            otherUserId = intent.getStringExtra("otherUserId");
                            String extraData = intent.getStringExtra("extraData");
                            despatchAddToConfNotification(extraData, otherUserId);
                            break;

                        case Constants.ANSWERCALL:
                            inCall = true;
                            mode = intent.getStringExtra("mode");
                            otherUserId = intent.getStringExtra("otherUserId");
                            Log.i("trovaConferenceType:", trovaConferenceType);
                            if (!TextUtils.isEmpty(trovaConferenceType) && trovaConferenceType.equalsIgnoreCase("Gadget")) {
                                recordCall = true;
                                ArrayList<String> participants = new ArrayList<>();
                                initRtc();
                                String userid = otherUserId;
                                if (preferenceUtil.isWidget()) {
                                    userid = preferenceUtil.getUserId();
                                }
                                inCall = true;
                                makeJoinedConfCall(mode, participants, trovaAgentKey, otherUserId, userid);
                            } else {
                                if (rtcConnection == null || rtcConnection.lmediaStream == null) {
                                    initRtc();
                                    rtcConnection.callingAudioVideo(mode);
                                    rtcConnection.createStream(TrovaApiService.this);
                                }
                                executeAnswerCall(otherUserId, mode);
                                audioUnmute();
                                if (mode.equalsIgnoreCase("video"))
                                    makeSpeakerOn();
                                else {
                                    makeEarPiece();
                                }
                            }
                            break;
                        case Constants.ENDCALL:
                            mode = intent.getStringExtra("mode");
                            otherUserId = intent.getStringExtra("otherUserId");
                            if (TextUtils.isEmpty(trovaConferenceType) || !trovaConferenceType.equalsIgnoreCase("Gadget")) {
                                inCall = false;
                                isAgentInfoReceived = false;
                                endcall(otherUserId, mode);
                                recordCall = false;
                                trovaConferenceType = "";
                                confId = "";
                                trovaAgentKey = "";
                                mainAgentUserId = "";
                            } else {
                                executeEndConfOnly(new ArrayList<String>(), mode, confId, true);
                            }
                            break;
                        case Constants.MISSEDCALL:
                            inCall = false;
                            trovaConferenceType = "";
                            mainAgentUserId = "";
                            mode = intent.getStringExtra("mode");
                            otherUserId = intent.getStringExtra("otherUserId");
                            executeMissedCall(otherUserId, mode);
                            break;
                        case Constants.REJECTCALL:
                            inCall = false;
                            trovaConferenceType = "";
                            mainAgentUserId = "";
                            isAgentInfoReceived = false;
                            mode = intent.getStringExtra("mode");
                            otherUserId = intent.getStringExtra("otherUserId");
                            String otherUserKey = otherUserId;
                            if (callersList != null && callersList.containsKey(otherUserId)) {
                                otherUserKey = callersList.get(otherUserId);
                            }
                            executeRejectCall(otherUserId, otherUserKey, mode);
                            break;

                        case Constants.SEND_MESSAGE:
                            String messageJson = intent.getStringExtra("messageJson");
                            String OtherUserId = intent.getStringExtra("OtherUserId");
                            String subTitle = intent.getStringExtra("subTitle");
                            String displayText = intent.getStringExtra("displayText");
                            String bKey = preferenceUtil.getBusinessKey();
                            executeMessageData(bKey, messageJson, OtherUserId, subTitle, displayText);
                            break;
                        case Constants.EXECUTE_POST:
                            String recievedData = intent.getStringExtra(Constants.EXECUTE_POST);
                            if (!TextUtils.isEmpty(recievedData)) {
                                JSONObject jsonObject = new JSONObject(recievedData);
                                executeQueuePost(jsonObject);
                            }
                            break;
                        case Constants.REGISTER:
                            intsocketconnection();
                            String bsKey = intent.getStringExtra("bKey");
                            String name = intent.getStringExtra("name");
                            String userEmail = intent.getStringExtra("userEmail");
                            String userPhone = intent.getStringExtra("userPhone");
                            String userCC = intent.getStringExtra("userCC");
                            boolean isWidget = intent.getBooleanExtra("widget", false);
                            executeRegisterProfile(isWidget, bsKey, name, userEmail, userPhone, userCC);
                            break;
                        case Constants.JSEND_NOTIFICATION:
                            String notification = intent.getStringExtra("notification");
                            otherUserId = intent.getStringExtra("otherUserId");
                            String priority = intent.getStringExtra("priority");
                            int ttl = intent.getIntExtra("ttl", 0);
                            subTitle = intent.getStringExtra("subTitle");
                            displayText = intent.getStringExtra("displayText");
                            if (!TextUtils.isEmpty(trovaConferenceType) && trovaConferenceType.equalsIgnoreCase("Gadget")) {
                                try {
                                    if (!TextUtils.isEmpty(confId)) {
                                        JSONObject userObj = new JSONObject();
                                        jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
                                        jsonValuePut(userObj, "confId", confId);
                                        jsonValuePut(userObj, "notification", notification);
                                        jsonValuePut(userObj, "priority", priority);
                                        jsonValuePut(userObj, "ttl", ttl);
                                        jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
                                        jsonValuePut(userObj, "userKey", getUserKey());
                                        emit("jSendConfNotification", userObj);
                                        logData("", "executeTrovaSendConfNotification Called ........" + userObj.toString());
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                despatchNotification(notification, otherUserId, priority, ttl, subTitle, displayText);
                            }
                            break;
                        case Constants.CHANGE_CAMERA:
                            if (rtcConnection != null)
                                rtcConnection.changeCamera();
                            break;
                        case Constants.HANDLE_FCM_ID:
                            String token = intent.getStringExtra("FCMID");
                            sendRegistrationToServer(token);
                            break;
                        case Constants.HANDLE_FCM_MESSAGES:
                            String message = intent.getStringExtra("message");
                            try {
                                JSONObject jsonObject = new JSONObject(message);
                                logData("Socket", jsonObject.toString());
                                executeQueuePost(jsonObject);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;
                        case Constants.MAKECONF:
                            mode = intent.getStringExtra("mode");
                            String confId = intent.getStringExtra("confId");
                            recordCall = intent.getBooleanExtra("autoRecord", false);
                            isConferenceOwner = intent.getBooleanExtra("isConferenceOwner", false);
                            ArrayList<String> participants = intent.getStringArrayListExtra("participants");
                            initRtc();
                            executeMakeCallConf(mode, participants, confId);
                            audioUnmute();
                            break;

                        case Constants.TROVAENDCONF:
                            mode = intent.getStringExtra("mode");
                            confId = intent.getStringExtra("confId");
                            participants = intent.getStringArrayListExtra("participants");
                            executeEndConfcall(participants, mode, confId, false);
                            break;
                        case Constants.ENABLE_MIC:
                            boolean mute = intent.getBooleanExtra("mute", false);
                            excecuteEnableMic(mute);
                            break;

                        case Constants.ENABLE_AUDIO_SPEAKER:
                            mute = intent.getBooleanExtra("mute", false);
                            audioStreamEnable(mute);
                            break;

                        case Constants.ENABLE_VIDEO:
                            mute = intent.getBooleanExtra("mute", false);
                            executeVideoMute(mute);
                            break;

                        case Constants.TROVA_CONF_NOTIFICATION:
                            String notifications = intent.getStringExtra("notifications");
                            confId = intent.getStringExtra("confId");
                            priority = intent.getStringExtra("priority");
                            ttl = intent.getIntExtra("ttl", 0);
                            executeTrovaSendConfNotification(confId, notifications, priority, ttl);
                            break;
                        case Constants.TROVA_DISCONNECT:
                            trovaDisconnect = true;
                            inCall = false;
                            callSigSock = false;
                            trovaConferenceType = "";
                            mainAgentUserId = "";
                            onlyDisconnectSocket();
                            break;
                        case Constants.TROVA_CONNECT:

                            roomJoined = false;
                            if (socket == null) {
                                callSigSock = true;
                                intsocketconnection();
                            }
                            if (!socket.connected()) {
                                socket.connect();
                            }
                            break;
                        case Constants.UPLOAD:
                            String resourcePath = intent.getStringExtra("resourcePath");
                            String filetype = intent.getStringExtra("filetype");
                            String destinationPath = intent.getStringExtra("destinationPath");
                            Upload upload = new Upload();
                            upload.setFileToUpload(TrovaApiService.this, resourcePath, destinationPath, filetype);
                            break;
                        case Constants.DOWNLOAD:
                            String localPathToStore = intent.getStringExtra("localPathToStore");
                            String serverPath = intent.getStringExtra("serverPath");
                            DownloadS3 downloadS3 = new DownloadS3();
                            downloadS3.downloadFileFromS3(TrovaApiService.this, localPathToStore, serverPath);
                            break;
                        case Constants.SYN_MESSAGE:
                            otherUserId = intent.getStringExtra("otherUserId");
                            executeAllSyncMessage(otherUserId);
                            break;
                        case Constants.UPDATEMESSAGEID:
                            ArrayList<String> messageIds = intent.getStringArrayListExtra("messageIds");
                            executeUpdateMessageId(messageIds);
                            break;

                        case Constants.CALLEEBUSY:
                            otherUserId = intent.getStringExtra("otherUserId");
                            executeCallBusy(otherUserId);
                            if (rtcConnection == null || rtcConnection.peerConnectionMap == null || rtcConnection.peerConnectionMap.size() == 0) {
                                inCall = false;
                                trovaConferenceType = "";
                                mainAgentUserId = "";
                            }
                            break;

                        case Constants.SYNCAPPSTATE:
                            String appState = intent.getStringExtra("appState");
                            priority = intent.getStringExtra("priority");
                            ttl = intent.getIntExtra("ttl", 0);
                            executeSyncAppState(appState, priority, ttl);
                            break;
                        case Constants.TROVA_GET_ALL_MESSAGE:
                            otherUserId = intent.getStringExtra("otherUserId");
                            executeGetAllMessage(otherUserId);
                            break;

                        case Constants.GETALLSYNCAPPSTATE:
                            executeGetAllSyncAppState();
                            break;

                        case Constants.UPDATESYNCAPPSTATE:
                            String appStateId = intent.getStringExtra("appStateId");
                            executeUpdateSyncAppState(appStateId);
                            break;
                        case Constants.TROVASDKFREE:
                            executeTrovaSdkFree();
                            break;
                        case Constants.TROVAGETSCREENSHARE:
                            String callerid = intent.getStringExtra("otherUserId");
                            String callerKey = callersList.get(callerid);
                            executeGetScreeShare(callerKey);
                            break;
                        case Constants.TROVA_GROUP_CHAT:
                            String groupname = intent.getStringExtra("groupname");
                            participants = intent.getStringArrayListExtra("participants");
                            executeAddGroupChat(groupname, participants);
                            break;
                        case Constants.TROVA_REMOVE_GROUP_CHAT:
                            groupname = intent.getStringExtra("groupname");
                            participants = intent.getStringArrayListExtra("participants");
                            executeRemoveGroupChat(groupname, participants);
                            break;
                        case Constants.TROVA_XMIT_GROUP_CHAT:
                            message = intent.getStringExtra("message");
                            String productId = intent.getStringExtra("productId");
                            String groupName = intent.getStringExtra("groupName");
                            subTitle = intent.getStringExtra("subTitle");
                            displayText = intent.getStringExtra("displayText");
                            participants = intent.getStringArrayListExtra("participants");
                            executeXmitGroupChat(message, productId, groupName, subTitle, displayText, participants);
                            break;
                        case Constants.START_RECORD:
                            if (callersList != null && callersList.size() > 0) {
                                for (Map.Entry<String, String> e : callersList.entrySet()) {
                                    callerKey = e.getValue();
                                    executeSendStartRecord(callerKey);
                                }
                                recordCall = true;
                            } else {
                                recordCall = true;
                            }

                            break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void executeXmitGroupChat(String message, String productId, String groupName, String subTitle, String displayText, ArrayList<String> participants) {
        try {
            logData("", "executeXmitGroupChat Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "message", message);
            jsonValuePut(userObj, "productId", productId);
            jsonValuePut(userObj, "groupName", groupName);
            jsonValuePut(userObj, "subTitle", subTitle);
            jsonValuePut(userObj, "displayText", displayText);
            jsonValuePut(userObj, "participants", participants);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jXmitGroupChat", userObj.toString());
            emit("jXmitGroupChat", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeRemoveGroupChat(String groupname, ArrayList<String> participants) {
        try {
            logData("", "executeRemoveGroupChat Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "groupname", groupname);
            jsonValuePut(userObj, "participants", participants);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jRemoveGroupChat", userObj.toString());
            emit("jRemoveGroupChat", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeAddGroupChat(String groupname, ArrayList<String> participants) {
        try {
            logData("", "executeAddGroupChat Called ........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "groupname", groupname);
            jsonValuePut(userObj, "participants", participants);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jAddGroupChat", userObj.toString());
            emit("jAddGroupChat", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeGetAllMessage(String otherUserId) {
        try {
            logData("", "jGetAllMessage called........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "callerKey", otherUserId);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jGetAllMessage", userObj.toString());
            emit("jGetAllMessage", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeGetScreeShare(String callerKey) {

        try {
            logData("", "executeGetScreeShare called........");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "callerKey", callerKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            logData("jAnswerScreenShare", userObj.toString());
            emit("jAnswerScreenShare", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeTrovaSdkFree() {
        try {
            disconnectSocket();
            rtcConnection = null;
            callEvents = null;
            trovaAudioMute = false;
            callSigSock = false;
            Upload.amazonS3Client = null;
            isAgentChatInfoReceived = false;
            isAgentInfoReceived = false;
            roomJoined = false;
            inCall = false;
            trovaConferenceType = "";
            mainAgentUserId = "";
            this.confId = "";
            if (pendingQueue != null)
                pendingQueue.clear();

            System.gc();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeUpdateSyncAppState(String appStateId) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "appStateId", appStateId);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jUpdateSyncAppState", userObj.toString());
            emit("jUpdateSyncAppState", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeGetAllSyncAppState() {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jGetAllSyncAppState", userObj.toString());
            emit("jGetAllSyncAppState", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeSyncAppState(String appState, String priority, int ttl) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "appstate", appState);
            jsonValuePut(userObj, "priority", priority);
            jsonValuePut(userObj, "ttl", ttl);
            jsonValuePut(userObj, "deviceCon", preferenceUtil.isWidget() ? "Widget" : "Mobile");
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jSyncAppState", userObj.toString());
            emit("jSyncAppState", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeCallBusy(String otherUserId) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "callerId", otherUserId);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jCalleeBusy", userObj.toString());
            emit("jCalleeBusy", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeAllSyncMessage(String otherUserId) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "callerId", otherUserId);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jGetAllSyncMessage", userObj.toString());
            emit("jGetAllSyncMessage", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeUpdateMessageId(ArrayList<String> messageIds) {
//    private void executeUpdateMessageId(String[] messageIds) {
        try {
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "messageId", messageIds.toString());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jUpdateMessageId", userObj.toString());
            emit("jUpdateMessageId", userObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executetrovaCloseAgentChat(String otherUserId) {
        try {
            isAgentChatInfoReceived = false;
            logData("", "executetrovaCloseAgentChat Called ..... ...");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "callerId", otherUserId);
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jCloseAgentChat", userObj.toString());
            emit("jCloseAgentChat", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executetrovaCloseChat(String otherUserId) {
        try {
            isAgentChatInfoReceived = false;
            logData("", "executetrovaCloseChat Called ..... ...");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "callerId", otherUserId);
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            logData("jCloseChat", userObj.toString());
            emit("jCloseChat", userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeAgentMakechat(String agentKey) {

        try {
            logData("", "executeAgentMakechat Called ..... ...");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "version", version);
            jsonValuePut(userObj, "callerId", agentKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "env", "Mobile");

            jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
            jsonValuePut(userObj, "userPhone", preferenceUtil.getUserPhone());
            jsonValuePut(userObj, "userEmail", preferenceUtil.getUserEmail());
            logData("executeAgentMakechat", userObj.toString());
            emit("jMakeAgentChat", userObj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void executeAvailableAgents(String agentKey, String callMode) {

        try {
            recordCall = true;
            logData("", "executeAvailableAgents Called ..... ...");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "version", version);
            jsonValuePut(userObj, "callerId", agentKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "callMode", callMode);
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "env", "Mobile");
            jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
            jsonValuePut(userObj, "userPhone", preferenceUtil.getUserPhone());
            jsonValuePut(userObj, "userEmail", preferenceUtil.getUserEmail());
            jsonValuePut(userObj, "agentKey", agentKey);
            confId = md5(preferenceUtil.getBusinessKey() + preferenceUtil.getUserId());
            jsonValuePut(userObj, "confId", confId);
            logData("executejListAvailableAgents", userObj.toString());
            trovaConferenceType = "Gadget";
            trovaAgentKey = agentKey;
            emit("jListAvailableAgents", userObj);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void executeGadgetMakecall(String agentKey, String callMode) {

        try {
            rtcConnection = null;
            recordCall = true;
            logData("", "executeGadgetMakecall Called ..... ...");
            JSONObject userObj = new JSONObject();
            jsonValuePut(userObj, "version", version);
            jsonValuePut(userObj, "callerId", agentKey);
            jsonValuePut(userObj, "userKey", getUserKey());
            jsonValuePut(userObj, "callMode", callMode);
            jsonValuePut(userObj, "businessKey", preferenceUtil.getBusinessKey());
            jsonValuePut(userObj, "userId", preferenceUtil.getUserId());
            jsonValuePut(userObj, "env", "Mobile");
            jsonValuePut(userObj, "userName", preferenceUtil.getUserName());
            jsonValuePut(userObj, "userPhone", preferenceUtil.getUserPhone());
            jsonValuePut(userObj, "userEmail", preferenceUtil.getUserEmail());
            jsonValuePut(userObj, "agentKey", agentKey);
            confId = md5(preferenceUtil.getBusinessKey() + preferenceUtil.getUserId());
            jsonValuePut(userObj, "confId", confId);
            logData("executeGadgetMakecall", userObj.toString());
            trovaConferenceType = "Gadget";
            trovaAgentKey = agentKey;
            emit("jMakeAgentCall", userObj);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public class LocalBinder extends Binder {
        public TrovaApiService getService() {
            return TrovaApiService.this;
        }
    }

}

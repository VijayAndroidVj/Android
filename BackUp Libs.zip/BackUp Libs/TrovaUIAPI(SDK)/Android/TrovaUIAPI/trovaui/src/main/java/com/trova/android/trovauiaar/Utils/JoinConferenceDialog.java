package com.trova.android.trovauiaar.Utils;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.trova.android.trovauiaar.Globalclass;
import com.trova.android.trovauiaar.R;
import com.trova.android.trovauiaar.video.ReachVideoCall;
import com.trova.android.trovauiaar.voice.ReachVoiceCall;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import arr.trova.in.trovawoui.Utils.PreferenceUtil;

/**
 * Created by razin on 4/12/17.
 */


public class JoinConferenceDialog extends Activity {
    TextView tv_conference_agent_id;
    TextView tv_conference_widget_id;
    String agentKey, widgetUserId;
    Button bt_join_conference;
    Button bt_reject_conference;
    ImageView img_close;
    JSONObject jobj;
    public static String mainAgent;
    public static String GadgetAgent;
    public static String agentName;
    public static String widgetName;

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.setFinishOnTouchOutside(false);
            setContentView(R.layout.join_conference_dialog);
            initializeContent();
            try {
                jobj = new JSONObject(getIntent().getStringExtra("notification_data"));
                agentName = jobj.has("agentUserName") ? jobj.getString("agentUserName") : "";
                widgetName = jobj.has("widgetUserName") ? jobj.getString("widgetUserName") : "";
                tv_conference_agent_id.setText("" + agentName + " - Agent");
                tv_conference_widget_id.setText("" + widgetName);
                mainAgent = jobj.has("agentUserId") ? jobj.getString("agentUserId") : "";
                GadgetAgent = jobj.has("widgetUserId") ? jobj.getString("widgetUserId") : "";
                agentKey = jobj.has("agentKey") ? jobj.getString("agentKey") : "";
                widgetUserId = jobj.has("widgetUserId") ? jobj.getString("widgetUserId") : "";
            } catch (Exception e) {
                e.printStackTrace();
            }
            img_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isEscalationCancelled = false;
                    countDownTimer.cancel();
                    NotificationManager notificationManager = (NotificationManager) JoinConferenceDialog.this.getSystemService(NOTIFICATION_SERVICE);
                    notificationManager.cancelAll();
                    finish();
                }
            });

            bt_join_conference.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!TextUtils.isEmpty(widgetUserId))
                        try {
                            isEscalationCancelled = false;
                            countDownTimer.cancel();

                            long callbackTime = jobj.has("callbackTime") ? jobj.getLong("callbackTime") : 0;
                            if (callbackTime == 0 || (callbackTime + 30000) >=
                                    System.currentTimeMillis()) {
                                Calendar cal = Calendar.getInstance();
                                SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                String currDate = df.format(cal.getTime());
                                Intent CallActivity = null;
                                if (jobj.getString("callMode").equalsIgnoreCase("audio")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVoiceCall.class);
                                    CallActivity = new Intent(JoinConferenceDialog.this, ReachVoiceCall.class);
                                } else if (jobj.getString("callMode").equalsIgnoreCase("video")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVideoCall.class);
                                    CallActivity = new Intent(JoinConferenceDialog.this, ReachVideoCall.class);
                                }
                                CallActivity.putExtra("date", currDate);
                                CallActivity.putExtra("otherUserName", "");
                                CallActivity.putExtra("businessName", jobj.has("displayName") ? jobj.getString("displayName") : "");
//                                String agentKey = jsonObject.getString("agentKey");
                                CallActivity.putExtra("agentKey", agentKey);
//                                if (!TextUtils.isEmpty(agentKey)) {
//                                    CallActivity.putExtra("isAgentCall", 1);
                                CallActivity.putExtra("otherUserID", widgetUserId);
                                CallActivity.putExtra("callType", "in_call");
                                CallActivity.putExtra("restrictEscalate", true);
                                CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                JoinConferenceDialog.this.startActivity(CallActivity);
                                NotificationManager notificationManager = (NotificationManager) JoinConferenceDialog.this.getSystemService(NOTIFICATION_SERVICE);
                                notificationManager.cancelAll();
                                finish();
                            } else {
                                Toast.makeText(JoinConferenceDialog.this, "Expired", Toast.LENGTH_SHORT).show();
                                NotificationManager notificationManager = (NotificationManager) JoinConferenceDialog.this.getSystemService(NOTIFICATION_SERVICE);
                                notificationManager.cancelAll();
                                finish();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                }
            });

            bt_reject_conference.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    try {
                        isEscalationCancelled = false;
                        countDownTimer.cancel();

                        JSONObject nuserObj = new JSONObject();
                        nuserObj.put("event", "onCancelEscalation");
                        PreferenceUtil preferenceUtil = new PreferenceUtil(JoinConferenceDialog.this);
                        nuserObj.put("userId", preferenceUtil.getUserId());
                        if (Globalclass.trovaSDK_init != null)
                            Globalclass.trovaSDK_init.trovaXmit_Notification(mainAgent, nuserObj.toString(), "high", 0, "", "");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    NotificationManager notificationManager = (NotificationManager) JoinConferenceDialog.this.getSystemService(NOTIFICATION_SERVICE);
                    notificationManager.cancelAll();
                    finish();
                }
            });

            countDownTimer.start();
        } catch (Exception e) {
            Log.d("Exception", e.toString());
            e.printStackTrace();
        }
    }

    private boolean isEscalationCancelled = false;

    CountDownTimer countDownTimer = new

            CountDownTimer(30000, 1000) {

                public void onTick(long millisUntilFinished) {
                    Log.i("CountDownTimer:", "seconds remaining: " + millisUntilFinished / 1000);
                    if (millisUntilFinished / 1000 <= 1) {
                        isEscalationCancelled = true;
                    }
                }

                public void onFinish() {
                    if (isEscalationCancelled) {
                        NotificationManager notificationManager = (NotificationManager) JoinConferenceDialog.this.getSystemService(NOTIFICATION_SERVICE);
                        notificationManager.cancelAll();
                        finish();
                    }
                }
            };

    private void initializeContent() {
        tv_conference_agent_id = (TextView) findViewById(R.id.tv_conference_agent_id);
        tv_conference_widget_id = (TextView) findViewById(R.id.tv_conference_widget_id);
        bt_join_conference = (Button) findViewById(R.id.bt_join_conference);
        img_close = (ImageView) findViewById(R.id.img_close);
        bt_reject_conference = findViewById(R.id.bt_reject_conference);
    }

}
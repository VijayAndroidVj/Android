package arr.trova.in.trovawoui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import arr.trova.in.trovawoui.Utils.NetworkUtil;
import arr.trova.in.trovawoui.Utils.PermissionCheck;
import arr.trova.in.trovawoui.Utils.PreferenceUtil;
import arr.trova.in.trovawoui.Utils.TrovaApiCallback;
import arr.trova.in.trovawoui.s3Util.Upload;
import arr.trova.in.trovawoui.services.TrovaApiService;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnGetAllSyncAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnPermissionsRequired;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAcknowledgeMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAddToConf;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAddToGroupChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentCall_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Download;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Upload;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCall_Answer;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCall_End;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCall_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCall_InitMissedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCall_Reject;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCalleBusy;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCloseGadget_Chat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCloseSDK_Chat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaConference_End;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaConference_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaConference_ScreenShareInit;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaConference_XmitNotification;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaGadgetCall_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaGadgetChat_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaGetAllMessages;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaListAvailableAgents_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRecord_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRemoveToGroupChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSDK_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSessionUserOnline;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSession_Disconnect;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSyncMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaUpdateSyncAppData;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmitGroupChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_Chat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_File;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_Notification;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_Registration2Server;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_SendPayload;

public class trovaSDK_Init {
    public PreferenceUtil preferenceUtil;
    private Context context;
    private String packageName;

    /**
     * This constructor user to create object for access all api's
     *
     * @param cntx            - Context
     * @param type            - {"TYPE1 or TYPE2}
     * @param bKey            - Business key
     * @param userName        - User name
     * @param userId          - User Id
     * @param userEmail       - User Email
     * @param userPhone       - User Phone
     * @param userCountryCode - User Country Code
     * @param nodeUrl         - Socket Url
     * @param port            - Socket Port
     * @param callback        - Callback
     */
    public trovaSDK_Init(final Context cntx, final String type, final String bKey, final String userName, final String userId, final String userEmail, final String userPhone, final String userCountryCode, final TrovaApiCallback callback, final String nodeUrl, final String port) {
        if (callback != null) {
            context = cntx;
            packageName = context.getPackageName();
            TrovaApiService.setTrovaCallBack(callback);
            preferenceUtil = new PreferenceUtil(context);
            if (TextUtils.isEmpty(type)) {
                HashMap<String, Object> values = new HashMap<>();
                values.put("trovaEvent", OnTrovaSDK_Init);
                values.put("result", "failed");
                values.put("msg", "type is empty");
                TrovaApiService.constructCallback(callback, values);
            } else if (!type.equalsIgnoreCase("normal") && !type.equalsIgnoreCase("gadget")) {
                HashMap<String, Object> values = new HashMap<>();
                values.put("trovaEvent", OnTrovaSDK_Init);
                values.put("result", "failed");
                values.put("msg", "type is wrong");
                TrovaApiService.constructCallback(callback, values);
            } else if (TextUtils.isEmpty(bKey)) {
                HashMap<String, Object> values = new HashMap<>();
                values.put("trovaEvent", OnTrovaSDK_Init);
                values.put("result", "failed");
                values.put("msg", "bKey is empty");
                TrovaApiService.constructCallback(callback, values);
            } else if (TextUtils.isEmpty(userId)) {
                HashMap<String, Object> values = new HashMap<>();
                values.put("trovaEvent", OnTrovaSDK_Init);
                values.put("result", "failed");
                values.put("msg", "userId is empty");
                TrovaApiService.constructCallback(callback, values);
            } else if (NetworkUtil.isNetworkNotAvailable(cntx)) {
                HashMap<String, Object> values = new HashMap<>();
                values.put("trovaEvent", OnTrovaSDK_Init);
                values.put("result", "failed");
                values.put("msg", "Network not available");
                TrovaApiService.constructCallback(callback, values);
            } else {
                preferenceUtil.saveInitValues(bKey, userId, userName, userEmail, userPhone, userCountryCode, nodeUrl, port);

                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent();
                        intent.setAction(Constants.REGISTER);
                        intent.putExtra("bKey", bKey);
                        intent.putExtra("name", userName);
                        intent.putExtra("userEmail", userEmail);
                        intent.putExtra("userPhone", userPhone);
                        intent.setPackage(packageName);
                        intent.putExtra("userCC", userCountryCode);

                        if (type.equalsIgnoreCase("normal")) {
                            preferenceUtil.setWidget(false);
                            intent.putExtra("widget", false);
                        } else {
                            preferenceUtil.setWidget(true);
                            intent.putExtra("widget", true);
                        }
                        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

                        // trovaSession_Connect();
                    }
                }, 1000);

                Log.i("Init Success", " userId : " + userId + " name : " + userName);
            }
        }
    }

    private trovaSDK_Init() {
    }

    /**
     * This method used to start Call
     *
     * @param activity    - {Activity object}
     * @param callMode    - {callMode - {"audio" or "video"}}
     * @param otherUserId - caller id
     * @return - {Based on result}
     */

    public boolean trovaCall_Init(Activity activity, String callMode, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        ArrayList<String> permissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions());
        if (permissions.size() > 0) {

            values.put("trovaEvent", OnPermissionsRequired);
            values.put("result", "failed");
            values.put("msg", "permission not given");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCall_Init);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {

            values.put("trovaEvent", OnTrovaCall_Init);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {

            values.put("trovaEvent", OnTrovaCall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SETUPCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCall_Init);
            values.put("result", "success");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
            return true;
        }
        return false;
    }


    /**
     * This method used to answer Call
     *
     * @param callMode    - {callMode - {"audio" or "video"}}
     * @param otherUserId - caller id
     */

    public void trovaCall_Answer(String callMode, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCall_Answer);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCall_Answer);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.ANSWERCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCall_Answer);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);


        }
    }


    /**
     * This method used to end Rtc Call
     *
     * @param callMode    - {callMode - {"audio" or "video"}}
     * @param otherUserId - caller id
     */
    public void trovaCall_End(String callMode, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCall_End);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCall_End);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.ENDCALL);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("otherUserId", otherUserId);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCall_End);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }

    }

    /**
     * This method used to Reject the call
     *
     * @param callMode    - {callMode - {"audio" or "video"}}
     * @param otherUserId - caller id
     */
    public void trovaCall_Reject(String callMode, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCall_Reject);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCall_Reject);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.REJECTCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCall_Reject);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);


        }
    }

    /**
     * This method used to give the missed call
     *
     * @param callMode    - {callMode - {"audio" or "video"}}
     * @param otherUserId - caller id
     */
    public void trovaCall_InitMissedCall(String callMode, String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCall_InitMissedCall);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCall_InitMissedCall);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.MISSEDCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCall_InitMissedCall);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    /**
     * To Send Text Message
     *
     * @param message     - {Text message}
     * @param productId   -{Product Id}
     * @param OtherUserId -{Caller Id}
     * @param subTitle    -{SubTitle Id}
     * @param displayText -{DisplayText Id}
     * @param MessageId   -{Message Id}
     */
    public void trovaXmit_Chat(String message, String productId, String OtherUserId, String subTitle, String displayText, Long MessageId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(OtherUserId) || TextUtils.isEmpty(message)) {
            String dmessage = "";
            if (TextUtils.isEmpty(OtherUserId)) {
                dmessage = "callerId is empty";
            } else if (TextUtils.isEmpty(message)) {
                dmessage = "message is empty";
            }

            values.put("trovaEvent", OnTrovaXmit_Chat);
            values.put("result", "failed");
            values.put("msg", dmessage);
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaXmit_Chat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Calendar calendar = Calendar.getInstance();
            final JSONObject jsonObject = new JSONObject();
            TrovaApiService.jsonValuePut(jsonObject, "mode", "text");
            TrovaApiService.jsonValuePut(jsonObject, "productId", productId);
            TrovaApiService.jsonValuePut(jsonObject, "senderId", preferenceUtil.getUserId());
            if (MessageId != null && !TextUtils.isEmpty(MessageId.toString())) {
                TrovaApiService.jsonValuePut(jsonObject, "messageId", MessageId);
            } else {
                TrovaApiService.jsonValuePut(jsonObject, "messageId", System.currentTimeMillis());
            }
            TrovaApiService.jsonValuePut(jsonObject, "message", message);
            TrovaApiService.jsonValuePut(jsonObject, "TimeZoneOffset", calendar.getTimeZone().getRawOffset());
            String data = jsonObject.toString();
            Log.i("Send mesage", data);

            Intent intent = new Intent();
            intent.setAction(Constants.SEND_MESSAGE);
            intent.setPackage(packageName);
            intent.putExtra("messageJson", jsonObject.toString());
            intent.putExtra("OtherUserId", OtherUserId);
            intent.putExtra("subTitle", subTitle);
            intent.putExtra("displayText", displayText);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaXmit_Chat);
            values.put("result", "success");
            values.put("messageId", MessageId);
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }

    /**
     * To Send Media message
     *
     * @param filePath    - {File Path}
     * @param fileName    - {File Name}
     * @param fileType    - {File Type}
     * @param fileSize    - {File Size}
     * @param duration    - {Duration}
     * @param productId   - {Product Id}
     * @param OtherUserId - {Caller Id}
     * @param subTitle    - {Sub Title}
     * @param displayText - {Display Text}
     * @param messageId   - {Message Id}
     */
    public void trovaXmit_File(String filePath, String fileName, String fileType, long fileSize, String duration, String productId, String OtherUserId, String subTitle, String displayText, Long messageId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(OtherUserId) || TextUtils.isEmpty(filePath)) {
            String dmessage = "";
            if (TextUtils.isEmpty(OtherUserId)) {
                dmessage = "callerId is empty";
            } else if (TextUtils.isEmpty(filePath)) {
                dmessage = "filePath is empty";
            }
            values.put("trovaEvent", OnTrovaXmit_File);
            values.put("result", "failed");
            values.put("msg", dmessage);
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaXmit_File);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            JSONObject jsonObject = new JSONObject();
            Calendar calendar = Calendar.getInstance();
            TrovaApiService.jsonValuePut(jsonObject, "mode", "stream");
            TrovaApiService.jsonValuePut(jsonObject, "filetype", fileType);
            TrovaApiService.jsonValuePut(jsonObject, "filename", fileName);
            TrovaApiService.jsonValuePut(jsonObject, "filepath", filePath);
            TrovaApiService.jsonValuePut(jsonObject, "mediaduration", duration);
            TrovaApiService.jsonValuePut(jsonObject, "filesize", fileSize);
            TrovaApiService.jsonValuePut(jsonObject, "productId", productId);
            TrovaApiService.jsonValuePut(jsonObject, "senderId", preferenceUtil.getUserId());
            if (messageId != null && !TextUtils.isEmpty(messageId.toString())) {
                TrovaApiService.jsonValuePut(jsonObject, "messageId", messageId);
            } else {
                TrovaApiService.jsonValuePut(jsonObject, "messageId", System.currentTimeMillis());
            }
            TrovaApiService.jsonValuePut(jsonObject, "message", "");
            TrovaApiService.jsonValuePut(jsonObject, "TimeZoneOffset", calendar.getTimeZone().getRawOffset());
            String data = jsonObject.toString();
            Log.i("Send mesage", data);

            Intent intent = new Intent();
            intent.setAction(Constants.SEND_MESSAGE);
            intent.putExtra("messageJson", jsonObject.toString());
            intent.putExtra("OtherUserId", OtherUserId);
            intent.putExtra("subTitle", subTitle);
            intent.putExtra("displayText", displayText);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaXmit_File);
            values.put("result", "success");
            values.put("messageId", messageId);
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }

    }


    /**
     * To send Custom notification
     *
     * @param otherUserId  - {Caller Id}
     * @param notification - {Notification}
     * @param priority     - {Priority}
     * @param ttl          - {Time To Live}
     * @param subTitle     - {Sub Title}
     * @param displayText  - {Display Text}
     */
    public void trovaXmit_Notification(String otherUserId, String notification, String priority, int ttl, String subTitle, String displayText) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId) || TextUtils.isEmpty(notification)) {
            String dmessage = "";
            if (TextUtils.isEmpty(otherUserId)) {
                dmessage = "callerId is empty";
            } else if (TextUtils.isEmpty(notification)) {
                dmessage = "notification is empty";
            }
            values.put("trovaEvent", OnTrovaXmit_Notification);
            values.put("result", "failed");
            values.put("msg", dmessage);
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaXmit_Notification);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.JSEND_NOTIFICATION);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            intent.putExtra("notification", notification);
            intent.putExtra("priority", priority);
            intent.putExtra("ttl", ttl);
            intent.putExtra("subTitle", subTitle);
            intent.putExtra("displayText", displayText);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaXmit_Notification);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }

    /**
     * Connect Socket
     */
    public void trovaSession_Connect() {

        if (NetworkUtil.isNetworkNotAvailable(context)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaSessionUserOnline);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent();
                    intent.setAction(Constants.TROVA_CONNECT);
                    intent.setPackage(packageName);
                    LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
                }
            }, 1500);
        }

    }


    /**
     * DisConnect Socket
     */
    public void trovaSession_Disconnect() {
        Intent intent = new Intent();
        intent.setAction(Constants.TROVA_DISCONNECT);
        intent.setPackage(packageName);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

        HashMap<String, Object> values = new HashMap<>();
        values.put("trovaEvent", OnTrovaSession_Disconnect);
        values.put("result", "success");
        values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
        TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

    }


    /**
     * This method used to init the amazon credentials
     *
     * @param context    - Context
     * @param bucketName - This is the bucket name used for amazon
     * @param cognitoId  - This is the amazonCognito Id used for amazon
     * @param regionName - This is the region used for amazon
     */
    public void trovaAmazonS3_Init(Context context, String bucketName, String cognitoId, String regionName) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(bucketName)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Init);
            values.put("result", "failed");
            values.put("msg", "bucketName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(cognitoId)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Init);
            values.put("result", "failed");
            values.put("msg", "cognitoId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(regionName)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Init);
            values.put("result", "failed");
            values.put("msg", "regionName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            PreferenceUtil preferenceUtil = new PreferenceUtil(context);
            preferenceUtil.saveInitAwsValues(bucketName, cognitoId, regionName);
            Upload.amazonS3Client = null;
            Log.i("Init Aws Success", " s3Bucket : " + bucketName + " s3Cognito id : " + cognitoId + " region : " + regionName);

            values.put("trovaEvent", OnTrovaAmazonS3_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }

    }


    /**
     * To Upload Media file in Amazon
     *
     * @param resourceURL     - {Local File path to upload}
     * @param destinationPath - {Destination folder path in Amazon}
     */
    public void trovaAmazonS3_Upload(String resourceURL, String destinationPath, String identifier) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(resourceURL)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Upload);
            values.put("result", "failed");
            values.put("msg", "resourcePath is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Upload);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.UPLOAD);
            intent.setPackage(packageName);
            if (identifier == null) {
                identifier = "";
            }
            intent.putExtra("filetype", identifier);
            intent.putExtra("resourcePath", resourceURL);
            intent.putExtra("destinationPath", destinationPath);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
        }

    }

    /**
     * To Download file from Amazon
     *
     * @param localPathToStore - {Local file path to store after download}
     * @param serverPath       - {Server path for download file}
     */
    public void trovaAmazonS3_Download(String localPathToStore, String serverPath) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(localPathToStore)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Download);
            values.put("result", "failed");
            values.put("msg", "localPathToStore is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(serverPath)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Download);
            values.put("result", "failed");
            values.put("msg", "serverPath is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAmazonS3_Download);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.DOWNLOAD);
            intent.setPackage(packageName);
            intent.putExtra("localPathToStore", localPathToStore);
            intent.putExtra("serverPath", serverPath);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
        }
    }


    /**
     * Make conference call
     *
     * @param callMode     -{callMode - {"audio" or "video"}}
     * @param participants -{participants}
     */
    public void trovaConference_Init(String callMode, String type, ArrayList<String> participants, String conferenceId, String filePath, boolean autoRecording, boolean isConferenceOwner) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(conferenceId)) {
            values.put("trovaEvent", OnTrovaConference_Init);
            values.put("result", "failed");
            values.put("msg", "confId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {
            values.put("trovaEvent", OnTrovaConference_Init);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(filePath) && autoRecording) {
            values.put("trovaEvent", OnTrovaConference_Init);
            values.put("result", "failed");
            values.put("msg", "folderName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaConference_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            preferenceUtil.setConfRecordFolder(filePath);
            Intent intent = new Intent();
            intent.setAction(Constants.MAKECONF);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("participants", participants);
            intent.putExtra("confId", conferenceId);
            intent.putExtra("isConferenceOwner", isConferenceOwner);
            intent.putExtra("autoRecord", autoRecording);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaConference_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }


    /**
     * Conference end call
     *
     * @param callMode     -{callMode - {"audio" or "video"}}
     * @param participants -{participants}
     */
    public void trovaConference_End(String callMode, ArrayList<String> participants, String conferenceId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(conferenceId)) {
            values.put("trovaEvent", OnTrovaConference_End);
            values.put("result", "failed");
            values.put("msg", "conferenceId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaConference_End);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {
            values.put("trovaEvent", OnTrovaConference_End);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaConference_End);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            if (participants == null) {
                participants = new ArrayList<>();
            }
            Intent intent = new Intent();
            intent.setAction(Constants.TROVAENDCONF);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("participants", participants);
            intent.putExtra("confId", conferenceId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaConference_End);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * To Send Conf Notification
     *
     * @param conferenceId - {Conference Id}
     * @param notification - {Notifications}
     * @param priority     - {Priority}
     * @param ttl          - {Time To Live}
     */
    public void trovaConference_XmitNotification(String conferenceId, String notification, String priority, int ttl) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(conferenceId)) {
            values.put("trovaEvent", OnTrovaConference_XmitNotification);
            values.put("result", "failed");
            values.put("msg", "confId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(notification)) {
            values.put("trovaEvent", OnTrovaConference_XmitNotification);
            values.put("result", "failed");
            values.put("msg", "notification is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaConference_XmitNotification);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_CONF_NOTIFICATION);
            intent.setPackage(packageName);
            intent.putExtra("confId", conferenceId);
            intent.putExtra("notifications", notification);
            intent.putExtra("priority", priority);
            intent.putExtra("ttl", ttl);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaConference_XmitNotification);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * To Send fcm token to register
     *
     * @param token -{Token}
     */
    public void trovaXmit_Registration2Server(RegsitrationType tokenType, String token) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(token)) {
            values.put("trovaEvent", OnTrovaXmit_Registration2Server);
            values.put("result", "failed");
            values.put("msg", "token is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (!RegsitrationType.FCM.toString().equalsIgnoreCase(tokenType.toString())) {
            values.put("trovaEvent", OnTrovaXmit_Registration2Server);
            values.put("result", "failed");
            values.put("msg", "regsitrationType is wrong");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {

            values.put("trovaEvent", OnTrovaXmit_Registration2Server);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.HANDLE_FCM_ID);
            intent.putExtra("FCMID", token);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaXmit_Registration2Server);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }


    /**
     * Handle Fcm Message
     *
     * @param payLoad -{PayLoad}
     */
    public void trovaXmit_SendPayload(RegsitrationType tokenType, final String payLoad) {
        HashMap<String, Object> values = new HashMap<>();
        Log.i("Fcm", "Entered" + payLoad);
        if (TextUtils.isEmpty(payLoad)) {
            Log.i("Fcm payLoad", "Empty");
            values.put("trovaEvent", OnTrovaXmit_SendPayload);
            values.put("result", "failed");
            values.put("msg", "payLoad is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (tokenType == null || !RegsitrationType.FCM.toString().equalsIgnoreCase(tokenType.toString())) {
            values.put("trovaEvent", OnTrovaXmit_SendPayload);
            values.put("result", "failed");
            values.put("msg", "regsitrationType is wrong");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaXmit_SendPayload);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent();
                    intent.setAction(Constants.HANDLE_FCM_MESSAGES);
                    intent.setPackage(packageName);
                    intent.putExtra("message", payLoad);
                    LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

                    HashMap<String, Object> values = new HashMap<>();
                    values.put("trovaEvent", OnTrovaXmit_SendPayload);
                    values.put("result", "success");
                    TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

                }
            }, 1500);

        }
    }


    /**
     * Setup Agent call
     *
     * @param activity - {Activity Object}
     * @param callMode - {callMode - {"audio" or "video"}}
     * @param AgentKey - {Agent Key}
     * @return - {true or false}
     */
    public boolean trovaGadgetCall_Init(Activity activity, String callMode, String AgentKey) {
        ArrayList<String> permissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions());
        HashMap<String, Object> values = new HashMap<>();
        if (permissions.size() > 0) {
            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "Permission required");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(AgentKey)) {
            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "AgentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {
            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SETUPGADGETCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("AgentKey", AgentKey);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaAgentCall_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
            return true;
        }
        return false;

    }

    /**
     * Setup Agent chat
     *
     * @param AgentKey -{Agent Key}
     */
    public void trovaGadgetChat_Init(String AgentKey) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(AgentKey)) {
            values.put("trovaEvent", OnTrovaGadgetChat_Init);
            values.put("result", "failed");
            values.put("msg", "AgentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaGadgetChat_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SETUPAGENTCHAT);
            intent.setPackage(packageName);
            intent.putExtra("AgentKey", AgentKey);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaGadgetChat_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }

    }

    /**
     * Setup gadget call
     *
     * @param activity - {Activity Object}
     * @param callMode - {callMode - {"audio" or "video"}}
     * @param AgentKey - {Agent Key}
     * @return - {true or false}
     */
    public boolean trovaAgentCall_Init(Activity activity, String callMode, String otherUserId, String filePath, boolean autoRecording, String AgentKey) {
        HashMap<String, Object> values = new HashMap<>();
        ArrayList<String> permissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions());
        if (permissions.size() > 0) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "Permission required");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(filePath) && autoRecording) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "folderName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(AgentKey)) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "AgentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "otherUserId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SETUPAGENTCALL);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("AgentKey", AgentKey);
            intent.putExtra("autoRecord", autoRecording);
            preferenceUtil.setConfRecordFolder(filePath);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaGadgetCall_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
            return true;
        }
        return false;

    }

    /**
     * Make screenshare
     *
     * @param screenShareType -{screenShareType - oneToone or conf}
     * @param destinationId   -{destinationId}
     *//*
    public void trovaScreenShare_Init(ScreenShareType screenShareType, String destinationId) {
        if (TextUtils.isEmpty(destinationId)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaMakeScreenShare);
            values.put("result", "failed");
            values.put("msg", "confId is empty");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (screenShareType == null) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaMakeScreenShare);
            values.put("result", "failed");
            values.put("msg", "screenShareType is empty");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (!screenShareType.toString().equalsIgnoreCase(ScreenShareType.Conference.toString()) && !screenShareType.toString().equalsIgnoreCase(ScreenShareType.OneOnOne.toString())) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaMakeScreenShare);
            values.put("result", "failed");
            values.put("msg", "screenShareType is wrong");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaMakeScreenShare);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.MAKESCREENSHARE);
            intent.setPackage(packageName);
            intent.putExtra("screenShareType", screenShareType.toString());
            intent.putExtra("destinationId", destinationId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaMakeScreenShare);
            values.put("result", "success");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    *//**
     * End screenshare
     *
     * @param destinationId -{destinationId}
     *//*
    public void trovaScreenShare_End(String destinationId) {
        if (TextUtils.isEmpty(destinationId)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaScreenShare_End);
            values.put("result", "failed");
            values.put("msg", "confId is empty");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaScreenShare_End);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.ENDSCREENSHARE);
            intent.setPackage(packageName);
            intent.putExtra("destinationId", destinationId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaScreenShare_End);
            values.put("result", "success");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }
*/

    /**
     * This method used to Get Screen share if any
     */
    public void trovaConference_ScreenShare_Init(String otherUserID) {
        HashMap<String, Object> values = new HashMap<>();
        if (NetworkUtil.isNetworkNotAvailable(context)) {

            values.put("trovaEvent", OnTrovaConference_ScreenShareInit);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(otherUserID)) {
            values.put("trovaEvent", OnTrovaConference_ScreenShareInit);
            values.put("result", "failed");
            values.put("msg", "otherUserID is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVAGETSCREENSHARE);
            intent.putExtra("otherUserId", otherUserID);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaConference_ScreenShareInit);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    /**
     * update message id's
     *
     * @param messageIds - {Array of message Ids to update}
     */
    public void trovaAcknowledgeMessage(ArrayList<String> messageIds) {
        HashMap<String, Object> values = new HashMap<>();
        if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAcknowledgeMessage);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (messageIds != null && messageIds.size() > 0) {
            Intent intent = new Intent();
            intent.setAction(Constants.UPDATEMESSAGEID);
            intent.setPackage(packageName);
            intent.putExtra("messageIds", messageIds);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaAcknowledgeMessage);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            values.put("trovaEvent", OnTrovaAcknowledgeMessage);
            values.put("result", "failed");
            values.put("msg", "messageId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }

    }

    /**
     * get all message
     *
     * @param otherUserId - {otherUserId}
     */
    public void trovaGetAllMessages(String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaGetAllMessages);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {


            values.put("trovaEvent", OnTrovaGetAllMessages);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_GET_ALL_MESSAGE);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

        }

    }

    /**
     * Get all msg by other user id
     *
     * @param otherUserId -{Caller Id}
     */
    public void TrovaSyncMessage(String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaSyncMessage);
            values.put("result", "failed");
            values.put("msg", "DestinationId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaSyncMessage);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SYN_MESSAGE);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

        }
    }


    /**
     * This method used to mute/unmute video stream
     *
     * @param mute - {true or false}
     */
    public void trovaVideoMute(boolean mute) {
        Intent intent = new Intent();
        intent.setAction(Constants.ENABLE_VIDEO);
        intent.setPackage(packageName);
        intent.putExtra("mute", mute);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }


    /**
     * Audio mute
     *
     * @param mute - {true or false}
     */
    public void trovaAudioMute(boolean mute) {
        Intent intent = new Intent();
        intent.setAction(Constants.ENABLE_AUDIO_SPEAKER);
        intent.setPackage(packageName);
        intent.putExtra("mute", mute);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }


    /**
     * This method used to mute/unmute mic
     *
     * @param mute - {true or false}
     */
    public void trovaMicMute(boolean mute) {
        Intent intent = new Intent();
        intent.setAction(Constants.ENABLE_MIC);
        intent.setPackage(packageName);
        intent.putExtra("mute", mute);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    /**
     * Close Chat
     *
     * @param otherUserId -{Caller Id}
     */
    public void trovaCloseSDK_Chat(String otherUserId) {
        if (TextUtils.isEmpty(otherUserId)) {
            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaCloseSDK_Chat);
            values.put("result", "failed");
            values.put("msg", "otherUserId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {

            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaCloseSDK_Chat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_CLOSE_CHAT);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            HashMap<String, Object> values = new HashMap<>();
            values.put("trovaEvent", OnTrovaCloseSDK_Chat);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }

    }


    /**
     * Close Agent Chat
     *
     * @param otherUserId -{Caller Id}
     */
    public void trovaCloseGadget_Chat(String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCloseGadget_Chat);
            values.put("result", "failed");
            values.put("msg", "otherUserId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCloseGadget_Chat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_CLOSE_AGENT_CHAT);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCloseGadget_Chat);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    /**
     * This method used to send Call busy
     *
     * @param otherUserId -{Caller Id}
     */
    public void trovaCalleeBusy(String otherUserId) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaCalleBusy);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaCalleBusy);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.CALLEEBUSY);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaCalleBusy);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    /**
     * Sync App State
     *
     * @param appState - {App State}
     * @param priority - {Priority}
     * @param ttl      - {Time To Live}
     */
    public void trovaSyncAppData(String appState, String priority, int ttl) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(appState)) {
            values.put("trovaEvent", OnTrovaAppState);
            values.put("result", "failed");
            values.put("msg", "appState is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAppState);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.SYNCAPPSTATE);
            intent.setPackage(packageName);
            intent.putExtra("appState", appState);
            intent.putExtra("priority", priority);
            intent.putExtra("ttl", ttl);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaAppState);
            values.put("result", "success");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }

    }

    /**
     * Get all Sync App State
     */
    public void trovaGetAllSyncAppData() {
        HashMap<String, Object> values = new HashMap<>();
        if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnGetAllSyncAppState);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            values.put("trovaEvent", OnGetAllSyncAppState);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

            Intent intent = new Intent();
            intent.setAction(Constants.GETALLSYNCAPPSTATE);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

        }

    }

    /**
     * Update Sync App State
     *
     * @param appStateId -{App State Id}
     */
    public void trovaUpdateSyncAppData(String appStateId) {
        HashMap<String, Object> values = new HashMap<>();
        if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaUpdateSyncAppData);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (appStateId != null && appStateId.isEmpty()) {
            Intent intent = new Intent();
            intent.setAction(Constants.UPDATESYNCAPPSTATE);
            intent.setPackage(packageName);
            intent.putExtra("appStateId", appStateId);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaUpdateSyncAppData);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
        } else {
            values.put("trovaEvent", OnTrovaUpdateSyncAppData);
            values.put("result", "failed");
            values.put("msg", "appStateId should not be empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * To Start Record
     */
    public void trovaRecord_Init() {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(preferenceUtil.getRecordFolder())) {
            values.put("trovaEvent", OnTrovaRecord_Init);
            values.put("result", "failed");
            values.put("msg", "folderName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaRecord_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.START_RECORD);
            intent.setPackage(packageName);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaRecord_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        }
    }


    /**
     * Setup Available Agent list
     *
     * @param activity - {Activity Object}
     * @param callMode - {callMode - {"audio" or "video"}}
     * @param AgentKey - {Agent Key}
     * @return - {true or false}
     */
    public boolean trovaListAvailableAgents_Init(Activity activity, String callMode, String AgentKey) {
        HashMap<String, Object> values = new HashMap<>();
        ArrayList<String> permissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllAudioVideoPermissions());
        if (permissions.size() > 0) {
            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "failed");
            values.put("msg", "Permission required");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(callMode)) {
            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "failed");
            values.put("msg", "callMode is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (TextUtils.isEmpty(AgentKey)) {
            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "failed");
            values.put("msg", "AgentKey is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (!callMode.equalsIgnoreCase("audio") && !callMode.equalsIgnoreCase("video")) {

            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "failed");
            values.put("msg", "Pass proper callMode i.e audio or video");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {

            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.AVAILABLE_AGENTS);
            intent.setPackage(packageName);
            intent.putExtra("mode", callMode.toLowerCase());
            intent.putExtra("AgentKey", AgentKey);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaListAvailableAgents_Init);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
            return true;
        }
        return false;

    }

    /**
     * To escalate
     *
     * @param otherUserId
     * @param extraData
     */
    public void trovaAddToConference(String otherUserId, String extraData) {

        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(otherUserId)) {
            values.put("trovaEvent", OnTrovaAddToConf);
            values.put("result", "failed");
            values.put("msg", "callerId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAddToConf);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.ADDTOCONF);
            intent.setPackage(packageName);
            intent.putExtra("otherUserId", otherUserId);
            intent.putExtra("extraData", extraData);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaAddToConf);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);


        }
    }

    /**
     * Swich camera
     */
    public void trovaSwitchCamera() {
        Intent intent = new Intent();
        intent.setAction(Constants.CHANGE_CAMERA);
        intent.setPackage(packageName);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    /**
     * This method used to Make all object free in Library
     */
    public void trovaFree() {
        Intent intent = new Intent();
        intent.setAction(Constants.TROVASDKFREE);
        intent.setPackage(packageName);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    /**
     * To add group chat
     *
     * @param groupname    - {groupname}
     * @param participants - {participants}
     */
    public void trovaAddtoGroupChat(String groupname, ArrayList<String> participants) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(groupname)) {
            values.put("trovaEvent", OnTrovaAddToGroupChat);
            values.put("result", "failed");
            values.put("msg", "groupname is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaAddToGroupChat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_GROUP_CHAT);
            intent.setPackage(packageName);
            intent.putExtra("groupname", groupname);
            intent.putExtra("participants", participants);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaAddToGroupChat);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * To remove group chat
     *
     * @param groupname    - {groupname}
     * @param participants - {participants}
     */
    public void trovaRemovefromGroupChat(String groupname, ArrayList<String> participants) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(groupname)) {
            values.put("trovaEvent", OnTrovaRemoveToGroupChat);
            values.put("result", "failed");
            values.put("msg", "groupname is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaRemoveToGroupChat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);

        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_REMOVE_GROUP_CHAT);
            intent.setPackage(packageName);
            intent.putExtra("groupname", groupname);
            intent.putExtra("participants", participants);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaRemoveToGroupChat);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }

    /**
     * Send Group Chat
     *
     * @param message      - {message}
     * @param productId    - {productId}
     * @param groupName    - {groupName}
     * @param subTitle     - {subTitle}
     * @param displayText  - {displayText}
     * @param messageId    - {messageId}
     * @param participants - {participants}
     */
    public void trovaXmit_GroupChat(String message, String productId, String groupName, String subTitle, String displayText, String messageId, ArrayList<String> participants) {
        HashMap<String, Object> values = new HashMap<>();
        if (TextUtils.isEmpty(message)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "message is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(productId)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "productId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(groupName)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "groupName is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(subTitle)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "subTitle is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(displayText)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "displayText is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (TextUtils.isEmpty(messageId)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "messageId is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (participants == null || participants.size() == 0) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "participants list is empty");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else if (NetworkUtil.isNetworkNotAvailable(context)) {
            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "failed");
            values.put("msg", "Network not available");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        } else {
            Intent intent = new Intent();
            intent.setAction(Constants.TROVA_XMIT_GROUP_CHAT);
            intent.setPackage(packageName);
            intent.putExtra("message", message);
            intent.putExtra("productId", productId);
            intent.putExtra("groupName", groupName);
            intent.putExtra("subTitle", subTitle);
            intent.putExtra("displayText", displayText);
            intent.putExtra("messageId", messageId);
            intent.putExtra("participants", participants);
            LocalBroadcastManager.getInstance(context).sendBroadcast(intent);

            values.put("trovaEvent", OnTrovaXmitGroupChat);
            values.put("result", "success");
            values.put("env", preferenceUtil.isWidget() ? "widget" : "mobile");
            TrovaApiService.constructCallback(TrovaApiService.trovaApiCallback, values);
        }
    }


    public enum RegsitrationType {
        FCM, APIN, VOIP
    }


    public enum ScreenShareType {
        OneOnOne, Conference
    }
}

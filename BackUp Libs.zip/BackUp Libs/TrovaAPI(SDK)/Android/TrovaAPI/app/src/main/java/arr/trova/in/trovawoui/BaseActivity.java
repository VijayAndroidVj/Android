package arr.trova.in.trovawoui;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;

import arr.trova.in.trovawoui.Utils.PermissionCheck;
import arr.trova.in.trovawoui.Utils.PreferenceUtil;

/**
 * Created by iyara_rajan on 01-08-2017.
 */

public class BaseActivity extends AppCompatActivity {

    protected boolean permissionGranted;
    private ArrayList<String> pendingPermissions;
    protected Activity activity;
    private boolean askPermission;
    protected PreferenceUtil preferenceUtil;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferenceUtil = new PreferenceUtil(this);
        activity = this;
        pendingPermissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
        if (pendingPermissions.size() == 0) {
            permissionGranted = true;
        } else {
            askPermission = true;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (askPermission) {
                askPermission = false;
                permissionGranted = false;
                PermissionCheck.requestPermission(activity, pendingPermissions, 1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                pendingPermissions = PermissionCheck.checkPermission(activity, PermissionCheck.getAllPermissions());
                if (pendingPermissions.size() == 0) {
                    askPermission = false;
                    permissionGranted = true;
                } else {
                    askPermission = true;
                    permissionGranted = false;
                }

                break;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}

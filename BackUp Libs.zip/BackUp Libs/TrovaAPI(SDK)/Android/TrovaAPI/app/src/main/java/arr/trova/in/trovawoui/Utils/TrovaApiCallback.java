package arr.trova.in.trovawoui.Utils;

import org.json.JSONObject;

/**
 * Created by iyara_rajan on 29-07-2017.
 */

public interface TrovaApiCallback {
    String OnTrovaSDK_Init = "OnTrovaSDK_Init";
    String OnTrovaCall_Init = "OnTrovaCall_Init";
    String OnTrovaReceiveCall = "OnTrovaReceiveCall";
    String OnTrovaCall_Answer = "OnTrovaCall_Answer";
    String OnTrovaAcceptedCall = "OnTrovaAcceptedCall";
    String OnTrovaCall_End = "OnTrovaCall_End";
    String OnTrovaCall_Reject = "OnTrovaCall_Reject";
    String OnTrovaReceiveRejectCall = "OnTrovaReceiveRejectCall";
    String OnTrovaCall_InitMissedCall = "OnTrovaCall_InitMissedCall";
    String OnTrovaReceiveMissedCall = "OnTrovaReceiveMissedCall";
    String OnTrovaXmit_Chat = "OnTrovaXmit_Chat";
    String OnTrovaReceiveChat = "OnTrovaReceiveChat";
    String OnTrovaXmit_File = "OnTrovaXmit_File";
    String OnTrovaReceiveFile = "OnTrovaReceiveFile";
    String OnTrovaXmit_Notification = "OnTrovaXmit_Notification";
    String OnTrovaReceiveNotification = "OnTrovaReceiveNotification";
    String OnTrovaSession_Disconnect = "OnTrovaSession_Disconnect";
    String OnTrovaCallState = "OnTrovaCallState";
    String OnTrovaScreenShareState = "OnTrovaScreenShareState";
    String OnTrovaAmazonS3_Init = "OnTrovaAmazonS3_Init";
    String OnTrovaAmazonS3_Upload = "OnTrovaAmazonS3_Upload";
    String OnTrovaAmazonS3_Download = "OnTrovaAmazonS3_Download";
    String OnTrovaConference_Init = "OnTrovaConference_Init";
    String OnTrovaCalleBusy = "OnTrovaCalleBusy";
    String OnTrovaReceiveCalleeBusy = "OnTrovaReceiveCalleeBusy";
    String OnTrovaAddToConf = "OnTrovaAddToConf";

    String OnTrovaRecord_Init = "OnTrovaRecord_Init";
    String OnTrovaRececiveConfCall = "OnTrovaRececiveConfCall";
    String OnTrovaConference_End = "OnTrovaConference_End";
    String OnTrovaReceiveEndConfCall = "OnTrovaReceiveEndConfCall";
    String OnTrovaConference_XmitNotification = "OnTrovaConference_XmitNotification";
    String OnTrovaXmit_Registration2Server = "OnTrovaXmit_Registration2Server";
    String OnTrovaXmit_SendPayload = "OnTrovaXmit_SendPayload";
    String OnTrovaGadgetCall_Init = "OnTrovaGadgetCall_Init";
    String OnTrovaAgentCall_Init = "OnTrovaAgentCall_Init";
    String OnTrovaListAvailableAgents_Init = "OnTrovaListAvailableAgents_Init";
    String OnTrovaReceiveListAvailableAgents = "OnTrovaReceiveListAvailableAgents";
    String OnTrovaAgentInfo = "OnTrovaAgentInfo";
    String OnTrovaGadgetChat_Init = "OnTrovaGadgetChat_Init";
    String OnTrovaAgentChatInfo = "OnTrovaAgentChatInfo";
    String OnTrovaWidgetInfo = "OnTrovaWidgetInfo";
    String OnTrovaWidgetChatInfo = "OnTrovaWidgetChatInfo";
    String OnTrovaAcknowledgeMessage = "OnTrovaAcknowledgeMessage";
    String OnTrovaGetAllMessages = "OnTrovaGetAllMessages";
    String OnTrovaReceiveGetAllOfflineReceiveMessage = "OnTrovaReceiveGetAllOfflineReceiveMessage";
    String OnTrovaReceiveCloseChat = "OnTrovaReceiveCloseChat";
    String OnTrovaReceiveGetAllSyncSendMessage = "OnTrovaReceiveGetAllSyncSendMessage";
    String OnTrovaReceiveLocalStream = "OnTrovaReceiveLocalStream";
    String OnTrovaReceiveRemoteStream = "OnTrovaReceiveRemoteStream";
    String OnTrovaReceiveConfScreenShare = "OnTrovaReceiveConfScreenShare";
    String OnTrovaConference_ScreenShareInit = "OnTrovaConference_ScreenShareInit";
    String OnTrovaReceiveScreenShareStream = "OnTrovaReceiveScreenShareStream";
    String OnTrovaSessionUserOnline = "OnTrovaSessionUserOnline";
    String OnTrovaReceiveEndScreenShare = "OnTrovaReceiveEndScreenShare";
    String OnTrovaReceiveEndCall = "OnTrovaReceiveEndCall";
    String OnTrovaUpdateSyncAppData = "OnTrovaUpdateSyncAppData";
    String OnTrovaSyncMessage = "OnTrovaSyncMessage";
    String OnTrovaRequestToConf = "OnTrovaRequestToConf";
    String OnPermissionsRequired = "OnPermissionsRequired";
    String InProgress = "InProgress";
    String OnTrovaAppState = "OnTrovaAppState";
    String OnTrovaAddToGroupChat = "OnTrovaAddToGroupChat";
    String OnTrovaRemoveToGroupChat = "OnTrovaRemoveToGroupChat";
    String OnTrovaXmitGroupChat = "OnTrovaXmitGroupChat";
    String OnTrovaCloseGadget_Chat = "OnTrovaCloseGadget_Chat";
    String OnTrovaCloseSDK_Chat = "OnTrovaCloseSDK_Chat";

    String OnGetAllUnDeliverdMessages = "OnGetAllUnDeliverdMessages";
    String OnRecvSyncAppState = "OnRecvSyncAppState";
    String OnGetAllSyncAppState = "OnGetAllSyncAppState";

    void TrovaEvents(JSONObject message);

}

package com.trova.android.trovauiaar.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.Log;

import com.trova.android.trovauiaar.Db.DataBaseHandler;
import com.trova.android.trovauiaar.Globalclass;
import com.trova.android.trovauiaar.R;
import com.trova.android.trovauiaar.TrovaUIAPICallBack;
import com.trova.android.trovauiaar.Utils.JoinConferenceDialog;
import com.trova.android.trovauiaar.chat.TrovaChat;
import com.trova.android.trovauiaar.model.ChatMessageModel;
import com.trova.android.trovauiaar.model.UserModel;
import com.trova.android.trovauiaar.video.ReachVideoCall;
import com.trova.android.trovauiaar.voice.ReachVoiceCall;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import arr.trova.in.trovawoui.Utils.PreferenceUtil;
import arr.trova.in.trovawoui.Utils.TrovaApiCallback;
import arr.trova.in.trovawoui.services.TrovaApiService;

import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnGetAllSyncAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnGetAllUnDeliverdMessages;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnRecvSyncAppState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAcceptedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentChatInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAgentInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Download;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaAmazonS3_Upload;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaCallState;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRececiveConfCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveCalleeBusy;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveChat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveEndCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveFile;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveGetAllOfflineReceiveMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveGetAllSyncSendMessage;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveLocalStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveMissedCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveNotification;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRejectCall;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaReceiveRemoteStream;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaRequestToConf;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaSDK_Init;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaWidgetChatInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaWidgetInfo;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_Chat;
import static arr.trova.in.trovawoui.Utils.TrovaApiCallback.OnTrovaXmit_File;
import static com.trova.android.trovauiaar.TrovaUIAPICallBack.OnTrovaUISDK_Init;
import static com.trova.android.trovauiaar.Utils.JoinConferenceDialog.GadgetAgent;
import static com.trova.android.trovauiaar.chat.ChatListActivity.chatListActivity;
import static com.trova.android.trovauiaar.pstn.CallReceiver.isOnPSTNCall;

/**
 * Created by razin on 4-10-2017.
 */

public class TrovaService extends TrovaApiService implements SensorEventListener {

    public static TrovaApiCallback trovaApiCallback = new TrovaApiCallback() {
        @Override
        public void TrovaEvents(JSONObject message) {
            TrovaEvent(message);
        }
    };
    public static TrovaUIAPICallBack trovaUIAPICallBack;
    //    public static String displayName = "";
    public static String callerName = "";
//    public static String agentKey = "";

    public static HashMap<String, String> agentKeyHashmap = new HashMap<>();
    public static HashMap<String, String> displaynameHashmap = new HashMap<>();

    private static TrovaService trovaService;

    public static String KEY_ACCEPT_CALL = "accept_call";
    public static String KEY_REJECT_CALL = "reject_call";
    public static String KEY_JOIN_CONFERENCE = "join_conference";
    public static String KEY_REJECT_CONFERENCE = "reject_conference";
    public static UserModel userNotif;
    public static String callmode;
    public static NotificationManager notificationManager;
    public static long lastReceivedCallTime = 0;
    public static int i = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("onCreate", "");
        trovaService = this;
        sensorEventListener = this;
        MyReceiver myReceiver = new MyReceiver();
        IntentFilter filter = new IntentFilter(KEY_ACCEPT_CALL);
        IntentFilter filter2 = new IntentFilter(KEY_REJECT_CALL);
        IntentFilter filter3 = new IntentFilter(KEY_JOIN_CONFERENCE);
        IntentFilter filter4 = new IntentFilter(KEY_REJECT_CONFERENCE);
        this.registerReceiver(myReceiver, filter);
        this.registerReceiver(myReceiver, filter2);
        this.registerReceiver(myReceiver, filter3);
        this.registerReceiver(myReceiver, filter4);
        createSensorManager();
    }

    public static void TrovaEvent(final JSONObject jsonObject) {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String event = jsonObject.getString("trovaEvent");
//                    MyLogger.appendLog(event, jsonObject.toString());
                    switch (event) {
                        case OnTrovaSDK_Init:
                            if (Globalclass.trovaSDK_init != null)
                                Globalclass.trovaSDK_init.trovaAmazonS3_Init(trovaService, "trovamedia", "us-east-1:75f62414-b651-471f-9211-69165861a261", "us-east-1");
                            if (jsonObject.has("result")) {
                                String result = jsonObject.getString("result");
                                if (result.equalsIgnoreCase("alreadyLoggedIn"))
                                    Globalclass.trovaSDK_init.trovaFree();
                            }
                            jsonObject.put("trovaEvent", OnTrovaUISDK_Init);
                            trovaUIAPICallBack.setTrovaUICallBack(jsonObject);
                            // }
                            break;

                        case OnTrovaReceiveCall:
                            UserModel userModel = new UserModel();
                            Calendar cal = Calendar.getInstance();
                            TimeZone tz = cal.getTimeZone();
                            String timezone = tz.getDisplayName();
                            logData("zone", timezone);
                            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                            String currDate = df.format(cal.getTime());
                            logData("zone", currDate);
                            df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                            String time = df.format(cal.getTime());
                            logData("zone", time);
                            String callDuration = "00:00:00";
                            userModel.setUserId(jsonObject.getString("callerId"));
                            userModel.setDate(currDate);
                            userModel.setTime(time);
                            userModel.setStatus(1);
                            userModel.setDisplayName(displaynameHashmap.get(userModel.getUserId()));
                            String callerNam = jsonObject.has("callerName") ? jsonObject.getString("callerName") : "";
                            if (!TextUtils.isEmpty(callerNam)) {
                                callerName = callerNam;
                            }
                            userModel.setName(callerName);
                            DataBaseHandler dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                            if (TextUtils.isEmpty(userModel.getName())) {
                                String userName = dataBaseHandler.getUserName(userModel.getUserId());
                                userModel.setName(userName);
                            }
                            boolean allowCall = false;
                            if (jsonObject.getString("env").equalsIgnoreCase("widget")) {
                                GadgetAgent = userModel.getUserId();
                                userModel.setAgentKey(GadgetAgent);
                                PreferenceUtil preferenceUtil = new PreferenceUtil(trovaService);
                                if (ReachVoiceCall.isVoiceCallAlive) {
                                    if (ReachVoiceCall.conferenceId != null && ReachVoiceCall.conferenceId.equalsIgnoreCase(ReachVoiceCall.md5(preferenceUtil.getBusinessKey() + userModel.getUserId()))) {
                                        allowCall = true;
                                    }
                                } else if (ReachVideoCall.isVideoCallAlive) {
                                    if (ReachVoiceCall.conferenceId != null && ReachVoiceCall.conferenceId.equalsIgnoreCase(ReachVoiceCall.md5(preferenceUtil.getBusinessKey() + userModel.getUserId()))) {
                                        allowCall = true;
                                    }
                                }
                            } else {
                                GadgetAgent = "";
                                JoinConferenceDialog.mainAgent = "";
                                JoinConferenceDialog.agentName = "";
                                JoinConferenceDialog.widgetName = "";

                                userModel.setAgentKey("");
                                userModel.setDisplayName("");
                                // dataBaseHandler.saveContactLogs(userModel);
//                                dataBaseHandler.saveFilteredContacts(userModel);
                            }

                            if (allowCall) {
                                lastReceivedCallTime = System.currentTimeMillis();
                                PowerManager pm = (PowerManager) trovaService.getSystemService(POWER_SERVICE);
                                PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "tag");
                                wl.acquire();
//                                if (agentLogActivity != null) {
//                                    agentLogActivity.callBackListener(null, "refresh");
//                                }
                                callmode = "audio";
                                Intent CallActivity = null;
                                if (jsonObject.getString("callMode").equalsIgnoreCase("audio")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVoiceCall.class);
                                    callmode = "audio";
                                    CallActivity = new Intent(trovaService.getApplicationContext(), ReachVoiceCall.class);
                                } else if (jsonObject.getString("callMode").equalsIgnoreCase("video")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVideoCall.class);
                                    CallActivity = new Intent(trovaService.getApplicationContext(), ReachVideoCall.class);
                                    callmode = "video";
                                }
                                CallActivity.putExtra("date", userModel.getDate());
                                CallActivity.putExtra("otherUserName", userModel.getName());
                                CallActivity.putExtra("businessName", displaynameHashmap.get(jsonObject.getString("callerId")));
//                                String agentKey = jsonObject.getString("agentKey");
                                CallActivity.putExtra("agentKey", agentKeyHashmap.get(jsonObject.getString("callerId")));
//                                if (!TextUtils.isEmpty(agentKey)) {
//                                    CallActivity.putExtra("isAgentCall", 1);
//                                }
                                CallActivity.putExtra("otherUserID", jsonObject.getString("callerId"));
                                CallActivity.putExtra("callType", "answer");
                                CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                trovaService.getApplicationContext().startActivity(CallActivity);
                                userNotif = userModel;
                                createIncomingCallNotification();
                            } else if (ReachVoiceCall.isVoiceCallAlive || isOnPSTNCall) {
//                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                Globalclass.trovaSDK_init.trovaCalleeBusy(userModel.getUserId());
                            } else if (ReachVideoCall.isVideoCallAlive || isOnPSTNCall) {
//                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                                Globalclass.trovaSDK_init.trovaCalleeBusy(userModel.getUserId());
                            } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null || isOnPSTNCall) {
//                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                Globalclass.trovaSDK_init.trovaCalleeBusy(userModel.getUserId());
                            } else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                Globalclass.trovaSDK_init.trovaCalleeBusy(userModel.getUserId());
                            }*/ else {
                                lastReceivedCallTime = System.currentTimeMillis();

                                PowerManager pm = (PowerManager) trovaService.getSystemService(POWER_SERVICE);
                                PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "tag");
                                wl.acquire();
//                                if (agentLogActivity != null) {
//                                    agentLogActivity.callBackListener(null, "refresh");
//                                }
                                Intent CallActivity = null;
                                callmode = "audio";
                                if (jsonObject.getString("callMode").equalsIgnoreCase("audio")) {
                                    callmode = "audio";
//                                CallActivity = new Intent(getApplicationContext(), ReachVoiceCall.class);
                                    CallActivity = new Intent(trovaService.getApplicationContext(), ReachVoiceCall.class);
                                } else if (jsonObject.getString("callMode").equalsIgnoreCase("video")) {
                                    callmode = "video";
//                                CallActivity = new Intent(getApplicationContext(), ReachVideoCall.class);
                                    CallActivity = new Intent(trovaService.getApplicationContext(), ReachVideoCall.class);
                                }
                                CallActivity.putExtra("date", userModel.getDate());
                                CallActivity.putExtra("otherUserName", userModel.getName());
                                CallActivity.putExtra("businessName", displaynameHashmap.get(jsonObject.getString("callerId")));
//                                String agentKey = jsonObject.getString("agentKey");
                                if (jsonObject.getString("env").equalsIgnoreCase("widget")) {
                                    CallActivity.putExtra("status", 1);
                                    CallActivity.putExtra("agentKey", agentKeyHashmap.get(jsonObject.getString("callerId")));
                                }
//                                if (!TextUtils.isEmpty(agentKey)) {
//                                    CallActivity.putExtra("isAgentCall", 1);
//                                }
                                CallActivity.putExtra("otherUserID", jsonObject.getString("callerId"));
                                CallActivity.putExtra("callType", "answer");
                                CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                trovaService.getApplicationContext().startActivity(CallActivity);
                                userNotif = userModel;
                                createIncomingCallNotification();
                            }
                            break;

                        case OnTrovaRececiveConfCall:
                            userModel = new UserModel();
                            cal = Calendar.getInstance();
                            tz = cal.getTimeZone();
                            timezone = tz.getDisplayName();
                            logData("zone", timezone);
                            df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                            currDate = df.format(cal.getTime());
                            logData("zone", currDate);
                            df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                            time = df.format(cal.getTime());
                            logData("zone", time);
                            callDuration = "00:00:00";
                            userModel.setUserId(jsonObject.getString("callerId"));
                            userModel.setDate(currDate);
                            userModel.setTime(time);
                            userModel.setStatus(1);
                            userModel.setDisplayName(displaynameHashmap.get(jsonObject.getString("callerId")));
                            userModel.setName(callerName);
                            dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                            if (TextUtils.isEmpty(userModel.getName())) {
                                String userName = dataBaseHandler.getUserName(userModel.getUserId());
                                userModel.setName(userName);
                            }
                            if (jsonObject.getString("env").equalsIgnoreCase("widget")) {
//                                dataBaseHandler.saveAgentLogs(userModel);
                            } else {
//                                dataBaseHandler.saveContactLogs(userModel);
//                                dataBaseHandler.saveFilteredContacts(userModel);
                            }
                            break;
                        case OnTrovaAgentInfo:
                        case OnTrovaReceiveCalleeBusy:
                            if (ReachVoiceCall.reachVoiceCall != null) {
                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            } else if (ReachVideoCall.reachVideoCall != null) {
                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                            } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            }*/
                            break;

                        case OnTrovaReceiveMissedCall:
                            if (ReachVoiceCall.reachVoiceCall != null) {
                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            } else if (ReachVideoCall.reachVideoCall != null) {
                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                            } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            }*/
                            break;
                        case OnTrovaCallState:
                        case OnTrovaReceiveEndCall:
                            //End call
                            if (ReachVoiceCall.reachVoiceCall != null) {
                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            } else if (ReachVideoCall.reachVideoCall != null) {
                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                            }/* else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            }*/
                            break;
                        case OnTrovaReceiveRejectCall:
                            if (ReachVoiceCall.reachVoiceCall != null) {
                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            } else if (ReachVideoCall.reachVideoCall != null) {
                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                            }/* else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            }*/
                            break;
                        case OnTrovaWidgetInfo:

                            String widgetCallerId = jsonObject.getString("widgetCallerId");
                            String displayName = jsonObject.getString("displayName");
                            callerName = jsonObject.getString("widgetUserName");
                            String agentKey = jsonObject.getString("agentKey");
                            agentKeyHashmap.put(widgetCallerId, agentKey);
                            displaynameHashmap.put(widgetCallerId, displayName);
                            break;
                        case OnTrovaWidgetChatInfo:
                            String callerId = jsonObject.getString("widgetCallerId");
                            callerName = jsonObject.getString("widgetUserName");
                            displayName = jsonObject.getString("displayName");
                            agentKey = jsonObject.getString("agentKey");
                            agentKeyHashmap.put(callerId, agentKey);
                            displaynameHashmap.put(callerId, displayName);
                            break;
                        case OnTrovaReceiveRemoteStream:
                        case OnTrovaReceiveLocalStream:
                        case OnTrovaAcceptedCall:
                            if (ReachVoiceCall.reachVoiceCall != null) {
                                ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            } else if (ReachVideoCall.reachVideoCall != null) {
                                ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                            } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                            }*/
                            break;
                        case OnTrovaReceiveChat:
                            PreferenceUtil preferenceUtil = new PreferenceUtil(trovaService);
                            JSONObject sendNotificationObject = new JSONObject();
                            sendNotificationObject.put("event", "onMessageDelivered");
                            sendNotificationObject.put("messageId", jsonObject.getLong("messageId"));
                            sendNotificationObject.put("userId", preferenceUtil.getUserId());

                            try {
                                Globalclass.trovaSDK_init.trovaXmit_Notification(jsonObject.getString("senderId"), sendNotificationObject.toString(), "high", 0, "", "");
                                long timemilliseconds = System.currentTimeMillis();
                                cal = Calendar.getInstance();
                                tz = cal.getTimeZone();
                                timezone = tz.getDisplayName();
                                logData("zone", timezone);
                                df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                currDate = df.format(cal.getTime());
                                logData("zone", currDate);
                                df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                                time = df.format(cal.getTime());
                                String message = jsonObject.getString("message");
                                String senderId = jsonObject.getString("senderId");
                                ChatMessageModel chatMessageModel = new ChatMessageModel();
                                chatMessageModel.setMessageId(jsonObject.getLong("messageId"));
                                chatMessageModel.setPhone(senderId);
                                chatMessageModel.setMessage(message);
                                chatMessageModel.setMimeType("text");
                                chatMessageModel.setWidgetPhone(agentKeyHashmap.get(senderId));
                                chatMessageModel.setMessageSentOrReceived(1);
                                chatMessageModel.setName(jsonObject.getString("senderName"));
                                chatMessageModel.setDate(currDate);
                                chatMessageModel.setTime(time);
                                chatMessageModel.setTimeZone(timezone);
                                chatMessageModel.setSeenstatus(0);
                                chatMessageModel.setId("0");
                                chatMessageModel.setFileUploading(true);
                                chatMessageModel.setTimemilliseconds(timemilliseconds);

                                userModel = new UserModel();
                                cal = Calendar.getInstance();
                                tz = cal.getTimeZone();
                                timezone = tz.getDisplayName();
                                logData("zone", timezone);
                                df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                currDate = df.format(cal.getTime());
                                logData("zone", currDate);
                                df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                                time = df.format(cal.getTime());
                                logData("zone", time);
                                userModel.setDate(currDate);
                                userModel.setTime(time);
                                userModel.setStatus(1);
                                userModel.setMessage(chatMessageModel.getMessage());
                                userModel.setMimeType(chatMessageModel.getMimeType());
                                userModel.setUserId(senderId);
                                dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                                String businessname = displaynameHashmap.get(userModel.getUserId());
                                if (TextUtils.isEmpty(businessname)) {
                                    businessname = dataBaseHandler.getBusinessName(userModel.getUserId());
                                }

                                String cname = callerName;
                                if (!TextUtils.isEmpty(chatMessageModel.getName())) {
                                    cname = chatMessageModel.getName();
                                }
                                userModel.setName(cname);
                                boolean widgetChat = false;
                                dataBaseHandler.saveChatMessage(chatMessageModel);
                                userModel.setUnseenMessageCount(dataBaseHandler.unseenCount(userModel.getUserId()));
                                if (TrovaChat.trovaChat != null) {
                                    if (TrovaChat.chatSenderId.equalsIgnoreCase(senderId)) {
                                        //handle trova event
                                        userModel.setUnseenMessageCount(0);
                                        TrovaChat.trovaChat.sendMessageSeenStatus(chatMessageModel.getMessageId(), "");
                                        TrovaChat.chatList.add(chatMessageModel);
                                        TrovaChat.trovaChat.TrovaEvents(TrovaChat.chatList);
                                    } else {
                                        Notification.Builder mNotificationBuilder = new Notification.Builder(trovaService.getApplicationContext());
                                        Intent ChatActivity = new Intent(trovaService.getApplicationContext(), TrovaChat.class);
                                        try {
                                            ChatActivity.putExtra("otherUserName", chatMessageModel.getName());
                                            ChatActivity.putExtra("otherUserID", senderId);
                                            ChatActivity.putExtra("businessName", userModel.getDisplayName());
                                            ChatActivity.putExtra("isWidgetChat", widgetChat);
                                            ChatActivity.putExtra("incoming", 1);
                                            ChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            PendingIntent resultIntent = PendingIntent.getActivity(trovaService.getApplicationContext(), 0, ChatActivity,
                                                    PendingIntent.FLAG_UPDATE_CURRENT);

                                            Uri notificationSoundURI = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);

                                            String title = "";
                                            if (!TextUtils.isEmpty(userModel.getDisplayName())) {
                                                title = userModel.getDisplayName();
                                            } else if (!TextUtils.isEmpty(userModel.getName())) {
                                                title = userModel.getName();
                                            } else {
                                                title = userModel.getUserId();
                                            }
                                            mNotificationBuilder.setContentTitle(title);
                                            mNotificationBuilder.setContentText(message).setTicker(message);
                                            mNotificationBuilder.setAutoCancel(true);
                                            mNotificationBuilder.setSound(notificationSoundURI);
                                            mNotificationBuilder.setContentIntent(resultIntent).setPriority(Notification.PRIORITY_MAX);
                                            String CHANNEL_ID = trovaService.getPackageName() + "_Channel";// The id of the channel.

                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                mNotificationBuilder.setChannelId(CHANNEL_ID);
                                            }
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                                mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                                mNotificationBuilder.setColor(trovaService.getResources().getColor(R.color.colorPrimary));
                                            } else {
                                                mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                            }
                                            NotificationManager notificationManager = (NotificationManager) trovaService.getSystemService(trovaService.getApplicationContext().NOTIFICATION_SERVICE);
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                String channelName = trovaService.getPackageName();
                                                int importance = NotificationManager.IMPORTANCE_HIGH;
                                                NotificationChannel mChannel = new NotificationChannel(
                                                        CHANNEL_ID, channelName, importance);
                                                notificationManager.createNotificationChannel(mChannel);
                                            }
                                            mNotificationBuilder.setStyle(new Notification.BigTextStyle()
                                                    .bigText(message));
                                            Notification nf = mNotificationBuilder.build();
                                            i = (i + 1);
                                            notificationManager.notify(i, nf);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                } else {
                                    Notification.Builder mNotificationBuilder = new Notification.Builder(trovaService.getApplicationContext());
                                    Intent ChatActivity = new Intent(trovaService.getApplicationContext(), TrovaChat.class);
                                    try {
                                        ChatActivity.putExtra("otherUserName", chatMessageModel.getName());
                                        ChatActivity.putExtra("otherUserID", senderId);
                                        ChatActivity.putExtra("businessName", userModel.getDisplayName());
                                        ChatActivity.putExtra("isWidgetChat", widgetChat);
                                        ChatActivity.putExtra("incoming", 1);

                                        ChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        PendingIntent resultIntent = PendingIntent.getActivity(trovaService.getApplicationContext(), 0, ChatActivity,
                                                PendingIntent.FLAG_UPDATE_CURRENT);

                                        Uri notificationSoundURI = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                        String title = "";
                                        if (!TextUtils.isEmpty(userModel.getDisplayName())) {
                                            title = userModel.getDisplayName();
                                        } else if (!TextUtils.isEmpty(userModel.getName())) {
                                            title = userModel.getName();
                                        } else {
                                            title = userModel.getUserId();
                                        }
                                        mNotificationBuilder.setContentTitle(title);
                                        mNotificationBuilder.setContentText(message).setTicker(message);
                                        mNotificationBuilder.setAutoCancel(true);
                                        mNotificationBuilder.setSound(notificationSoundURI);
                                        mNotificationBuilder.setContentIntent(resultIntent).setPriority(Notification.PRIORITY_MAX);
                                        String CHANNEL_ID = trovaService.getPackageName() + "_Channel";// The id of the channel.

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            mNotificationBuilder.setChannelId(CHANNEL_ID);
                                        }
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                            mNotificationBuilder.setColor(trovaService.getResources().getColor(R.color.colorPrimary));
                                        } else {
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                        }
                                        NotificationManager notificationManager = (NotificationManager) trovaService.getSystemService(trovaService.getApplicationContext().NOTIFICATION_SERVICE);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            String channelName = trovaService.getPackageName();
                                            int importance = NotificationManager.IMPORTANCE_HIGH;
                                            NotificationChannel mChannel = new NotificationChannel(
                                                    CHANNEL_ID, channelName, importance);
                                            notificationManager.createNotificationChannel(mChannel);
                                        }
                                        mNotificationBuilder.setStyle(new Notification.BigTextStyle()
                                                .bigText(message));
                                        Notification nf = mNotificationBuilder.build();
                                        i = (i + 1);
                                        notificationManager.notify(i, nf);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }
                                if (jsonObject.getString("env").equalsIgnoreCase("widget")) {
                                    widgetChat = true;
                                    GadgetAgent = userModel.getUserId();
                                    userModel.setAgentKey(agentKeyHashmap.get(senderId));
                                    userModel.setDisplayName(businessname);
                                    dataBaseHandler.saveAgentLogs(userModel);
                                } else {
                                    userModel.setAgentKey("");
                                    userModel.setDisplayName("");
                                    dataBaseHandler.saveContactLogs(userModel);
                                }
                                if (chatListActivity != null) {
                                    chatListActivity.reload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;

                        case OnTrovaAmazonS3_Upload:
                            if (TrovaChat.trovaChat != null) {
                                //handle trova event
                                TrovaChat.trovaChat.TrovaEvent(jsonObject);
                            }

                            break;
                        case OnTrovaAgentChatInfo:
                        case OnTrovaAmazonS3_Download:

                            if (TrovaChat.trovaChat != null) {

                                //handle trova event
                                TrovaChat.trovaChat.TrovaEvent(jsonObject);
                            }


                            break;
                        case OnTrovaXmit_File:
                        case OnTrovaXmit_Chat:
                            if (TrovaChat.trovaChat != null) {
                                long messageId = jsonObject.getLong("messageId");
                                TrovaChat.trovaChat.updateMesageStatus(messageId, 0);
                            }
                            break;

                        case OnTrovaReceiveFile:
                            preferenceUtil = new PreferenceUtil(trovaService);
                            sendNotificationObject = new JSONObject();
                            sendNotificationObject.put("event", "onMessageDelivered");
                            sendNotificationObject.put("messageId", jsonObject.getLong("messageId"));
                            sendNotificationObject.put("serverPath", jsonObject.getString("filePath"));
                            sendNotificationObject.put("userId", preferenceUtil.getUserId());
                            Globalclass.trovaSDK_init.trovaXmit_Notification(jsonObject.getString("senderId"), sendNotificationObject.toString(), "high", 0, "", "");
                            try {
                                long timemilliseconds = System.currentTimeMillis();
                                cal = Calendar.getInstance();
                                tz = cal.getTimeZone();
                                timezone = tz.getDisplayName();
                                logData("zone", timezone);
                                df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                currDate = df.format(cal.getTime());
                                logData("zone", currDate);
                                df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                                time = df.format(cal.getTime());
                                String senderId = jsonObject.getString("senderId");
                                ChatMessageModel chatMessageModel = new ChatMessageModel();
                                chatMessageModel.setMessageId(jsonObject.getLong("messageId"));
                                chatMessageModel.setPhone(senderId);
                                chatMessageModel.setWidgetPhone(agentKeyHashmap.get(senderId));
                                chatMessageModel.setMessage("");
                                chatMessageModel.setFileName(!jsonObject.has("fileName") ? "" : jsonObject.getString("fileName"));
                                chatMessageModel.setFileSize(!jsonObject.has("fileSize") ? 0 : jsonObject.getLong("fileSize"));
                                chatMessageModel.setDurationTime(!jsonObject.has("mediaDuration") ? "" : jsonObject.getString("mediaDuration"));
                                chatMessageModel.setMediaLink(!jsonObject.has("filePath") ? "" : jsonObject.getString("filePath"));
                                chatMessageModel.setMimeType(jsonObject.getString("fileType"));
                                chatMessageModel.setMessageSentOrReceived(1);
                                chatMessageModel.setName(jsonObject.getString("senderName"));
                                chatMessageModel.setDate(currDate);
                                chatMessageModel.setTime(time);
                                chatMessageModel.setTimeZone(timezone);
                                chatMessageModel.setSeenstatus(0);
                                chatMessageModel.setId("0");
                                chatMessageModel.setFileUploading(true);
                                chatMessageModel.setTimemilliseconds(timemilliseconds);
                                String key = chatMessageModel.getMediaLink();
                                if (key != null && key.contains("amazonaws.com/"))
                                    key = chatMessageModel.getMediaLink().split("amazonaws.com/")[1];

                                if (key.contains(".MOV")) {
                                    key = key.split(".MOV")[0] + ".mp4";
                                }
                                File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + key);
                                chatMessageModel.setFilePath(file.getAbsolutePath());
                                String str_Path = file.getPath().replace(file.getName(), "");
                                File filedir = new File(str_Path);
                                try {
                                    filedir.mkdirs();
                                } catch (Exception ex1) {
                                    ex1.printStackTrace();
                                }
                                Globalclass.trovaSDK_init.trovaAmazonS3_Download(file.getAbsolutePath(), chatMessageModel.getMediaLink().replaceAll("%40", "@"));

                                userModel = new UserModel();
                                cal = Calendar.getInstance();
                                tz = cal.getTimeZone();
                                timezone = tz.getDisplayName();
                                logData("zone", timezone);
                                df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                currDate = df.format(cal.getTime());
                                logData("zone", currDate);
                                df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                                time = df.format(cal.getTime());
                                logData("zone", time);
                                userModel.setDate(currDate);
                                userModel.setTime(time);
                                userModel.setStatus(1);
                                userModel.setMessage(chatMessageModel.getMimeType());
                                userModel.setMimeType(chatMessageModel.getMimeType());
                                userModel.setFileName(chatMessageModel.getFileName());
                                userModel.setUserId(senderId);
                                dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                                String businessname = displaynameHashmap.get(userModel.getUserId());
                                if (TextUtils.isEmpty(businessname)) {
                                    businessname = dataBaseHandler.getBusinessName(userModel.getUserId());
                                }
                                userModel.setDisplayName(businessname);

                                String name = callerName;
                                if (!TextUtils.isEmpty(chatMessageModel.getName())) {
                                    name = chatMessageModel.getName();
                                }
                                dataBaseHandler.saveChatMessage(chatMessageModel);
                                userModel.setName(name);
                                userModel.setUnseenMessageCount(dataBaseHandler.unseenCount(userModel.getUserId()));
                                boolean widgetChat = false;

                                if (TrovaChat.trovaChat != null) {
                                    if (TrovaChat.chatSenderId.equalsIgnoreCase(senderId)) {
                                        userModel.setUnseenMessageCount(0);
                                        //handle trova event
                                        TrovaChat.chatList.add(chatMessageModel);
                                        TrovaChat.trovaChat.TrovaEvents(TrovaChat.chatList);
                                    } else {
                                        Notification.Builder mNotificationBuilder = new Notification.Builder(trovaService.getApplicationContext());
                                        Intent ChatActivity = new Intent(trovaService.getApplicationContext(), TrovaChat.class);
                                        try {
                                            ChatActivity.putExtra("otherUserName", chatMessageModel.getName());
                                            ChatActivity.putExtra("otherUserID", senderId);
                                            ChatActivity.putExtra("businessName", userModel.getDisplayName());
                                            ChatActivity.putExtra("isWidgetChat", widgetChat);
                                            ChatActivity.putExtra("incoming", 1);

                                            ChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            PendingIntent resultIntent = PendingIntent.getActivity(trovaService.getApplicationContext(), 0, ChatActivity,
                                                    PendingIntent.FLAG_UPDATE_CURRENT);

                                            Uri notificationSoundURI = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                            String title = "";
                                            if (!TextUtils.isEmpty(userModel.getDisplayName())) {
                                                title = userModel.getDisplayName();
                                            } else if (!TextUtils.isEmpty(userModel.getName())) {
                                                title = userModel.getName();
                                            } else {
                                                title = userModel.getUserId();
                                            }
                                            String unicode;
                                            if (chatMessageModel.getMimeType().contains("image")) {
                                                unicode = getEmojiByUnicode(0x1F4F7);
                                            } else if (chatMessageModel.getMimeType().contains("video")) {
                                                unicode = getEmojiByUnicode(0x1F3A5);
                                            } else if (chatMessageModel.getMimeType().contains("audio")) {
                                                unicode = getEmojiByUnicode(0x1F3A7);
                                            } else {
                                                unicode = getEmojiByUnicode(0x1F4C1);
                                            }
                                            String message = unicode + " " + chatMessageModel.getMimeType() + " received";
                                            mNotificationBuilder.setContentTitle(title);
                                            mNotificationBuilder.setContentText(message).setTicker(message);
                                            mNotificationBuilder.setAutoCancel(true);
                                            mNotificationBuilder.setSound(notificationSoundURI);
                                            mNotificationBuilder.setContentIntent(resultIntent).setPriority(Notification.PRIORITY_MAX);
                                            String CHANNEL_ID = trovaService.getPackageName() + "_Channel";// The id of the channel.

                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                mNotificationBuilder.setChannelId(CHANNEL_ID);
                                            }
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                                mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                                mNotificationBuilder.setColor(trovaService.getResources().getColor(R.color.colorPrimary));
                                            } else {
                                                mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                            }
                                            NotificationManager notificationManager = (NotificationManager) trovaService.getSystemService(trovaService.getApplicationContext().NOTIFICATION_SERVICE);
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                String channelName = trovaService.getPackageName();
                                                int importance = NotificationManager.IMPORTANCE_HIGH;
                                                NotificationChannel mChannel = new NotificationChannel(
                                                        CHANNEL_ID, channelName, importance);
                                                notificationManager.createNotificationChannel(mChannel);
                                            }
                                            mNotificationBuilder.setStyle(new Notification.BigTextStyle()
                                                    .bigText(message));
                                            Notification nf = mNotificationBuilder.build();
                                            i = (i + 1);
                                            notificationManager.notify(i, nf);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                } else {
                                    Notification.Builder mNotificationBuilder = new Notification.Builder(trovaService.getApplicationContext());
                                    Intent ChatActivity = new Intent(trovaService.getApplicationContext(), TrovaChat.class);
                                    try {
                                        ChatActivity.putExtra("otherUserName", chatMessageModel.getName());
                                        ChatActivity.putExtra("otherUserID", senderId);
                                        ChatActivity.putExtra("businessName", userModel.getDisplayName());
                                        ChatActivity.putExtra("isWidgetChat", widgetChat);
                                        ChatActivity.putExtra("incoming", 1);
                                        ChatActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        PendingIntent resultIntent = PendingIntent.getActivity(trovaService.getApplicationContext(), 0, ChatActivity,
                                                PendingIntent.FLAG_UPDATE_CURRENT);

                                        Uri notificationSoundURI = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                        mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                        String title = "";
                                        if (!TextUtils.isEmpty(userModel.getDisplayName())) {
                                            title = userModel.getDisplayName();
                                        } else if (!TextUtils.isEmpty(userModel.getName())) {
                                            title = userModel.getName();
                                        } else {
                                            title = userModel.getUserId();
                                        }
                                        String unicode;
                                        if (chatMessageModel.getMimeType().contains("image")) {
                                            unicode = getEmojiByUnicode(0x1F4F7);
                                        } else if (chatMessageModel.getMimeType().contains("video")) {
                                            unicode = getEmojiByUnicode(0x1F3A5);
                                        } else if (chatMessageModel.getMimeType().contains("audio")) {
                                            unicode = getEmojiByUnicode(0x1F3A7);
                                        } else {
                                            unicode = getEmojiByUnicode(0x1F4C1);
                                        }

                                        String message = unicode + " " + chatMessageModel.getMimeType() + " received";
                                        mNotificationBuilder.setContentTitle(title);
                                        mNotificationBuilder.setContentText(message).setTicker(message);
                                        mNotificationBuilder.setAutoCancel(true);
                                        mNotificationBuilder.setSound(notificationSoundURI);
                                        mNotificationBuilder.setContentIntent(resultIntent).setPriority(Notification.PRIORITY_MAX);
                                        String CHANNEL_ID = trovaService.getPackageName() + "_Channel";// The id of the channel.

                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            mNotificationBuilder.setChannelId(CHANNEL_ID);
                                        }
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                            mNotificationBuilder.setColor(trovaService.getResources().getColor(R.color.colorPrimary));
                                        } else {
                                            mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                        }
                                        NotificationManager notificationManager = (NotificationManager) trovaService.getSystemService(trovaService.getApplicationContext().NOTIFICATION_SERVICE);
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            String channelName = trovaService.getPackageName();
                                            int importance = NotificationManager.IMPORTANCE_HIGH;
                                            NotificationChannel mChannel = new NotificationChannel(
                                                    CHANNEL_ID, channelName, importance);
                                            notificationManager.createNotificationChannel(mChannel);
                                        }
                                        mNotificationBuilder.setStyle(new Notification.BigTextStyle()
                                                .bigText(message));
                                        Notification nf = mNotificationBuilder.build();
                                        i = (i + 1);
                                        notificationManager.notify(i, nf);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (jsonObject.getString("env").equalsIgnoreCase("widget")) {
                                    widgetChat = true;
                                    GadgetAgent = userModel.getUserId();
                                    userModel.setAgentKey(agentKeyHashmap.get(senderId));
                                    userModel.setDisplayName(businessname);
                                    dataBaseHandler.saveAgentLogs(userModel);
                                } else {
                                    userModel.setAgentKey("");
                                    userModel.setDisplayName("");
                                    dataBaseHandler.saveContactLogs(userModel);
//                                    dataBaseHandler.saveFilteredContacts(userModel);
                                }
                                if (chatListActivity != null) {
                                    chatListActivity.reload();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;
                        case OnTrovaRequestToConf:
                            JSONObject notification = new JSONObject(jsonObject.getString("extraData"));
                            createJoinConferenceNotification(notification);
                            break;

                        case OnTrovaReceiveNotification:
                            notification = new JSONObject(jsonObject.getString("notification"));
                            String serverPath = "";
                            if (notification.has("serverPath")) {
                                serverPath = notification.getString("serverPath");
                            }
                            switch (notification.getString("event")) {
                                case "onMissedEscalation":
                                case "onCancelEscalation":
                                    String senderId = "";
                                    if (jsonObject.has("senderId")) {
                                        senderId = jsonObject.getString("senderId");
                                    } else if (jsonObject.has("userId")) {
                                        senderId = jsonObject.getString("userId");
                                    }
                                    if (TextUtils.isEmpty(senderId)) {
                                        String sid = new JSONObject(jsonObject.toString()).getString("notification");
                                        senderId = new JSONObject(sid).getString("userId");
                                    }
                                    jsonObject.put("callerId", senderId);
                                    jsonObject.put("trovaEvent", notification.getString("event"));
                                    if (ReachVoiceCall.reachVoiceCall != null) {
                                        ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    } else if (ReachVideoCall.reachVideoCall != null) {
                                        ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                                    } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                        ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    }*/
                                    break;
                                case "micoff":
                                    senderId = "";
                                    if (jsonObject.has("senderId")) {
                                        senderId = jsonObject.getString("senderId");
                                    } else if (jsonObject.has("userId")) {
                                        senderId = jsonObject.getString("userId");
                                    }
                                    if (TextUtils.isEmpty(senderId)) {
                                        String sid = new JSONObject(jsonObject.toString()).getString("notification");
                                        senderId = new JSONObject(sid).getString("userId");
                                    }
                                    jsonObject.put("callerId", senderId);
                                    jsonObject.put("trovaEvent", "micoff");
                                    if (ReachVoiceCall.reachVoiceCall != null) {
                                        ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    } else if (ReachVideoCall.reachVideoCall != null) {
                                        ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                                    } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                        ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    }
*/
                                    break;
                                case "micon":
                                    senderId = "";
                                    if (jsonObject.has("senderId")) {
                                        senderId = jsonObject.getString("senderId");
                                    } else if (jsonObject.has("userId")) {
                                        senderId = jsonObject.getString("userId");
                                    }
                                    if (TextUtils.isEmpty(senderId)) {
                                        String sid = new JSONObject(jsonObject.toString()).getString("notification");
                                        senderId = new JSONObject(sid).getString("userId");
                                    }
                                    jsonObject.put("callerId", senderId);
                                    jsonObject.put("trovaEvent", "micon");
                                    if (ReachVoiceCall.reachVoiceCall != null) {
                                        ReachVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    } else if (ReachVideoCall.reachVideoCall != null) {
                                        ReachVideoCall.reachVideoCall.TrovaEvents(jsonObject);
                                    } /*else if (ReachConferenceVoiceCall.reachVoiceCall != null) {
                                        ReachConferenceVoiceCall.reachVoiceCall.TrovaEvents(jsonObject);
                                    }*/
                                    break;

                                case "onContactAvailable":
                                    /*Intent DashBoardActivity = new Intent(trovaService, DashBoard.class);
                                    PendingIntent DashBoardActivityPI = PendingIntent.getActivity(trovaService, 0, DashBoardActivity, 0);

                                    NotificationCompat.Builder mNotificationBuilder = new NotificationCompat.Builder(trovaService.getApplicationContext());
                                    Uri notificationSoundURI = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                                    mNotificationBuilder.setSmallIcon(R.drawable.ic_launcher);
                                    String contactname = dataBaseHandler.getUserName(notification.getString("userId"));
                                    if (TextUtils.isEmpty(contactname)) {
                                        contactname = notification.getString("name");
                                    }
                                    mNotificationBuilder.setContentTitle(contactname + " is now available");
//                            mNotificationBuilder.setContentText(chatMessageModel.getMimeType() + " received");
                                    mNotificationBuilder.setContentIntent(DashBoardActivityPI);
                                    mNotificationBuilder.setAutoCancel(true);
                                    mNotificationBuilder.setSound(notificationSoundURI);
                                    mNotificationBuilder.setPriority(Notification.PRIORITY_MAX);
                                    mNotificationBuilder.setVibrate(new long[]{0, 200, 600});
//                                mNotificationBuilder.setContentIntent(resultIntent);
                                    NotificationManager notificationManager = (NotificationManager) trovaService.getSystemService(trovaService.getApplicationContext().NOTIFICATION_SERVICE);
                                    int i = 0;
                                    notificationManager.notify(i, mNotificationBuilder.build());
                                    if (ContactList.Companion.getContactList() != null) {
                                        ContactList.Companion.getContactList().fetchContacts();
                                        ContactList.Companion.getRv_contact_list().getAdapter().notifyDataSetChanged();
                                    }*/
                                    break;

                                case "onMessageDelivered":
                                    if (TrovaChat.trovaChat != null) {
                                        if (TrovaChat.chatSenderId.equalsIgnoreCase(notification.getString("userId"))) {
                                            TrovaChat.trovaChat.TrovaEvent(jsonObject);
                                        }
                                    }
                                    dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                                    if (serverPath.equalsIgnoreCase("")) {
                                        dataBaseHandler.updateChatMessageStatus(notification.getString("messageId"), 1);
                                    } else {
                                        dataBaseHandler.updateChatFileStatus(serverPath, 1);
                                    }
                                    dataBaseHandler.updateChatLogSeenStatus(notification.getString("userId"), 1, true, notification.getString("messageId"));

                                    if (chatListActivity != null) {
                                        chatListActivity.reload();
                                    }
                                    break;
                                case "onMessageSeen":
                                    if (TrovaChat.trovaChat != null) {
                                        if (TrovaChat.chatSenderId.equalsIgnoreCase(notification.getString("userId"))) {
                                            TrovaChat.trovaChat.TrovaEvent(jsonObject);
                                        }
                                    }
                                    dataBaseHandler = DataBaseHandler.getInstance(trovaService);
                                    if (serverPath.equalsIgnoreCase("")) {
                                        dataBaseHandler.updateChatMessageStatus(notification.getString("messageId"), 2);
                                    } else {
                                        dataBaseHandler.updateChatFileStatus(serverPath, 2);
                                    }
                                    dataBaseHandler.updateChatLogSeenStatus(notification.getString("userId"), 2, true, notification.getString("messageId"));
                                    if (chatListActivity != null) {
                                        chatListActivity.reload();
                                    }
                                    break;
                                case OnTrovaReceiveGetAllOfflineReceiveMessage:
                                    String message = jsonObject.getString("message");
                                    try {
                                        JSONArray jsonArray = new JSONArray(message);
                                        ArrayList<String> messageIdList = new ArrayList<>();
//                    String[] messageIdList = new String[jsonArray.length()];
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                            String msgId = jsonObject1.getString("msgId");
                                            messageIdList.add(msgId);
//                        messageIdList[i] = msgId;
                                        }
//                    if (Globalclass.trovaApi != null)
//                        Globalclass.trovaApi.trovaUpdateMessageId(messageIdList);
//                    trovaApi.trovaUpdateMessageId(messageIdList);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                case OnTrovaReceiveGetAllSyncSendMessage:
                                    message = jsonObject.getString("message");
                                    try {
                                        JSONArray jsonArray = new JSONArray(message);
                                        ArrayList<String> messageIdList = new ArrayList<>();
//                    String[] messageIdList = new String[jsonArray.length()];
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                            String msgId = jsonObject1.getString("msgId");
                                            messageIdList.add(msgId);
//                        messageIdList[i] = msgId;
                                        }
//                    if (Globalclass.trovaApi != null)
//                        Globalclass.trovaApi..trovaUpdateMessageId(messageIdList);
//                    trovaApi.trovaUpdateMessageId(messageIdList);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    break;
                                case OnGetAllUnDeliverdMessages:
                                    break;
                                case OnRecvSyncAppState:
                                    String appstate = jsonObject.getString("appstate");
                                    String appStateId = jsonObject.getString("syncId");
                                    break;
                                case OnGetAllSyncAppState:
                                    message = jsonObject.getString("message");

                                    break;
                            }

                            break;
                    }
                } catch (
                        Exception e)

                {
                    e.printStackTrace();
//                    MyLogger.appendLog("Exception", e.getMessage());
//                    MyLogger.appendLog("Exception", e.getMessage());
                }
            }
        });
    }

    public static void createJoinConferenceNotification(JSONObject notification) {

        /*this notification data is user in TrovaAPIService.class executeRecivedNotification()*/

        Intent JoinConferenceIntent = new Intent();
        JoinConferenceIntent.setAction(KEY_JOIN_CONFERENCE);
        JoinConferenceIntent.putExtra("notification_data", notification.toString());
        PendingIntent JoinConferencePI = PendingIntent.getBroadcast(trovaService, 0, JoinConferenceIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent RejectConferenceIntent = new Intent();
        RejectConferenceIntent.setAction(KEY_REJECT_CONFERENCE);
        RejectConferenceIntent.putExtra("notification_data", notification.toString());
        PendingIntent RejectConferencePI = PendingIntent.getBroadcast(trovaService, 0, RejectConferenceIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(trovaService)
                .setContentTitle("Invite for conference")
                .setContentText("Do you wish to join the conference?")
                .setSmallIcon(R.drawable.ic_launcher)
//                .setContentIntent(CallPI)
                .setAutoCancel(true)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(R.drawable.ic_phone_black_24dp, "Yes", JoinConferencePI)
                .addAction(R.drawable.ic_phone_black_24dp, "No", RejectConferencePI)
//                .setVibrate(new long[]{0, 200, 600})
                .build();


        notificationManager =
                (NotificationManager) trovaService.getSystemService(NOTIFICATION_SERVICE);

        notificationManager.notify(0, n);

        final Intent intent = new Intent(trovaService, JoinConferenceDialog.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("notification_data", notification.toString());
        trovaService.startActivity(intent);
    }

    public static void createIncomingCallNotification() {
        String displayId;
        if (TextUtils.isEmpty(userNotif.getName())) {
            displayId = userNotif.getUserId();
        } else {
            displayId = userNotif.getName();
        }
        Intent CallActivity = null;
        if (callmode.equalsIgnoreCase("audio")) {
            CallActivity = new Intent(trovaService, ReachVoiceCall.class);
        } else if (callmode.equalsIgnoreCase("video")) {
            CallActivity = new Intent(trovaService, ReachVideoCall.class);
        }
        CallActivity.putExtra("date", userNotif.getDate());
        CallActivity.putExtra("otherUserName", userNotif.getName());
        CallActivity.putExtra("businessName", displaynameHashmap.get(userNotif.getUserId()));
        CallActivity.putExtra("otherUserID", userNotif.getUserId());
        CallActivity.putExtra("callType", "answer");
        CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent CallPI = PendingIntent.getActivity(trovaService, 0, CallActivity, 0);

        Intent AcceptCallIntent = new Intent();
        AcceptCallIntent.setAction(KEY_ACCEPT_CALL);
        PendingIntent AcceptCallPI = PendingIntent.getBroadcast(trovaService, 0, AcceptCallIntent, 0);

        Intent RejectCallIntent = new Intent();
        RejectCallIntent.setAction(KEY_REJECT_CALL);
        PendingIntent RejectCallPI = PendingIntent.getBroadcast(trovaService, 0, RejectCallIntent, 0);

        Notification n = new Notification.Builder(trovaService)
                .setContentTitle("Incoming")
                .setContentText(displayId)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(CallPI)
                .setAutoCancel(true)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MAX)
                .addAction(R.drawable.ic_phone_black_24dp, "Answer", AcceptCallPI)
                .addAction(R.drawable.ic_phone_black_24dp, "Decline", RejectCallPI)
//                .setVibrate(new long[]{0, 200, 600})
                .build();


        notificationManager =
                (NotificationManager) trovaService.getSystemService(NOTIFICATION_SERVICE);

        notificationManager.notify(0, n);
    }

    public static void createInCallNotification(String otherUserName, String otherUserID, String callMode) {
        String displayId;
        if (!TextUtils.isEmpty(otherUserName)) {
            displayId = otherUserName;
        } else {
            displayId = otherUserID;
        }
        if (userNotif == null) {
            userNotif = new UserModel();
        }
        callmode = callMode;
        userNotif.setUserId(otherUserID);
        Intent CallActivity = null;
        if (callMode.equalsIgnoreCase("audio")) {
            CallActivity = new Intent(trovaService, ReachVoiceCall.class);
        } else if (callMode.equalsIgnoreCase("video")) {
            CallActivity = new Intent(trovaService, ReachVideoCall.class);
        }
        if (ReachVoiceCall.reachVoiceCall == null) {
//            CallActivity.putExtra("date", userNotif.getDate());
            CallActivity.putExtra("otherUserName", otherUserName);
            CallActivity.putExtra("businessName", displaynameHashmap.get(otherUserID));
            CallActivity.putExtra("otherUserID", otherUserID);
            CallActivity.putExtra("callType", "in_call");
            CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        PendingIntent CallPI = PendingIntent.getActivity(trovaService, 0, CallActivity, 0);

        Intent RejectCallIntent = new Intent();
        RejectCallIntent.setAction(KEY_REJECT_CALL);
        PendingIntent RejectCallPI = PendingIntent.getBroadcast(trovaService, 0, RejectCallIntent, 0);

        Notification n = new Notification.Builder(trovaService)
                .setContentTitle("In-Call")
                .setContentText(displayId)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(CallPI)
                .setAutoCancel(false)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_HIGH)
                .addAction(R.drawable.ic_phone_black_24dp, "End Call", RejectCallPI)
                .build();


        notificationManager =
                (NotificationManager) trovaService.getSystemService(NOTIFICATION_SERVICE);

        notificationManager.notify(1, n);
    }

    public static void setCallBack(TrovaUIAPICallBack trovaUIAPICallBack) {
        TrovaService.trovaUIAPICallBack = trovaUIAPICallBack;
    }

    public class MyReceiver extends BroadcastReceiver {
        public MyReceiver() {
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            // This method is called when this BroadcastReceiver receives an Intent broadcast.
            String action = intent.getAction();
//            byte[] bytes = new byte[100];
//            Bundle bundle = ParcelableUtil.unmarshall(new byte[]{intent.getByteExtra("bundle", (byte) 1)});
            switch (action) {
                case "accept_call":
                    if (ReachVoiceCall.reachVoiceCall != null) {
                        ReachVoiceCall.reachVoiceCall.img_trova_voice_call_accept.callOnClick();
                    } else if (ReachVideoCall.reachVideoCall != null) {
                        ReachVideoCall.reachVideoCall.img_trova_video_call_accept.callOnClick();
                    }
                    Intent CallActivity = null;
                    if (callmode.equalsIgnoreCase("audio")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVoiceCall.class);
                        CallActivity = new Intent(trovaService.getApplicationContext(), ReachVoiceCall.class);
                    } else if (callmode.equalsIgnoreCase("video")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVideoCall.class);
                        CallActivity = new Intent(trovaService.getApplicationContext(), ReachVideoCall.class);
                    }
                    CallActivity.putExtra("date", userNotif.getDate());
                    CallActivity.putExtra("otherUserName", userNotif.getName());
                    CallActivity.putExtra("businessName", displaynameHashmap.get(userNotif.getUserId()));
                    CallActivity.putExtra("otherUserID", userNotif.getUserId());
                    CallActivity.putExtra("callType", "answer");
                    CallActivity.putExtra("action", "accept_call");
                    CallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    trovaService.getApplicationContext().startActivity(CallActivity);
                    break;

                case "reject_call":
                    if (ReachVoiceCall.reachVoiceCall != null) {
                        ReachVoiceCall.reachVoiceCall.img_trova_voice_call_reject.callOnClick();
                    } else if (ReachVideoCall.reachVideoCall != null) {
                        ReachVideoCall.reachVideoCall.img_trova_video_call_reject.callOnClick();
                    } else {
                        notificationManager.cancelAll();
                        if (callmode.equalsIgnoreCase("audio")) {
                            Globalclass.trovaSDK_init.trovaCall_Reject("audio", userNotif.getUserId());
                        } else if (callmode.equalsIgnoreCase("video")) {
                            Globalclass.trovaSDK_init.trovaCall_Reject("video", userNotif.getUserId());
                        }
                    }
                    userNotif = null;
                    break;

                case "join_conference":
                    notificationManager.cancelAll();
                    try {
                        JSONObject jobj = new JSONObject(intent.getStringExtra("notification_data"));
                        try {
                            Calendar cal = Calendar.getInstance();
                            TimeZone tz = cal.getTimeZone();
                            String timezone = tz.getDisplayName();
                            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                            String currDate = df.format(cal.getTime());
                            df = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                            String time = df.format(cal.getTime());
                            Intent ConferenceCallActivity = null;
                            if (jobj.getString("callMode").equalsIgnoreCase("audio")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVoiceCall.class);
                                ConferenceCallActivity = new Intent(trovaService, ReachVoiceCall.class);
                            } else if (jobj.getString("callMode").equalsIgnoreCase("video")) {
//                                CallActivity = new Intent(getApplicationContext(), ReachVideoCall.class);
                                ConferenceCallActivity = new Intent(trovaService, ReachVideoCall.class);
                            }
                            ConferenceCallActivity.putExtra("date", currDate);
                            ConferenceCallActivity.putExtra("otherUserName", "");
                            ConferenceCallActivity.putExtra("businessName", jobj.getString("businessName"));
//                                String agentKey = jsonObject.getString("agentKey");
                            ConferenceCallActivity.putExtra("agentKey", jobj.getString("agentKey"));
//                                if (!TextUtils.isEmpty(agentKey)) {
//                                    CallActivity.putExtra("isAgentCall", 1);
//                                }
                            ConferenceCallActivity.putExtra("otherUserID", jobj.getString("otherUserID"));
                            ConferenceCallActivity.putExtra("callType", "in_call");
                            ConferenceCallActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            trovaService.startActivity(ConferenceCallActivity);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
//                                Globalclass.trovaSDK_init.trovaGadgetCall_Init(jobj.getString("callMode"),jobj.getString("agentKey"),jobj.getString("otherUserID"));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;

                case "reject_conference":
                    notificationManager.cancelAll();
//                        try {
//                            JSONObject jobj = new JSONObject(intent.getStringExtra("notification_data"));
//                            Globalclass.trovaSDK_init.trovaCall_End(jobj.getString("callMode"),jobj.getString("otherUserID"));
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
                    break;
            }
        }

    }

    private static SensorManager sensorManager;
    private static PowerManager.WakeLock pmWakeLock;
    private static SensorEventListener sensorEventListener;
    public static int STOPPED = 0;
    public static int STARTING = 1;
    public static int RUNNING = 2;
    public static int ERROR_FAILED_TO_START = 3;
    PowerManager.WakeLock partialWakeLock;
    static int status;

    private void createSensorManager() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            boolean supportProximity = false;
            Field f = PowerManager.class.getDeclaredField("PROXIMITY_SCREEN_OFF_WAKE_LOCK");
            int proximityScreenOffWakeLock = (Integer) f.get(null);

            if (Build.VERSION.SDK_INT >= 17) {
                Method method = pm.getClass().getDeclaredMethod("isWakeLockLevelSupported", int.class);
                supportProximity = (Boolean) method.invoke(pm, proximityScreenOffWakeLock);
            } else {
                Method method = pm.getClass().getDeclaredMethod("getSupportedWakeLockFlags");
                int supportedFlags = (Integer) method.invoke(pm);
                supportProximity = ((supportedFlags & proximityScreenOffWakeLock) != 0x0);
            }

            if (supportProximity) {
                pmWakeLock = pm.newWakeLock(proximityScreenOffWakeLock, "in.trova.android");
                pmWakeLock.setReferenceCounted(false);
            }

            partialWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE, "in.trova.android");
        } catch (Exception e) {
            logData("", "Impossible to get power manager supported wake lock flags");
        }
    }

    public static int startProximity() {
        Sensor mSensor;
        @SuppressWarnings("deprecation")
        List<Sensor> list = sensorManager.getSensorList(Sensor.TYPE_PROXIMITY);

        if (pmWakeLock != null && !pmWakeLock.isHeld()) {
            pmWakeLock.acquire();
        }
        if (list != null && list.size() > 0) {
            mSensor = list.get(0);
            sensorManager.registerListener(sensorEventListener, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
            status = STARTING;
        } else {
            status = ERROR_FAILED_TO_START;
        }

        return status;
    }

    public static void stopProximity() {
        if (status != STOPPED) {
            sensorManager.unregisterListener(sensorEventListener);
        }
        if (pmWakeLock != null && pmWakeLock.isHeld()) {
            pmWakeLock.release();
        }
        status = STOPPED;
    }

    public static String getEmojiByUnicode(int unicode) {
        return new String(Character.toChars(unicode));
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (TrovaService.notificationManager != null) {
            TrovaService.notificationManager.cancelAll();
        }
        if (TrovaService.userNotif != null) {
            TrovaService.userNotif = null;
        }

        if (Globalclass.trovaSDK_init != null) {
            Globalclass.trovaSDK_init.trovaSession_Disconnect();
            Globalclass.trovaSDK_init.trovaFree();
        }

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        for (int i = 1; i <= 100; i++) {
//            Log.w("onTaskRemoved", "count :" + i);
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
        super.onTaskRemoved(rootIntent);

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.values[0] == 0) {
            if (partialWakeLock != null && !partialWakeLock.isHeld()) {
                partialWakeLock.acquire();
            }
        } else {

            if (partialWakeLock != null && partialWakeLock.isHeld()) {
                partialWakeLock.release();
            }
        }
        status = RUNNING;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
